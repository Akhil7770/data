from typing import List
from pydantic import BaseModel

from app.schemas.benefit_common import (
    Modifier,
    SupportingServiceCodes,
    PlaceOfService,
    ProviderType,
    ProviderSpecialty,
)


class ServiceCodeInfo(BaseModel):
    code: str
    type: str
    modifier: List[Modifier]
    supportingServiceCodes: List[SupportingServiceCodes]
    placeOfService: List[PlaceOfService]
    providerType: List[ProviderType]
    providerSpecialty: List[ProviderSpecialty]
    pin: str


class ServiceInfo(BaseModel):
    serviceCodeInfo: ServiceCodeInfo


class BenefitRequest(BaseModel):
    """Model for benefit request data."""

    membershipID: str
    benefitProductType: str
    serviceInfo: List[ServiceInfo]
