from typing import List, Optional
from pydantic import BaseModel, Field

from app.schemas.benefit_common import (
    Modifier,
    SupportingServiceCodes,
    PlaceOfService,
    ProviderType,
    ProviderSpecialty,
)


class Diagnosis(BaseModel):
    code: Optional[str] = ""


class ServiceCodeInfoItem(BaseModel):
    code: str
    type: str
    modifier: Optional[List[Modifier]] = []
    diagnosis: Optional[List[Diagnosis]] = Field(default_factory=list)
    supportingServiceCodes: Optional[List[SupportingServiceCodes]] = []


class GrpIndicator(BaseModel):
    typeInd: Optional[str] = ""
    typeCode: Optional[str] = ""


class BenefitTier(BaseModel):
    benefitTierName: Optional[str] = ""

    def __init__(self, **data):
        # Handle empty dict case
        if not data:
            data = {"benefitTierName": ""}
        super().__init__(**data)


class Prerequisite(BaseModel):
    type: Optional[str]
    isRequired: Optional[str]

    def __init__(self, **data):
        # Handle empty dict case
        if not data:
            data = {"type": "", "isRequired": ""}
        super().__init__(**data)


class ServiceProviderItem(BaseModel):
    providerDesignation: Optional[str]

    def __init__(self, **data):
        # Handle empty dict case
        if not data:
            data = {"providerDesignation": ""}
        super().__init__(**data)


class RelatedAccumulator(BaseModel):
    code: Optional[str] = ""
    level: Optional[str] = ""
    description: Optional[str] = ""
    deductibleCode: Optional[str] = ""
    accumExCode: Optional[str] = ""
    networkIndicatorCode: Optional[str] = ""
    limitMaxForBenefit: Optional[float] = 0.0
    alternateBenefits: List[dict] = Field(default_factory=list)


class Coverage(BaseModel):
    sequenceNumber: int
    benefitDescription: Optional[str] = ""
    maxCoverageAmount: Optional[float] = 0.0
    costShareCopay: Optional[float] = 0.0
    costShareCoinsurance: Optional[float] = 0.0
    copayAppliesOutOfPocket: Optional[str] = "N"
    coinsAppliesOutOfPocket: Optional[str] = "N"
    deductibleAppliesOutOfPocket: Optional[str] = "N"
    deductibleAppliesOutOfPocketOtherIndicator: Optional[str] = "N"
    copayCountToDeductibleIndicator: Optional[str] = "N"
    copayContinueWhenDeductibleMetIndicator: Optional[str] = "N"
    copayContinueWhenOutOfPocketMaxMetIndicator: Optional[str] = "N"
    coinsuranceToOutOfPocketOtherIndicator: Optional[str] = "N"
    copayToOutofPocketOtherIndicator: Optional[str] = "N"
    isDeductibleBeforeCopay: Optional[str] = "N"
    benefitLimitation: Optional[str] = "N"
    isServiceCovered: Optional[str] = "N"
    relatedAccumulators: Optional[List[RelatedAccumulator]] = Field(
        default_factory=list
    )


class Benefit(BaseModel):
    benefitName: str
    benefitCode: int
    isInitialBenefit: Optional[str] = ""
    benefitTier: Optional[BenefitTier] = BenefitTier()
    networkCategory: str
    prerequisites: Optional[List[Prerequisite]] = []
    benefitProvider: Optional[str] = ""
    serviceProvider: Optional[List[ServiceProviderItem]] = []
    coverages: List[Coverage] = Field(max_length=1)


class ServiceInfoItem(BaseModel):
    serviceCodeInfo: List[ServiceCodeInfoItem]
    placeOfService: List[PlaceOfService]
    providerType: Optional[List[ProviderType]] = []
    providerSpecialty: Optional[List[ProviderSpecialty]] = []
    pin: str
    grpIndicator: Optional[List[GrpIndicator]] = []
    benefit: List[Benefit]


# New model for the actual API response structure
class BenefitApiResponse(BaseModel):
    serviceInfo: List[ServiceInfoItem]

    def getBenefit(
        self,
        network_category: Optional[str] = None,
        benefit_tier_name: Optional[str] = None,
        benefit_code: Optional[int] = None,
    ) -> Optional[Benefit]:
        """
        Get a specific benefit from the response based on criteria.

        Args:
            network_category: Filter by network category (e.g., "InNetwork", "OutofNetwork")
            benefit_tier_name: Filter by benefit tier name
            benefit_code: Filter by benefit code

        Returns:
            First matching Benefit object or None if not found
        """
        for service_info_item in self.serviceInfo:
            for benefit in service_info_item.benefit:
                # Check network category
                if network_category and benefit.networkCategory != network_category:
                    continue

                # Check benefit tier name
                if (
                    benefit_tier_name
                    and benefit.benefitTier
                    and benefit.benefitTier.benefitTierName != benefit_tier_name
                ):
                    continue

                # Check benefit code
                if benefit_code and benefit.benefitCode != benefit_code:
                    continue

                return benefit
        return None

    def getBenefits(
        self,
        network_category: Optional[str] = None,
        benefit_tier_name: Optional[str] = None,
    ) -> List[Benefit]:
        """
        Get all benefits from the response that match the criteria.

        Args:
            network_category: Filter by network category (e.g., "InNetwork", "OutofNetwork")
            benefit_tier_name: Filter by benefit tier name

        Returns:
            List of matching Benefit objects
        """
        matching_benefits = []

        for service_info_item in self.serviceInfo:
            for benefit in service_info_item.benefit:
                # Check network category
                if network_category and benefit.networkCategory != network_category:
                    continue

                # Check benefit tier name
                if (
                    benefit_tier_name
                    and benefit.benefitTier
                    and benefit.benefitTier.benefitTierName != benefit_tier_name
                ):
                    continue

                matching_benefits.append(benefit)

        return matching_benefits

    def getBenefitByProviderTier(
        self, provider_tier: str, network_category: Optional[str] = None
    ) -> Optional[Benefit]:
        """
        Get a benefit that matches the provider tier.

        Args:
            provider_tier: The provider tier to match
            network_category: Optional network category filter

        Returns:
            First matching Benefit object or None if not found
        """
        return self.getBenefit(
            network_category=network_category, benefit_tier_name=provider_tier
        )
