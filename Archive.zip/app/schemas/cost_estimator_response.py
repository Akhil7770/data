from typing import List, Optional, Union, Dict, Any, Callable
from pydantic import BaseModel

from app.core.base import InsuranceContext
from app.core.constants import RATE_TYPE_AMOUNT
from app.core.logger import logger
from app.exception.exception_handler import (
    rate_not_found_exception_handler_logic,
    provider_not_found_exception_handler_logic,
    insurance_context_error_exception_handler_logic,
    benefits_not_matching_exception_handler_logic,
)
from app.exception.exceptions import (
    RateNotFoundException,
    InsuranceContextException,
    BenefitsNotMatchingException,
    ProviderNotFoundException,
)
from app.models.rate_criteria import NegotiatedRate
from app.models.selected_benefit import SelectedBenefit
from app.schemas.cost_estimator_common import (
    Service,
    ProviderInfo,
)
from app.schemas.cost_estimator_request import CostEstimatorRequest


class Coverage(BaseModel):
    isServiceCovered: str
    maxCoverageAmount: float
    costShareCopay: float
    costShareCoinsurance: int


class Cost(BaseModel):
    inNetworkCosts: float
    outOfNetworkCosts: float
    inNetworkCostsType: str


class HealthClaimLine(BaseModel):
    amountCopay: float
    amountCoinsurance: float
    amountResponsibility: float
    percentResponsibility: float
    amountpayable: float


class Accumulator(BaseModel):
    code: str
    level: str
    limitValue: float
    currentValue: float
    calculatedValue: float


class AccumulatorWithLimitType(BaseModel):
    code: str
    level: str
    limitValue: float
    limitType: str
    calculatedValue: float


class AccumulatorCalculation(BaseModel):
    remainingValue: float
    appliedValue: float


class AccumulatorCalculationWithType(BaseModel):
    remainingValue: float
    appliedValue: float
    appliedValueType: str


class AccumulatorInfo(BaseModel):
    accumulator: Union[Accumulator, AccumulatorWithLimitType]
    accumulatorCalculation: Union[
        AccumulatorCalculation, AccumulatorCalculationWithType
    ]


class CostEstimateResponseInfo(BaseModel):
    providerInfo: ProviderInfo
    coverage: Coverage
    cost: Cost
    healthClaimLine: HealthClaimLine
    accumulators: List[AccumulatorInfo]


class CostEstimateResponseInfoError(BaseModel):
    providerInfo: ProviderInfo
    exception: Dict[str, Any]

    def __init__(
        self,
        providerInfo: ProviderInfo,
        headers: Dict[str, str],
        exc: Exception,
        handler_logic: Callable[[Exception, Dict[str, str]], Dict[str, Any]],
    ):
        super().__init__(
            providerInfo=providerInfo,
            exception=handler_logic(exc, headers),
        )
        logger.error(f"{exc.__class__.__name__} was handled and returned")


class CostEstimateResponse(BaseModel):
    service: Service
    costEstimateResponseInfo: List[
        Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]
    ]


class CostEstimatorResponse(BaseModel):
    costEstimateResponse: CostEstimateResponse

    @classmethod
    def _validate_insurance_context_and_rate(
        cls,
        insuranceContext: InsuranceContext,
        negotiated_rate: NegotiatedRate,
    ) -> Optional[InsuranceContextException]:
        """
        Validate InsuranceContext and NegotiatedRate for business rule violations.

        Returns InsuranceContextException if any validation fails, None otherwise.
        Validations are checked in priority order:
        1. Negative values in numeric fields
        2. Negotiated rate less than member pays
        3. Cost share coinsurance greater than 100
        """
        # Check for negative values in numeric fields
        negative_fields = []
        numeric_fields = [
            ("cost_share_copay", insuranceContext.cost_share_copay),
            ("cost_share_coinsurance", insuranceContext.cost_share_coinsurance),
            ("member_pays", insuranceContext.member_pays),
            ("amount_copay", insuranceContext.amount_copay),
            ("amount_coinsurance", insuranceContext.amount_coinsurance),
            ("oopmax_family_calculated", insuranceContext.oopmax_family_calculated),
            (
                "oopmax_individual_calculated",
                insuranceContext.oopmax_individual_calculated,
            ),
            (
                "deductible_individual_calculated",
                insuranceContext.deductible_individual_calculated,
            ),
            (
                "deductible_family_calculated",
                insuranceContext.deductible_family_calculated,
            ),
            ("limit_calculated", insuranceContext.limit_calculated),
        ]

        for field_name, field_value in numeric_fields:
            if field_value is not None and field_value < 0:
                negative_fields.append(f"{field_name}={field_value}")

        # Determine which exception to use (prioritize negative values check over existing error_code)
        exc: Optional[InsuranceContextException] = None

        if negative_fields:
            error_message = f"Negative values found in insurance context: {', '.join(negative_fields)}"
            exc = InsuranceContextException(
                "Insurance context contains negative values which are not allowed",
                error_code="IC_NEGATIVE_VALUES",
                error_message=error_message,
            )
        elif round(negotiated_rate.rate, 2) < round(insuranceContext.member_pays, 2):
            error_message = f"Negotiated rate is less than member pays which is not allowed: negotiated_rate={round(negotiated_rate.rate, 2)}, member_pays={round(insuranceContext.member_pays,2)}"
            exc = InsuranceContextException(
                "Negotiated rate is less than member pays which is not allowed",
                error_code="IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE",
                error_message=error_message,
            )
        elif insuranceContext.cost_share_coinsurance > 100:
            error_message = f"Cost share coinsurance is greater than 100 which is not allowed: cost_share_coinsurance={insuranceContext.cost_share_coinsurance}"
            exc = InsuranceContextException(
                "Cost share coinsurance is greater than 100 which is not allowed",
                error_code="IC_COST_SHARE_COINSURANCE_GREATER_THAN_100",
                error_message=error_message,
            )

        return exc

    @classmethod
    def build_cost_estimate_response_info(
        cls,
        headers: Dict[str, str],
        provider_info: ProviderInfo,
        selected_benefits: List[SelectedBenefit],
        insuranceContext: InsuranceContext,
        negotiated_rate: NegotiatedRate,
        raise_exception: bool = False,
    ) -> Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]:
        """
        Build a CostEstimatorResponse with the provided details.
        """

        if not negotiated_rate.isProviderInfoFound:
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                headers=headers,
                exc=ProviderNotFoundException(),
                handler_logic=provider_not_found_exception_handler_logic,
            )
        elif not negotiated_rate.isRateFound:
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                headers=headers,
                exc=RateNotFoundException(),
                handler_logic=rate_not_found_exception_handler_logic,
            )

        if len(selected_benefits) == 0:
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                headers=headers,
                exc=BenefitsNotMatchingException(),
                handler_logic=benefits_not_matching_exception_handler_logic,
            )

        # Validate InsuranceContext and NegotiatedRate
        validation_exc = cls._validate_insurance_context_and_rate(
            insuranceContext, negotiated_rate
        )

        # Handle the exception (raise or return error response)
        if validation_exc is not None:
            if raise_exception:
                raise validation_exc
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                headers=headers,
                exc=validation_exc,
                handler_logic=insurance_context_error_exception_handler_logic,
            )

        # Check for existing error codes in InsuranceContext
        if insuranceContext.error_code is not None:
            exc = InsuranceContextException(
                error_code=insuranceContext.error_code,
                error_message=insuranceContext.error_message,
            )
            if raise_exception:
                raise exc
            return CostEstimateResponseInfoError(
                providerInfo=provider_info,
                headers=headers,
                exc=exc,
                handler_logic=insurance_context_error_exception_handler_logic,
            )

        # Extract data from the request and context
        selected_benefit_of_highest_member_pay = cls.select_benefit(
            selected_benefits, insuranceContext
        )

        coverage = Coverage(
            isServiceCovered=(
                selected_benefit_of_highest_member_pay.coverage.isServiceCovered
                if selected_benefit_of_highest_member_pay
                else "N"
            ),
            maxCoverageAmount=0.0,
            costShareCopay=float(
                selected_benefit_of_highest_member_pay.coverage.costShareCopay
                if selected_benefit_of_highest_member_pay
                else 0.0
            ),
            costShareCoinsurance=int(
                selected_benefit_of_highest_member_pay.coverage.costShareCoinsurance
                if selected_benefit_of_highest_member_pay
                else 0
            ),
        )

        # Create cost information
        cost = Cost(
            inNetworkCosts=round(float(negotiated_rate.rate), 2),
            outOfNetworkCosts=float(0.0),
            inNetworkCostsType=negotiated_rate.rateType,
        )

        # Create health claim line
        if negotiated_rate.rateType == RATE_TYPE_AMOUNT:
            health_claim_line = HealthClaimLine(
                amountCopay=insuranceContext.amount_copay,
                amountCoinsurance=round(insuranceContext.amount_coinsurance, 2),
                amountResponsibility=round(insuranceContext.member_pays, 2),
                percentResponsibility=0.0,
                amountpayable=round(
                    negotiated_rate.rate - insuranceContext.member_pays, 2
                ),
            )
        else:
            health_claim_line = HealthClaimLine(
                amountCopay=0.0,
                amountCoinsurance=0.0,
                amountResponsibility=0,
                percentResponsibility=negotiated_rate.rate,
                amountpayable=0.0,
            )

        if selected_benefit_of_highest_member_pay is not None:
            accumulators = []
            accumulators = cls.build_accumulator(
                selected_benefit_of_highest_member_pay.coverage.matchedAccumulators,
                insuranceContext,
                negotiated_rate.rateType,
            )
        else:
            accumulators = []

        logger.info(insuranceContext.get_trace_summary())

        cost_estimate_response_info = CostEstimateResponseInfo(
            providerInfo=provider_info,
            coverage=coverage,
            cost=cost,
            healthClaimLine=health_claim_line,
            accumulators=accumulators,
        )
        return cost_estimate_response_info

    @classmethod
    def build_cost_estimator_response_from_info_objects(
        cls,
        cost_estimator_request: CostEstimatorRequest,
        cost_estimate_response_info_list: List[
            Union[CostEstimateResponseInfo, CostEstimateResponseInfoError]
        ],
    ) -> "CostEstimatorResponse":
        """
        Build a CostEstimatorResponse with the provided details.
        """
        service = cost_estimator_request.service
        cost_estimate_response = CostEstimateResponse(
            service=service,
            costEstimateResponseInfo=cost_estimate_response_info_list,
        )
        return CostEstimatorResponse(costEstimateResponse=cost_estimate_response)

    @classmethod
    def select_benefit(
        cls,
        selected_benefits: List[SelectedBenefit],
        insuranceContext: InsuranceContext,
    ) -> Optional[SelectedBenefit]:
        # Filter benefits by matching benefit code with insurance context
        matching_benefits = [
            benefit
            for benefit in selected_benefits
            if str(benefit.benefitCode) == insuranceContext.benefit_id
        ]

        # If no matching benefits found, return the first benefit or None

        if not matching_benefits:
            return selected_benefits[0] if selected_benefits else None

        # For now, return the first matching benefit since we can't calculate member_pays here
        # The actual member_pays calculation happens in the calculation service
        return matching_benefits[0]

    @classmethod
    def build_accumulator(
        cls, accumulators: List, insuranceContext: InsuranceContext, rateType: str
    ) -> List[AccumulatorInfo]:

        result = []
        for acc in accumulators:
            code = acc.code.lower()
            level = acc.level.lower()
            limit_type = acc.limitType or ""

            if acc.code.lower() not in ["oop max", "deductible"]:
                accumulator = AccumulatorWithLimitType(
                    code=acc.code,
                    level=acc.level,
                    limitValue=acc.limitValue,
                    limitType=acc.limitType or "",
                    calculatedValue=acc.calculatedValue,
                )
            else:
                accumulator = Accumulator(
                    code=acc.code,
                    level=acc.level,
                    limitValue=acc.limitValue,
                    currentValue=acc.currentValue,
                    calculatedValue=acc.calculatedValue,
                )

            # Mapping for accumulator calculation logic
            remaining = 0.0
            applied = 0.0
            applied_type = None

            if code not in ["oop max", "deductible"]:
                # Note: "dollaer" typo is preserved for backward compatibility
                if rateType == RATE_TYPE_AMOUNT:
                    remaining = insuranceContext.limit_calculated or 0.0
                else:
                    remaining = acc.calculatedValue
                applied = round(acc.calculatedValue - remaining, 2)
                applied_type = (
                    limit_type if limit_type.lower() in ("counter") else "AMOUNT"
                )
            elif code == "deductible":
                if level == "individual":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = (
                            insuranceContext.deductible_individual_calculated or 0.0
                        )
                    else:
                        remaining = acc.calculatedValue
                    applied = round(acc.calculatedValue - remaining, 2)
                elif level == "family":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = insuranceContext.deductible_family_calculated or 0.0
                    else:
                        remaining = acc.calculatedValue
                    applied = round(acc.calculatedValue - remaining, 2)
                applied_type = None
            elif code == "oop max":
                if level == "individual":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = insuranceContext.oopmax_individual_calculated or 0.0
                    else:
                        remaining = acc.calculatedValue
                    applied = round(acc.calculatedValue - remaining, 2)

                elif level == "family":
                    if rateType == RATE_TYPE_AMOUNT:
                        remaining = insuranceContext.oopmax_family_calculated or 0.0
                    else:
                        remaining = acc.calculatedValue
                    applied = round(acc.calculatedValue - remaining, 2)
                applied_type = None
            else:
                # Skip unknown accumulator types
                continue
            if code not in ["oop max", "deductible"]:
                accumulator_calc = AccumulatorCalculationWithType(
                    remainingValue=round(remaining, 2),
                    appliedValue=applied,
                    appliedValueType=str(applied_type),
                )
            else:
                accumulator_calc = AccumulatorCalculationWithType(
                    remainingValue=round(remaining, 2),
                    appliedValue=applied,
                    appliedValueType="AMOUNT",
                )
            result.append(
                AccumulatorInfo(
                    accumulator=accumulator,
                    accumulatorCalculation=accumulator_calc,
                )
            )
        return result
