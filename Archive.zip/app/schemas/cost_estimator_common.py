from typing import Annotated, Optional
from pydantic import BaseModel, Field


class SupportingService(BaseModel):
    code: Optional[str] = ""
    type: Optional[str] = ""


class Modifier(BaseModel):
    modifierCode: Optional[str] = ""


class PlaceOfService(BaseModel):
    code: Annotated[str, Field(..., description="Place of service code", min_length=1)]


class Service(BaseModel):
    code: Annotated[
        str, Field(..., description="Service code (e.g., 99214)", min_length=1)
    ]
    type: Annotated[
        str, Field(..., description="Service type (e.g., CPT4)", min_length=1)
    ]
    description: Optional[str] = ""
    supportingService: SupportingService
    modifier: Modifier
    diagnosisCode: Optional[str] = ""
    placeOfService: PlaceOfService


class Speciality(BaseModel):
    code: Annotated[str, Field(..., json_schema_extra={"examples": ["91017"]})]


class ProviderNetworks(BaseModel):
    networkID: Annotated[str, Field(..., description="Network ID", min_length=1)]


class ProviderNetworkParticipation(BaseModel):
    providerTier: Optional[str] = ""


class ProviderInfo(BaseModel):
    serviceLocation: Annotated[
        str, Field(..., description="Service location code", min_length=1)
    ]
    providerType: Optional[str] = ""
    speciality: Speciality = Speciality(code="")
    taxIdentificationNumber: Optional[str] = ""
    taxIdQualifier: Optional[str] = ""
    providerNetworks: ProviderNetworks
    providerIdentificationNumber: Annotated[
        str, Field(..., description="Provider identification number", min_length=1)
    ]
    nationalProviderId: Optional[str] = ""
    providerNetworkParticipation: ProviderNetworkParticipation = (
        ProviderNetworkParticipation()
    )

    def hash(self):
        return "-".join(
            [
                self.providerType or "",
                self.serviceLocation,
                self.speciality.code,
                self.providerNetworks.networkID,
                self.providerIdentificationNumber,
            ]
        )
