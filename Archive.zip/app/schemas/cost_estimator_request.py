from typing import Annotated
from typing import List, Optional
from pydantic import BaseModel, Field

from app.schemas.cost_estimator_common import Service, ProviderInfo


class CostEstimatorRequest(BaseModel):
    membershipId: Annotated[str, Field(..., description="Membership ID", min_length=1)]
    zipCode: Optional[str] = ""
    benefitProductType: Optional[str] = ""
    languageCode: Optional[str] = ""
    service: Service
    providerInfo: Optional[List[ProviderInfo]]  # None iff OON
