from pydantic import BaseModel
from typing import Optional


class Modifier(BaseModel):
    code: Optional[str] = ""


class SupportingServiceCodes(BaseModel):
    code: Optional[str] = ""
    type: Optional[str] = ""


class PlaceOfService(BaseModel):
    code: str


class ProviderType(BaseModel):
    code: Optional[str] = ""


class ProviderSpecialty(BaseModel):
    code: Optional[str] = ""
