from app.core.base import Handler, InsuranceContext
from typing import Optional


class DeductibleCoInsuranceHandler(Handler):
    """Determines any member co-insurance"""

    def process(self, context):

        if not context.cost_share_coinsurance > 0:
            context.trace_decision("Process", "The co-insurance is zero", True)
            return self._apply_member_pays_no_co_insurance(context)

        if not context.coins_applies_oop:
            context.trace_decision(
                "Process", "The co-insurance amount does not apply to OOP", True
            )
            return self._apply_member_pays_co_insurance_and_not_applied_to_oopmax(
                context
            )

        # TODO: Add the Code and Level checks: code and level are added to the context

        if (
            "oopmax" in context.accum_code
            and "oopmax_family" in context.accum_level
            and context.oopmax_family_calculated == 0
        ):
            context.trace_decision(
                "Process",
                "Benefit code contains 'oopmax' and benefit level is 'family'",
                True,
            )
            return self._apply_member_family_oopmax_met(context)
        if (
            "oopmax" in context.accum_code
            and "oopmax_individual" in context.accum_level
            and context.oopmax_individual_calculated == 0
        ):
            context.trace_decision("Process", "The individual OOPMax is zero", True)
            return self._apply_member_individual_oopmax_met(context)
        min_oopmax = self._calculate_min_oopmax(context)
        # co insurance is a percentage. 20.0 is 20%
        if (
            context.cost_share_coinsurance > 0
            and round(
                ((context.cost_share_coinsurance / 100) * context.service_amount), 2
            )
            < context.service_amount
        ):
            # TODO: Do we need to check the level and code here?
            if (
                min_oopmax is not None
                and round(((context.cost_share_coinsurance / 100) * context.service_amount), 2)> min_oopmax
            ):
                context.trace_decision(
                    "Process",
                    "The co-insurance amount is less than the individual and family OOPMax",
                    False,
                )
                return self._apply_member_pays_oopmax_difference(context)
            else:
                context.trace_decision(
                    "Process",
                    "The co-insurance amount is less than the individual and family OOPMax",
                    True,
                )

                return self._apply_member_pays_co_insurance_and_applied_to_oopmax(
                    context
                )
        else:
            context.trace_decision(
                "Process",
                "The co-insurance amount can never be greater than the service amount",
                True,
            )
            context.calculation_complete = True
            return context

    def _calculate_min_oopmax(self, context: InsuranceContext) -> Optional[float]:
        """Calculate minimum OOP max value handling None cases properly"""
        if (
            context.oopmax_individual_calculated is not None
            and context.oopmax_family_calculated is not None
        ):
            # Both exist: use minimum
            return min(
                context.oopmax_individual_calculated, context.oopmax_family_calculated
            )
        elif context.oopmax_individual_calculated is not None:
            # Only individual exists: use individual
            return context.oopmax_individual_calculated
        elif context.oopmax_family_calculated is not None:
            # Only family exists: use family
            return context.oopmax_family_calculated
        else:
            # Both are None: return None
            return None

    def _apply_member_pays_no_co_insurance(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays no co-insurance. No other cost sharing"""

        # Nothing to update
        context.calculation_complete = True

        context.trace("_apply_member_pays_no_co_insurance", "Logic applied")

        return context

    def _apply_member_pays_co_insurance_and_not_applied_to_oopmax(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays co-insurance amount. OOPMax will not be updated"""
        co_insurance_amount = round(
            ((context.cost_share_coinsurance / 100) * context.service_amount), 2
        )
        context.member_pays = context.member_pays + co_insurance_amount
        context.service_amount = context.service_amount - co_insurance_amount
        context.amount_coinsurance = co_insurance_amount
        context.calculation_complete = True

        context.trace(
            "_apply_member_pays_co_insurance_and_not_applied_to_oopmax", "Logic applied"
        )

        return context

    def _apply_member_family_oopmax_met(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Since OOPMax has been reached for family. No co-insurance applied"""

        context.calculation_complete = True

        context.trace("_apply_member_family_oopmax_met", "Logic applied")

        return context

    def _apply_member_individual_oopmax_met(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Since OOPMax has been reached for individual. No co-insurance applied"""

        context.calculation_complete = True

        context.trace("_apply_member_individual_oopmax_met", "Logic applied")

        return context

    def _apply_member_pays_co_insurance_and_applied_to_oopmax(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays co-insurance amount. OOPMax will be updated"""
        co_insurance_amount = round(
            ((context.cost_share_coinsurance / 100) * context.service_amount), 2
        )
        context.member_pays = context.member_pays + co_insurance_amount
        context.service_amount = context.service_amount - co_insurance_amount
        if context.oopmax_individual_calculated is not None:
            context.oopmax_individual_calculated -= co_insurance_amount
        if context.oopmax_family_calculated is not None:
            context.oopmax_family_calculated -= co_insurance_amount
        context.amount_coinsurance = co_insurance_amount
        context.calculation_complete = True
        context.trace(
            "_apply_member_pays_co_insurance_and_applied_to_oopmax", "Logic applied"
        )

        return context

    def _apply_member_pays_oopmax_difference(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays oopmax difference"""
        if (
            context.oopmax_individual_calculated is not None
            and context.oopmax_family_calculated is not None
        ):
            min_oopmax = min(
                context.oopmax_individual_calculated, context.oopmax_family_calculated
            )
        elif context.oopmax_individual_calculated is not None:
            min_oopmax = context.oopmax_individual_calculated
        elif context.oopmax_family_calculated is not None:
            min_oopmax = context.oopmax_family_calculated
        else:
            context.calculation_complete = True
            return context
        context.member_pays = context.member_pays + min_oopmax
        context.service_amount = context.service_amount - min_oopmax
        if context.oopmax_family_calculated is not None:
            context.oopmax_family_calculated -= min_oopmax
        if context.oopmax_individual_calculated is not None:
            context.oopmax_individual_calculated -= min_oopmax
        context.amount_coinsurance = min_oopmax
        context.calculation_complete = True
        context.trace("_apply_member_pays_oopmax_difference", "Logic applied")

        return context
