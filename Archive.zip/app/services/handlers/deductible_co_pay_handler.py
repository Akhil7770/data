from app.core.base import Handler, InsuranceContext
from typing import Optional


class DeductibleCoPayHandler(Handler):
    """Handles the member co-pay"""

    def set_deductible_oopmax_handler(self, handler):
        self._deductible_oopmax_handler = handler
        return handler

    def set_oopmax_copay_handler(self, handler):
        self._oopmax_co_pay_handler = handler
        return handler

    def set_deductible_co_insurance_handler(self, handler):
        self._deductible_co_insurance_handler = handler
        return handler

    def process(self, context):
        min_oopmax = self._calculate_min_oopmax(context)
        # If OOPMax Family is zero, then member pays no co-pay and go to co-insurance
        if (
            "oopmax" in context.accum_code
            and "oopmax_family" in context.accum_level
            and context.oopmax_family_calculated == 0
        ):
            context.trace_decision("Process", "The family OOPMax is zero", True)
            return self._apply_member_pays_no_co_pay(context)

        # If OOPMax Individual is zero, then member pays no co-pay and go to co-insurance
        if (
            "oopmax" in context.accum_code
            and "oopmax_individual" in context.accum_level
            and context.oopmax_individual_calculated == 0
        ):
            context.trace_decision("Process", "The individual OOPMax is zero", True)
            return self._apply_member_pays_no_co_pay(context)

        # If co-pay does not apply to OOP then member pays lesser of the remaining amount and cost share co-pay
        if not context.copay_applies_oop:
            context.trace_decision("Process", "Co-pay is not applied to OOP", False)
            if context.cost_share_copay > context.service_amount:
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is greater than the service amount",
                    True,
                )
                return self._apply_member_pays_remaining_service_amount(context)
            else:
                # Member pays cost share co-pay amount and its not applied to individual/family OOPMax
                # Co-insurance is applied on the difference between remaining service amount - cost share co-pay amount
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is greater than the service amount",
                    False,
                )
                context = self._apply_member_pays_co_pay_and_oopmax_not_updated(context)

                if context.is_deductible_before_copay:
                    return self._deductible_co_insurance_handler.handle(context)
                else:
                    if context.copay_count_to_deductible:
                        context = self._apply_costshare_copay_deductible(context)
                        return self._deductible_oopmax_handler.handle(context)
                    else:
                        return self._deductible_oopmax_handler.handle(context)

        else:  # co-pay applies to OOP
            # Member pays lessor between service amount and co-pay
            if context.cost_share_copay > context.service_amount:
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is greater than the service amount",
                    True,
                )
                if min_oopmax is not None and context.service_amount > min_oopmax:
                        context = (
                            self._apply_member_pays_lesser_of_oopmax_oopmax_met_indicator(
                                context
                            )
                        )
                        return self._oopmax_co_pay_handler.handle(context)
                else:
                    return self._apply_member_pays_remaining_service_amount_and_oopmax_updated(context)

            else:
                context.trace_decision(
                    "Process",
                    "The cost share co-pay is less than the service amount",
                    False,
                )
                if min_oopmax is not None and context.cost_share_copay > min_oopmax:
                    context = (
                        self._apply_member_pays_lesser_of_oopmax_oopmax_met_indicator(
                            context
                        )
                    )
                    return self._oopmax_co_pay_handler.handle(context)
                else:
                    context = self._apply_member_pays_co_pay_and_oopmax_updated(context)

                    if context.is_deductible_before_copay:
                        return self._deductible_co_insurance_handler.handle(context)
                    else:
                        if context.copay_count_to_deductible:
                            context = self._apply_costshare_copay_deductible(context)
                            return self._deductible_oopmax_handler.handle(context)
                        else:
                            return self._deductible_oopmax_handler.handle(context)

    def _apply_member_pays_remaining_service_amount(
        self, context: InsuranceContext
    ) -> InsuranceContext:  # done tested
        """Member pays remaining service amount and its not applied to individual/family OOPMax"""

        context.member_pays = context.member_pays + context.service_amount
        context.amount_copay = context.amount_copay + context.service_amount
        context.cost_share_copay = context.cost_share_copay - context.service_amount
        context.service_amount = 0.0
        context.calculation_complete = True

        context.trace("_apply_member_pays_remaining_service_amount", "Logic applied")

        return context

    def _apply_member_pays_no_co_pay(
        self, context: InsuranceContext
    ) -> InsuranceContext:
        """Member pays no co-pay. No other cost sharing"""

        # context.member_pays = 0
        context.calculation_complete = True

        context.trace("_apply_member_pays_no_co_pay", "Logic applied")

        return context

    def _apply_member_pays_remaining_service_amount_and_oopmax_updated(
        self, context: InsuranceContext
    ) -> InsuranceContext:  # done tested
        """Member pays remaining service amount and individual/family OOPMax updated"""

        context.member_pays = context.member_pays + context.service_amount

        # Update OOPMax
        if context.oopmax_family_calculated is not None:
            context.oopmax_family_calculated -= context.service_amount
        if context.oopmax_individual_calculated is not None:
            context.oopmax_individual_calculated -= context.service_amount
        context.amount_copay = context.amount_copay + context.service_amount
        context.cost_share_copay = context.cost_share_copay - context.service_amount
        context.service_amount = 0.0

        context.trace(
            "_apply_member_pays_remaining_service_amount_and_oopmax_updated",
            "Logic applied",
        )
        context.calculation_complete = True
        return context

    def _apply_member_pays_co_pay_and_oopmax_updated(
        self, context: InsuranceContext
    ) -> InsuranceContext:  # done tested
        """Member pays co-pay amount and its applied to individual/family OOPMax updated"""

        context.member_pays = context.member_pays + context.cost_share_copay
        context.service_amount = context.service_amount - context.cost_share_copay

        context.amount_copay = context.cost_share_copay
        # Update OOPMax
        if context.oopmax_family_calculated is not None:
            context.oopmax_family_calculated -= context.cost_share_copay
        if context.oopmax_individual_calculated is not None:
            context.oopmax_individual_calculated -= context.cost_share_copay

        context.cost_share_copay = 0.0
        context.trace("_apply_member_pays_co_pay_and_oopmax_updated", "Logic applied")

        return context

    def _apply_member_pays_co_pay_and_oopmax_not_updated(
        self, context: InsuranceContext
    ) -> InsuranceContext:  # done tested
        """Member pays co-pay amount and its not applied to individual/family OOPMax updated"""

        context.member_pays = context.member_pays + context.cost_share_copay

        context.amount_copay = context.cost_share_copay

        # We need to subtract the co-pay amount from the service amount so co-insurance is calculated correctly
        context.service_amount = context.service_amount - context.cost_share_copay

        context.cost_share_copay = 0.0

        context.trace(
            "_apply_member_pays_co_pay_and_oopmax_not_updated", "Logic applied"
        )

        return context

    def _apply_member_pays_lesser_of_oopmax_oopmax_met_indicator(
        self, context: InsuranceContext
    ) -> InsuranceContext:  # done tested
        """Member pays lesser of the OOPMax and OOPMax is met"""
        min_oopmax = self._calculate_min_oopmax(context)

        if min_oopmax is not None:
            context.member_pays = context.member_pays + min_oopmax
            context.amount_copay = context.amount_copay + min_oopmax
            context.cost_share_copay = context.cost_share_copay - min_oopmax
            context.service_amount = context.service_amount - min_oopmax

            # Update both individual and family calculated values
            if context.oopmax_family_calculated is not None:
                context.oopmax_family_calculated = (
                    context.oopmax_family_calculated - min_oopmax
                )
            if context.oopmax_individual_calculated is not None:
                context.oopmax_individual_calculated = (
                    context.oopmax_individual_calculated - min_oopmax
                )
        else:
            # No OOP max values available, set calculation complete and return
            context.calculation_complete = True

        context.trace(
            "_apply_member_pays_lesser_of_oopmax_oopmax_met_indicator", "Logic applied"
        )

        return context

    def _apply_costshare_copay_deductible(
        self, context: InsuranceContext
    ) -> InsuranceContext:  # done tested
        """Apply cost share copay deductible"""
        if context.deductible_individual_calculated is not None:
            context.deductible_individual_calculated = (
                context.deductible_individual_calculated - context.amount_copay
            )
        if context.deductible_family_calculated is not None:
            context.deductible_family_calculated = (
                context.deductible_family_calculated - context.amount_copay
            )
        context.trace("_apply_costshare_copay_deductible", "Logic applied")
        return context

    def _calculate_min_oopmax(self, context: InsuranceContext) -> Optional[float]:
        """Calculate minimum OOP max value handling None cases properly"""
        if (
            context.oopmax_individual_calculated is not None
            and context.oopmax_family_calculated is not None
        ):
            # Both exist: use minimum
            return min(
                context.oopmax_individual_calculated, context.oopmax_family_calculated
            )
        elif context.oopmax_individual_calculated is not None:
            # Only individual exists: use individual
            return context.oopmax_individual_calculated
        elif context.oopmax_family_calculated is not None:
            # Only family exists: use family
            return context.oopmax_family_calculated
        else:
            # Both are None: return None
            return None
