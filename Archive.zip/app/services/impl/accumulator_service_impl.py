import os
import ssl
from typing import Dict, Optional, Any
import aiohttp
import xmltodict
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_not_exception_type,
)

from app.core import constants
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.core.logger import logger
from app.core.observability.metrics.metrics_decorators import response_time
from app.schemas.accumulator_request import AccumulatorRequestBuilder
from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.services.accumulator_service import (
    AccumulatorServiceInterface,
    AccumulatorResponse,
)
from app.services.impl.token_service_impl import TokenServiceImpl
from app.exception.exceptions import (
    AccumulatorNotFoundException,
    AccumulatorMemberNotFoundException,
)


class AccumulatorServiceImpl(AccumulatorServiceInterface):
    """Service implementation for handling accumulator-related operations."""

    def __init__(self):
        # Create SSL context that doesn't verify certificates
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.token_service = TokenServiceImpl()

    @circuit_breaker("accumulator_service")
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_not_exception_type(
            (
                AccumulatorNotFoundException,
                AccumulatorMemberNotFoundException,
                ValueError,
            )
        ),
    )
    @response_time("accumulator_api", "get_accumulator")
    async def get_accumulator(
        self,
        request: CostEstimatorRequest,
        token: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None,
    ) -> AccumulatorResponse:
        """
        Get accumulator information for the given request.

        Args:
            request (CostEstimatorRequest): The accumulator request object

        Returns:
            AccumulatorResponse: The accumulator response data

        Raises:
            AccumulatorNotFoundException: If the accumulator request fails
        """
        try:
            accumulator_url = os.getenv("ACCUMULATOR_URL")
            if not accumulator_url:
                raise ValueError("ACCUMULATOR_URL environment variable is not set")

            headers_data = {
                "Content-Type": "application/xml",
                "Authorization": f"Bearer {token['access_token']}",
                "app_name": constants.APP_NAME,
                "X-Eiecorrelationid": (headers or {}).get("x-eiecorrelationid", ""),
                "x-global-transaction-id": (headers or {}).get(
                    "x-global-transaction-id", ""
                ),
            }
            logger.info("Accumulator Request Headers: %s", headers_data)
            request_builder = AccumulatorRequestBuilder()
            xml_request = request_builder.build_xml_request(request, headers)
            connector = aiohttp.TCPConnector(ssl=self.ssl_context)
            async with aiohttp.ClientSession(connector=connector) as session:
                # First attempt
                async with session.post(
                    url=f"{accumulator_url}",
                    headers=headers_data,
                    data=xml_request,
                ) as response:
                    response_text = await response.text()
                    logger.info(f"AccumulatorService: Response text: {response_text}")
                    if (
                        response_text != ""
                        and response_text is not None
                        and "accumulatorsResponse" in response_text
                    ):
                        response_dict = xmltodict.parse(response_text)
                        response_dict = request_builder.remove_namespaces(response_dict)
                    else:
                        logger.error(f"Response text: {response_text}")
                        raise ValueError("Invalid response from accumulator service")
                    if (
                        type(response_dict) is dict
                        and "readAccumulatorsResponse"
                        not in response_dict["accumulatorsResponse"]
                    ):
                        if (
                            "MBR NOT FOUND"
                            in response_dict["accumulatorsResponse"]["status"][
                                "additionalStatus"
                            ]["detail"]
                        ):
                            raise AccumulatorMemberNotFoundException(
                                message=f"Status {response.status}: {response_dict['accumulatorsResponse']['status']['additionalStatus']['detail'].split(';')[0]}",
                            )
                        logger.error(f"Response text: {response_text}")
                        raise ValueError("Invalid response from accumulator service")

                    response_data = {"readAccumulatorsResponse": response_dict["accumulatorsResponse"]["readAccumulatorsResponse"]}  # type: ignore

                    if response.status == 400:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator request failed with status 400: "
                                f"{response_json.get('httpMessage', 'Bad Request')} - "
                                f"{response_json.get('moreInformation', 'Invalid request data')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator request failed with status 400: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )

                    if response.status == 500:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator service error with status 500: "
                                f"{response_json.get('httpMessage', 'Internal Server Error')} - "
                                f"{response_json.get('moreInformation', 'Service temporarily unavailable')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator service error with status 500: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )

                    if response.status != 200:
                        try:
                            response_json = await response.json()
                            error_msg = (
                                f"Accumulator request failed with status {response.status}: "
                                f"{response_json.get('httpMessage', 'Request failed')} - "
                                f"{response_json.get('moreInformation', 'Unknown error')}"
                            )
                        except Exception:
                            error_msg = f"Accumulator request failed with status {response.status}: {response_text}"
                        logger.error(error_msg)
                        raise AccumulatorNotFoundException(
                            message=f"Status {response.status}: {error_msg}",
                            accumulator_request=request.model_dump(),
                        )
                    # Success
                    accumulator_response = AccumulatorResponse(**response_data)

                    return accumulator_response

        except AccumulatorNotFoundException:
            raise
        except AccumulatorMemberNotFoundException:
            raise
        except Exception as e:
            logger.error(f"Unexpected error in get_accumulator: {str(e)}")
            raise e
