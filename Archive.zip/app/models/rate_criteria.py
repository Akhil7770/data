from dataclasses import dataclass
from typing import Optional


@dataclass
class CostEstimatorRateCriteria:
    """
    A data class representing the criteria used for cost estimation calculations.

    Attributes:
        providerIdentificationNumber: The provider identification number
        serviceCode: The service code identifier
        serviceType: The type of service being provided
        serviceLocationNumber: The location number where service is provided
        zipCode: The ZIP code of the service location
    """

    providerIdentificationNumber: str
    serviceCode: str
    serviceType: str
    serviceLocationNumber: str
    networkId: str
    placeOfService: str
    isOutofNetwork: bool
    zipCode: Optional[str] = ""
    providerSpecialtyCode: Optional[str] = ""
    providerType: Optional[str] = ""


@dataclass
class NegotiatedRate:
    paymentMethod: str
    rate: float
    rateType: str
    isRateFound: bool
    isProviderInfoFound: bool
