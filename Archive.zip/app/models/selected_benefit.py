from typing import List, Optional
from pydantic import BaseModel, Field

from app.schemas.accumulator_response import Accumulator
from app.schemas.benefit_response import BenefitTier, Prerequisite, ServiceProviderItem


class SelectedCoverage(BaseModel):
    sequenceNumber: int
    benefitDescription: Optional[str] = ""
    costShareCopay: float
    costShareCoinsurance: float
    copayAppliesOutOfPocket: Optional[str] = ""
    coinsAppliesOutOfPocket: Optional[str] = ""
    deductibleAppliesOutOfPocket: Optional[str] = ""
    deductibleAppliesOutOfPocketOtherIndicator: Optional[str] = ""
    copayCountToDeductibleIndicator: Optional[str] = ""
    copayContinueWhenDeductibleMetIndicator: Optional[str] = ""
    copayContinueWhenOutOfPocketMaxMetIndicator: Optional[str] = ""
    coinsuranceToOutOfPocketOtherIndicator: Optional[str] = ""
    copayToOutofPocketOtherIndicator: Optional[str] = ""
    isDeductibleBeforeCopay: Optional[str] = ""
    benefitLimitation: Optional[str] = ""
    isServiceCovered: str
    matchedAccumulators: List[Accumulator] = Field(default_factory=list)


class SelectedBenefit(BaseModel):
    benefitName: str
    benefitCode: int
    isInitialBenefit: Optional[str] = ""
    benefitTier: Optional[BenefitTier] = BenefitTier()
    networkCategory: str
    prerequisites: Optional[List[Prerequisite]] = []
    benefitProvider: Optional[str] = ""
    serviceProvider: Optional[List[ServiceProviderItem]] = []
    coverage: SelectedCoverage
