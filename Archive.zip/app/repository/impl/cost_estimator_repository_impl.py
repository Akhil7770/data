from typing import Any, Optional, List, Dict
from tenacity import retry, stop_after_attempt, wait_exponential
import pandas as pd
from pandas import DataFrame

from app.repository.cost_estimator_repository import CostEstimatorRepositoryInterface
from app.database.spanner_client import SpannerClient
from app.config.database_config import spanner_config
from app.config.queries import RATE_QUERIES
from app.core.logger import logger
from app.core.circuitbreaker.circuit_breaker import circuit_breaker
from app.models.rate_criteria import CostEstimatorRateCriteria, NegotiatedRate
from app.core.constants import (
    PERCENTAGE_PAYMENT_METHOD_CODES,
    PAYMENT_METHOD_HIERARCHY_CACHE_KEY,
    RATE_TYPE_PERCENTAGE,
    RATE_TYPE_AMOUNT,
    PCP_SPECIALTY_CODES_CACHE_KEY,
)
from app.core.observability import response_time
from app.core.base import Cache


class CostEstimatorRepositoryImpl(CostEstimatorRepositoryInterface):
    def __init__(self):
        """Initialize repository with Spanner client."""
        if not spanner_config.is_valid():
            raise ValueError(
                "Invalid Spanner configuration. Please check environment variables."
            )

        self.db = SpannerClient(
            project_id=spanner_config.project_id,
            instance_id=spanner_config.instance_id,
            database_id=spanner_config.database_id,
            max_workers=40,  # Increase for better parallelism
        )

        # Initialize cache as instance variable instead of on db object
        self._cache = Cache()

    @circuit_breaker("rate_repository")
    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    @response_time("spanner_rate_repository", "get_rate")
    async def get_rate(
        self, rate_criteria: CostEstimatorRateCriteria, *args, **kwargs
    ) -> NegotiatedRate:
        """
        Retrieve the rate based on network status and criteria.

        Args:
            is_out_of_network: Whether to get out-of-network rate
            rate_criteria: Criteria for rate lookup
            *args: Variable length argument list
            **kwargs: Arbitrary keyword arguments

        Returns:
            NegotiatedRate: The negotiated rate object
        """

        default_negotiated_rate = NegotiatedRate(
            paymentMethod="",
            rate=0.0,
            isRateFound=False,
            rateType="",
            isProviderInfoFound=False,
        )

        # Try out-of-network rate first
        if rate_criteria.isOutofNetwork:
            oon_params = self._build_oon_params(rate_criteria)
            out_of_network_result = await self._get_rate("out_of_network", oon_params)
            negotiated_rate = self._build_negotiated_rate(out_of_network_result)
            if negotiated_rate.isRateFound:
                return negotiated_rate
            else:
                logger.info(
                    "No out-of-network rate found, returning default negotiated rate"
                )
                return default_negotiated_rate

        else:  # Try claim-based rate next
            claims_params = self._build_claims_params(rate_criteria)
            claim_result = await self._get_rate("claim_based", claims_params)
            negotiated_rate = self._build_negotiated_rate(claim_result)
            if negotiated_rate.isRateFound:
                negotiated_rate.rateType = RATE_TYPE_AMOUNT
                return negotiated_rate
            else:
                logger.info(
                    "No claim-based rate found, proceeding to get provider info"
                )
                provider_params = self._build_provider_params(rate_criteria)
                provider_info_result = await self._get_provider_info(provider_params)
                rate_params = self._build_rate_params(
                    provider_info_result, rate_criteria
                )
                if rate_params and "contracttype" in rate_params:
                    contract_type = rate_params["contracttype"]
                    del rate_params["contracttype"]
                    if contract_type == "S":
                        del rate_params["providerbusinessgroupnbr"]
                        get_standard_rate = await self._get_rate(
                            "standard", rate_params
                        )
                        negotiated_rate = self._build_negotiated_rate(get_standard_rate)
                        return negotiated_rate

                    else:  # You need to get the rate from somewhere - this might need adjustment
                        get_non_standard_rate = await self._get_rate(
                            "non_standard", rate_params
                        )
                        negotiated_rate = self._build_negotiated_rate(
                            get_non_standard_rate
                        )
                        if negotiated_rate.isRateFound:
                            return negotiated_rate

                        else:
                            logger.info(
                                "No non-standard rate found, proceeding to use default rate query"
                            )
                            get_default_rate = await self._get_rate(
                                "default", rate_params
                            )
                            negotiated_rate = self._build_negotiated_rate(
                                get_default_rate
                            )
                            return negotiated_rate
                else:
                    logger.info(
                        "No provider info found, returning default negotiated rate"
                    )
                    return default_negotiated_rate

    def _get_pbg_with_highest_pbg_score(self, result: DataFrame) -> DataFrame:
        # Custom function to find maximum score because result can contain null values too
        result["PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()] = result[
            "PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()
        ].astype(float)
        max_score_value = result["PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()].max()

        # If the max score we got comes out to be None or NaN, return the result as it is. This will lead our code to find standard rate
        if self._value_is_null(max_score_value):
            logger.warning(
                "All the PROVIDER_BUSINESS_GROUP_SCORE_NBR values were NONE in the PROVIDER_INFO RESULT"
            )
            return result
        result = DataFrame(
            result[
                result["PROVIDER_BUSINESS_GROUP_SCORE_NBR".lower()] == max_score_value
            ]
        ).reset_index(
            drop=True
        )  # added DF init to hide typing error, even though it is not needed
        return result

    async def _get_provider_info(self, params: Dict[str, Any]) -> DataFrame:
        try:
            if "providerspecialtycode" in params:
                provider_info_query = RATE_QUERIES.get(
                    "get_provider_info_with_specialty_cd"
                )
            elif "providertype" in params:
                provider_info_query = RATE_QUERIES.get(
                    "get_provider_info_with_provider_type_cd"
                )
            else:
                provider_info_query = RATE_QUERIES.get("get_provider_info")
            if not provider_info_query:
                logger.error("get_provider_info not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(provider_info_query, params)

            if len(result) > 1:
                result = self._get_pbg_with_highest_pbg_score(result)

            return result
        except Exception as e:
            logger.error("Error in _get_provider_info: %s", str(e))
            return DataFrame()

    async def _get_rate(self, rate_type: str, params: Dict[str, Any]) -> DataFrame:
        if rate_type not in [
            "out_of_network",
            "claim_based",
            "standard",
            "non_standard",
            "default",
        ]:
            logger.error("Invalid rate type: %s", rate_type)
            return DataFrame()
        rate_str = "get_" + rate_type + "_rate"
        if rate_type == "default":
            query = self._select_rate_query("D", params)
        elif rate_type == "non_standard":
            query = self._select_rate_query("N", params)
        elif rate_type == "standard":
            query = self._select_rate_query("S", params)
        else:
            query = RATE_QUERIES.get(rate_str)
        try:
            if not query:
                logger.error(f"{rate_str} not found in RATE_QUERIES")
                return DataFrame()
            result = await self.db.execute_query(query, params)
            if rate_type in ["default", "non_standard"] and len(result) > 1:
                # If result has more than 1 payment method, use hierarchy to get best one
                result = await self._select_payment_method(result)
                return result
            else:
                return result
        except Exception as e:
            logger.error("Error in _get_rate for type %s: %s", rate_type, str(e))
            return DataFrame()

    def _select_rate_query(
        self, contract_type: str, params: Dict[str, Any]
    ) -> str | None:
        query = ""
        if contract_type == "N":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_non_standard_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_non_standard_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_non_standard_rate")
        elif contract_type == "D":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_default_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_default_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_default_rate")
        elif contract_type == "S":
            if "providerspecialtycode" in params:
                query = RATE_QUERIES.get("get_standard_rate_with_specialty_cd")
            elif "providertype" in params:
                query = RATE_QUERIES.get("get_standard_rate_with_provider_type_cd")
            else:
                query = RATE_QUERIES.get("get_standard_rate")
        return query

    def _select_rate_when_scores_are_equal(self, result: DataFrame) -> DataFrame:
        """
        Choose the best row from the list of rows with equal scores.
        """

        result["rate"] = result["rate"].astype(float)
        ind_Y = result[result["service_group_changed_ind"] == "Y"]
        if len(ind_Y) > 0:
            return DataFrame(ind_Y[ind_Y["rate"] == ind_Y["rate"].max()]).reset_index(
                drop=True
            )

        ind_N = result[result["service_group_changed_ind"] == "N"]
        if len(ind_N) > 0:
            # If there are multiple non-standard rates with the same priority, select the best one
            ind_N["service_grouping_priority_nbr"] = ind_N[
                "service_grouping_priority_nbr"
            ].astype(float)
            min_service_grouping_priority_nbr = ind_N[
                ind_N["service_grouping_priority_nbr"]
                == ind_N["service_grouping_priority_nbr"].min()
            ]
            return DataFrame(
                min_service_grouping_priority_nbr[
                    min_service_grouping_priority_nbr["rate"]
                    == min_service_grouping_priority_nbr["rate"].min()
                ]
            ).reset_index(drop=True)

        return DataFrame() if len(result) == 0 else result.head(1)

    async def _select_payment_method(self, result: DataFrame) -> DataFrame:

        if "payment_method_cd" not in result.columns:
            logger.error("payment_method_cd not found in result")
            return DataFrame()

        result["scored_rows"] = (
            result["payment_method_cd".lower()]
            .astype(str)
            .apply(self.get_cached_payment_method_score)
        ).astype(float)

        if all(result["scored_rows"].apply(self._value_is_null)):
            logger.warning("No valid payment methods found in cache hierarchy")
            return DataFrame()

        rows_with_highest_payment_method_score = DataFrame(
            result[result["scored_rows"] == result["scored_rows"].max()].drop(
                columns=["scored_rows"]
            )
        )

        if len(rows_with_highest_payment_method_score) > 1:
            return self._select_rate_when_scores_are_equal(
                rows_with_highest_payment_method_score
            )
        else:
            return rows_with_highest_payment_method_score

    def _build_negotiated_rate(self, result: DataFrame) -> NegotiatedRate:
        """
        Build a NegotiatedRate object from query result.
        """
        result.reset_index(drop=True, inplace=True)

        if (result is None or len(result) == 0) or (
            result["rate"][0] is None or result["rate"][0] == ""
        ):
            return NegotiatedRate(
                paymentMethod="",
                rate=0.0,
                isRateFound=False,
                rateType="",
                isProviderInfoFound=True,
            )

        rate = result["rate"][0]
        if "payment_method_cd" in result.columns:
            paymentMethod = str(result["payment_method_cd"][0]).strip()
        else:
            paymentMethod = ""
        # Determine rate type based on payment method
        if paymentMethod in PERCENTAGE_PAYMENT_METHOD_CODES:
            rateType = RATE_TYPE_PERCENTAGE
        else:
            rateType = RATE_TYPE_AMOUNT

        return NegotiatedRate(
            paymentMethod=paymentMethod,
            rate=float(rate),  # type: ignore
            isRateFound=True,
            rateType=rateType,
            isProviderInfoFound=True,
        )

    def _build_rate_params(
        self, provider_info_result: DataFrame, rate_criteria: CostEstimatorRateCriteria
    ) -> Dict[str, Any] | None:
        """
        Extract provider information and update query parameters.

        Args:
            result: Query result with format [{'PROVIDER_BUSINESS_GROUP_NBR': 'None', 'PRODUCT_CD': 'MHMO', 'RATING_SYSTEM_CD': 'REF', 'EPDB_GEOGRAPHIC_AREA_CD': 'MD01'}, ...]

        Returns:
            parameters dictionary with provider data, or None if no provider data found
        """
        if provider_info_result is None or len(provider_info_result) == 0:
            return None

        provider_info_result.reset_index(drop=True, inplace=True)

        params: Dict[str, Any] = {
            "servicecd": rate_criteria.serviceCode,
            "placeofservice": rate_criteria.placeOfService,
            "servicetype": rate_criteria.serviceType,
        }
        params.update(self._build_optional_provider_params(rate_criteria))

        # Get first row of provider data
        provider_business_group_nbr = provider_info_result[
            "PROVIDER_BUSINESS_GROUP_NBR".lower()
        ][0]
        product_cd = provider_info_result["PRODUCT_CD".lower()][0]
        rating_system_cd = provider_info_result["RATING_SYSTEM_CD".lower()][0]
        geographic_area_cd = provider_info_result["EPDB_GEOGRAPHIC_AREA_CD".lower()][0]

        if not any(
            [
                self._value_is_null(product_cd),
                self._value_is_null(rating_system_cd),
                self._value_is_null(geographic_area_cd),
            ]
        ):
            # Determine contract type based on provider_business_group_nbr
            if self._value_is_null(provider_business_group_nbr):
                contract_type = "S"
            else:
                contract_type = "N"
            contract_params = {
                "productcd": product_cd,  # Product Code
                "ratesystemcd": rating_system_cd,  # Rating System Code
                "geographicareacd": geographic_area_cd,  # Geographic Area Code
                "contracttype": contract_type,
            }
            params.update(contract_params)
        else:
            logger.info(
                "At least one of product_cd, rating_system_cd, geographic_area_cd is null, so not assigning contracttype"
            )

        params["providerbusinessgroupnbr"] = provider_info_result[
            "PROVIDER_BUSINESS_GROUP_NBR".lower()
        ].tolist()

        return params

    def _build_oon_params(
        self, rate_criteria: CostEstimatorRateCriteria
    ) -> Dict[str, Any]:
        return {
            "servicecd": rate_criteria.serviceCode,
            "placeofservice": rate_criteria.placeOfService,
            "servicetype": rate_criteria.serviceType,
            "zipcode": rate_criteria.zipCode,
        }

    def _build_claims_params(
        self, rate_criteria: CostEstimatorRateCriteria
    ) -> Dict[str, Any]:
        return {
            "servicecd": rate_criteria.serviceCode,
            "provideridentificationnumber": rate_criteria.providerIdentificationNumber,
            "placeofservice": rate_criteria.placeOfService,
            "servicetype": rate_criteria.serviceType,
            "networkid": rate_criteria.networkId,
            "servicelocationnumber": rate_criteria.serviceLocationNumber,
        }

    def _build_optional_provider_params(
        self, rate_criteria: CostEstimatorRateCriteria
    ) -> Dict[str, Any]:
        params = {}
        if (
            rate_criteria.providerSpecialtyCode
            and rate_criteria.providerSpecialtyCode != ""
        ):
            params["providerspecialtycode"] = rate_criteria.providerSpecialtyCode
        if rate_criteria.providerType and rate_criteria.providerType != "":
            params["providertype"] = rate_criteria.providerType
        return params

    def _build_provider_params(
        self, rate_criteria: CostEstimatorRateCriteria
    ) -> Dict[str, Any]:
        params = self._build_claims_params(rate_criteria)
        params.update(self._build_optional_provider_params(rate_criteria))
        return params

    def _value_is_null(self, value: Any) -> bool:
        return (
            value is None
            or pd.isnull(value)
            or value == ""
            or str(value).lower() in ["none", "nan", "null"]
        )

    async def load_payment_method_hierarchy(self) -> None:
        """Load payment method hierarchy from Spanner into cache, optimized to avoid unnecessary DB calls."""

        payment_info_query = RATE_QUERIES.get("get_payment_method_hierarchy")
        if not payment_info_query:
            logger.error("get_payment_method_hierarchy not found in RATE_QUERIES")
            return None
        try:
            result = await self.db.execute_query(payment_info_query)
            if "payment_method_cd" not in result.columns:
                logger.error("payment_method_cd not found in result")
                return None
            if "score" not in result.columns:
                logger.error("score not found in result")
                return None
            result_no_nulls = result[
                ~result["payment_method_cd"].apply(self._value_is_null)
            ][~result["score"].apply(self._value_is_null)]
            hierarchy = dict(
                zip(result_no_nulls["payment_method_cd"], result_no_nulls["score"])
            )
            self._cache.set(PAYMENT_METHOD_HIERARCHY_CACHE_KEY, hierarchy)
        except Exception as e:
            logger.error("Failed to load payment method hierarchy: %s", str(e))

    def get_cached_payment_method_score(self, payment_method_cd: str) -> Optional[int]:
        payment_method_score_dict = (
            self._cache.get(PAYMENT_METHOD_HIERARCHY_CACHE_KEY) or {}
        )
        payment_method_score = payment_method_score_dict.get(payment_method_cd)
        if self._value_is_null(payment_method_score):
            logger.warning(
                "Payment Method %s not found in hierarchy", payment_method_cd
            )
            return None
        return payment_method_score

    async def load_pcp_specialty_codes(self) -> None:
        query = "SELECT SPECIALTY_CODE FROM CET_PCP_SPECIALTY_CODE"
        try:
            result = await self.db.execute_query(query)
            self._cache.set(
                PCP_SPECIALTY_CODES_CACHE_KEY, result["SPECIALTY_CODE".lower()].tolist()
            )
        except Exception as e:
            logger.error("Failed to load pcp specialty codes: %s", str(e))

    def get_cached_pcp_specialty_codes(self) -> List[str]:
        return self._cache.get(PCP_SPECIALTY_CODES_CACHE_KEY) or []
