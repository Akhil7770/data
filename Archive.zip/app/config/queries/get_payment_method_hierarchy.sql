select payment_method_cd, score 
from payment_method_hierarchy;