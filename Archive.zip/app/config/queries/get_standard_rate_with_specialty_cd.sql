WITH base AS (
  SELECT RATE, SPECIALTY_CD
  FROM CET_RATES
  WHERE
    RATE_SYSTEM_CD = @ratesystemcd
    AND SERVICE_CD = @servicecd
    AND SERVICE_TYPE_CD = @servicetype
    AND GEOGRAPHIC_AREA_CD = @geographicareacd
    AND PLACE_OF_SERVICE_CD = @placeofservice
    AND PRODUCT_CD IN (@productcd, 'ALL')
    AND CONTRACT_TYPE = 'S'
),
flag AS (
  SELECT EXISTS (SELECT 1 FROM base WHERE SPECIALTY_CD = @providerspecialtycode) AS has_providerspecialtycode
)
SELECT MAX(b.RATE) AS RATE
FROM base b
CROSS JOIN flag f
WHERE b.SPECIALTY_CD = CASE WHEN f.has_providerspecialtycode THEN @providerspecialtycode ELSE '' END
