"""
OpenTelemetry Automatic Instrumentation Setup

This module sets up automatic instrumentation for aiohttp-client.
Assumes OpenTelemetry is always available in GCP environment.
"""

import os

# OpenTelemetry imports - assume always available in GCP
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.aiohttp_client import AioHttpClientInstrumentor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor  # type: ignore
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from app.core.logger import logger


def setup_automatic_instrumentation():
    """
    Set up automatic OpenTelemetry instrumentation for aiohttp-client.

    Assumes OpenTelemetry is always available in GCP environment.
    Environment variables are configured in values.yaml deployment file.
    """

    # Create resource with service information
    resource = Resource.create(
        {
            "service.name": os.getenv("OTEL_SERVICE_NAME", "APM0016344"),
            "service.version": "1.0.0",
            "deployment.environment": os.getenv("ENVIRONMENT", "unknown"),
        }
    )

    # Create tracer provider
    tracer_provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(tracer_provider)

    # Get endpoint and strip https:// prefix if present (gRPC doesn't use it)
    traces_endpoint = os.getenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "")
    logger.info(f"Traces endpoint: {traces_endpoint}")

    # Add :443 if no port specified
    if traces_endpoint and ":" not in traces_endpoint:
        traces_endpoint = f"{traces_endpoint}:443"
        logger.info(f"Added default port 443 to traces endpoint")

    # Create OTLP exporter
    # insecure=False means TLS is ENABLED (secure connection)
    # insecure=True means TLS is DISABLED (insecure connection)
    otlp_exporter = OTLPSpanExporter(
        endpoint=traces_endpoint,
        insecure=True,
    )

    logger.info(f"OTLP Trace Exporter configured: {traces_endpoint}")

    # Configure batch span processor with explicit export interval
    # Reduced default to 1 second to prevent "root span not yet received" issues in Tempo
    # This ensures traces appear faster and root spans export before child spans timeout
    export_interval_ms = int(os.getenv("OTEL_BSP_EXPORT_SCHEDULE_DELAY_MILLIS", "1000"))
    max_export_batch_size = int(os.getenv("OTEL_BSP_MAX_EXPORT_BATCH_SIZE", "512"))
    export_timeout_ms = int(os.getenv("OTEL_BSP_EXPORT_TIMEOUT_MILLIS", "30000"))

    # Add span processor with configured export interval
    span_processor = BatchSpanProcessor(
        otlp_exporter,
        schedule_delay_millis=export_interval_ms,
        max_export_batch_size=max_export_batch_size,
        export_timeout_millis=export_timeout_ms,
    )
    tracer_provider.add_span_processor(span_processor)

    # Store span processor reference for potential flushing (e.g., on shutdown)
    # This helps ensure all spans are exported even if the app shuts down quickly
    setup_automatic_instrumentation.span_processor = span_processor  # type: ignore

    logger.info(
        f"BatchSpanProcessor configured: export_interval={export_interval_ms}ms, "
        f"max_batch_size={max_export_batch_size}, timeout={export_timeout_ms}ms"
    )

    # Initialize aiohttp-client instrumentation (metrics will be set up in metrics module)
    AioHttpClientInstrumentor().instrument()

    logger.info("OpenTelemetry SDK initialized successfully")
    logger.info("Instrumented: aiohttp-client (FastAPI will be instrumented manually)")
    logger.info(
        f"Traces will be exported to: {os.getenv('OTEL_EXPORTER_OTLP_TRACES_ENDPOINT')}"
    )
