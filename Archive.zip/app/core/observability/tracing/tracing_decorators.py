"""
Simplified tracing decorators for capturing request/response data in OpenTelemetry traces.
"""

import functools
import json
import time
from typing import Any, Callable, Optional

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from app.core.logger import logger


def trace_request_response(
    span_name: Optional[str] = None,
    capture_request: bool = True,
    capture_response: bool = True,
    max_request_size: int = 1024,
    max_response_size: int = 1024,
    include_headers: bool = True,
    sensitive_fields: Optional[list] = None,
):
    """
    Simplified decorator to add request/response tracing to functions.
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = trace.get_tracer(__name__)
            span_name_final = span_name or f"{func.__module__}.{func.__name__}"

            with tracer.start_as_current_span(span_name_final) as span:
                start_time = time.time()

                try:
                    # Capture request data
                    if capture_request:
                        _capture_simple_request_data(
                            span, args, kwargs, include_headers, sensitive_fields
                        )

                        # Try to capture HTTP request details from FastAPI context
                        try:
                            from fastapi import Request
                            from starlette.requests import Request as StarletteRequest

                            # Look for Request object in kwargs
                            for key, value in kwargs.items():
                                if isinstance(value, (Request, StarletteRequest)):
                                    span.set_attribute("http.method", value.method)
                                    span.set_attribute("http.url", str(value.url))
                                    span.set_attribute("http.path", value.url.path)
                                    span.set_attribute(
                                        "http.query_params", str(value.query_params)
                                    )
                                    span.set_attribute(
                                        "http.client_ip",
                                        (
                                            value.client.host
                                            if hasattr(value, "client") and value.client
                                            else "unknown"
                                        ),
                                    )
                                    break
                        except Exception as e:
                            span.set_attribute("http.capture_error", str(e))

                    # Execute the function
                    result = await func(*args, **kwargs)

                    # Capture response data
                    if capture_response:
                        _capture_simple_response_data(span, result, max_response_size)

                    # Set span status to success
                    span.set_status(Status(StatusCode.OK))

                    # Set operation name for trace storage
                    # TODO: pass in the operation name
                    span.set_attribute("operation", "cost_estimation_request")

                    # Explicitly set service name as resource attribute
                    # TODO: pass in the service name
                    # TODO: Do we need to pass in the service version?
                    span.set_attribute("service.name", "cost-estimator-calc-service")

                    return result

                except Exception as e:
                    # Set span status to error
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.set_attribute("error.message", str(e))
                    span.set_attribute("error.type", type(e).__name__)
                    logger.error(f"Error in {span_name_final}: {e}")
                    raise

                finally:
                    # Add timing information
                    duration = time.time() - start_time
                    span.set_attribute(
                        "function.duration_ms", round(duration * 1000, 2)
                    )
                    span.set_attribute("function.name", func.__name__)
                    span.set_attribute("function.module", func.__module__)

        # Since all decorated functions are async, always return async_wrapper
        return async_wrapper

    return decorator


def _capture_simple_request_data(
    span: trace.Span,
    args: tuple,
    kwargs: dict,
    include_headers: bool,
    sensitive_fields: Optional[list] = None,
):
    """Simplified request data capture."""
    # Capture basic info
    span.set_attribute("request.num_args", len(args))
    span.set_attribute("request.num_kwargs", len(kwargs))

    # Look for CostEstimatorRequest in args and kwargs
    cost_estimator_request = None

    # Check args first
    for i, arg in enumerate(args):
        if hasattr(arg, "membershipId"):  # CostEstimatorRequest
            cost_estimator_request = arg
            break

    # Check kwargs if not found in args
    if not cost_estimator_request:
        for key, value in kwargs.items():
            if hasattr(value, "membershipId"):  # CostEstimatorRequest
                cost_estimator_request = value
                break

    # Capture individual request attributes
    if cost_estimator_request:
        span.set_attribute(
            "request.membership_id", str(cost_estimator_request.membershipId)
        )
        if hasattr(cost_estimator_request, "benefitProductType"):
            span.set_attribute(
                "request.benefit_product_type",
                str(cost_estimator_request.benefitProductType),
            )
        if (
            hasattr(cost_estimator_request, "providerInfo")
            and cost_estimator_request.providerInfo
        ):
            span.set_attribute(
                "request.num_providers", len(cost_estimator_request.providerInfo)
            )
        if hasattr(cost_estimator_request, "service") and hasattr(
            cost_estimator_request.service, "code"
        ):
            span.set_attribute(
                "request.service_code", str(cost_estimator_request.service.code)
            )

        # Capture full request body as JSON using Pydantic model serialization
        try:
            import json

            # Use Pydantic's model_dump() or dict() to get complete request with all fields
            if hasattr(cost_estimator_request, "model_dump"):
                # Pydantic v2 - include all fields including defaults and unset fields
                request_dict = cost_estimator_request.model_dump(
                    include=None,  # Include all fields
                    exclude=None,  # Exclude nothing
                    mode="json",  # Use JSON-compatible mode
                )
            elif hasattr(cost_estimator_request, "dict"):
                # Pydantic v1 - include all fields
                request_dict = cost_estimator_request.dict(
                    include=None,  # Include all fields
                    exclude=None,  # Exclude nothing
                )
            else:
                # Fallback to manual extraction if model_dump/dict not available
                request_dict = {
                    "membershipId": str(cost_estimator_request.membershipId),
                    "zipCode": (
                        str(cost_estimator_request.zipCode)
                        if hasattr(cost_estimator_request, "zipCode")
                        else ""
                    ),
                    "benefitProductType": (
                        str(cost_estimator_request.benefitProductType)
                        if hasattr(cost_estimator_request, "benefitProductType")
                        else ""
                    ),
                    "languageCode": (
                        str(cost_estimator_request.languageCode)
                        if hasattr(cost_estimator_request, "languageCode")
                        else ""
                    ),
                    "service": (
                        _simple_object_to_dict(cost_estimator_request.service)
                        if hasattr(cost_estimator_request, "service")
                        and cost_estimator_request.service
                        else None
                    ),
                    "providerInfo": (
                        [
                            _simple_object_to_dict(p)
                            for p in (cost_estimator_request.providerInfo or [])
                        ]
                        if hasattr(cost_estimator_request, "providerInfo")
                        and cost_estimator_request.providerInfo
                        else None
                    ),
                }

            # Store full request body - no truncation
            request_body_json = json.dumps(request_dict, default=str)
            span.set_attribute("request.body", request_body_json)
            # Store original size for reference
            span.set_attribute("request.body_size_bytes", len(request_body_json))
        except Exception as e:
            span.set_attribute("request.body_error", str(e))
            logger.warning(f"Error capturing full request body: {e}")

    # Capture headers if present
    if include_headers:
        headers_dict = {}

        # Priority 1: Check if headers were passed as a dictionary (most reliable)
        # This handles the case from app/api/v1/routes/requests.py where headers dict is explicitly passed
        if "headers" in kwargs and isinstance(kwargs["headers"], dict):
            headers_dict.update(kwargs["headers"])

        # Priority 2: Extract headers from Request object (FastAPI/Starlette) as fallback
        # This matches the implementation in app/api/v1/routes/requests.py
        try:
            from fastapi import Request
            from starlette.requests import Request as StarletteRequest

            # Look for Request object in args and kwargs
            request_obj = None
            for arg in args:
                if isinstance(arg, (Request, StarletteRequest)):
                    request_obj = arg
                    break

            if not request_obj:
                for value in kwargs.values():
                    if isinstance(value, (Request, StarletteRequest)):
                        request_obj = value
                        break

            # Extract headers from Request object (matching request handler implementation)
            if request_obj and hasattr(request_obj, "headers"):
                # Headers being extracted in the actual request handler
                header_keys = [
                    "x-eieusercontext",
                    "x-eieapplication",
                    "x-eieversion",
                    "x-apitransactionid",
                    "x-global-transaction-id",
                    "x-clientrefid",
                    "x-client-ref-id",
                    "content-type",
                ]

                for key in header_keys:
                    # Only add if not already present (headers dict takes precedence)
                    if key.lower() not in headers_dict:
                        # Headers are case-insensitive, try both lowercase and original
                        value = request_obj.headers.get(key) or request_obj.headers.get(
                            key.lower()
                        )
                        if value:
                            headers_dict[key.lower()] = value

        except Exception as e:
            logger.debug(f"Error extracting headers from Request object: {e}")

        if headers_dict:
            _capture_simple_headers(span, headers_dict, sensitive_fields)
            # Set global transaction ID as dedicated attribute for easy trace lookup
            if "x-global-transaction-id" in headers_dict:
                span.set_attribute(
                    "x.global.transaction.id", headers_dict["x-global-transaction-id"]
                )


def _capture_simple_response_data(span: trace.Span, result: Any, max_size: int):
    """
    Simplified response data capture.
    Note: max_size parameter is kept for API compatibility but truncation is NOT applied.
    Full response is always captured - OpenTelemetry backend will handle any size limits.
    """
    if result is None:
        span.set_attribute("response.type", "None")
        return

    result_type = type(result).__name__
    span.set_attribute("response.type", result_type)

    # Convert to dict and capture
    result_dict = _simple_object_to_dict(result)
    if result_dict:
        # Check for cost estimation response
        if "costEstimateResponseInfo" in result_dict:
            estimates = result_dict["costEstimateResponseInfo"]
            if isinstance(estimates, list):
                span.set_attribute("response.num_estimates", len(estimates))
                span.set_attribute("response.has_estimates", len(estimates) > 0)

        # Capture response body - store FULL value, NO truncation
        # Store full response in both attribute and span event
        # OpenTelemetry backend may truncate attributes if they exceed limits, but we don't pre-truncate
        try:
            result_json = json.dumps(result_dict, default=str)
            # Store original size for reference
            span.set_attribute("response.body_size_bytes", len(result_json))

            # Try to store full response in attribute (OpenTelemetry will handle truncation if needed)
            try:
                span.set_attribute("response.body", result_json)
            except Exception as attr_error:
                # If attribute fails, log but continue - we'll store in event
                logger.warning(
                    f"Failed to store full response in attribute ({len(result_json)} bytes): {attr_error}"
                )

            # Always store full response in span event (events typically have higher size limits)
            try:
                span.add_event(
                    name="response.body.full", attributes={"response.body": result_json}
                )
            except Exception as event_error:
                logger.warning(
                    f"Failed to store full response in span event ({len(result_json)} bytes): {event_error}"
                )

            # Log if size exceeds max_size (for monitoring)
            if len(result_json) > max_size:
                logger.debug(
                    f"Response body size ({len(result_json)} bytes) exceeds max_response_size ({max_size})"
                )
        except Exception as e:
            span.set_attribute("response.body_error", str(e))
            logger.warning(f"Error capturing full response body: {e}")


def _capture_simple_headers(
    span: trace.Span, headers: Any, sensitive_fields: Optional[list] = None
):
    """Enhanced header capture for comprehensive request tracing."""
    if not headers:
        span.set_attribute("request.headers_count", 0)
        return

    # Headers actually used in the application
    important_headers = [
        "content-type",
        "authorization",
        "x-global-transaction-id",
        # EIE headers (matching app/api/v1/routes/requests.py)
        "x-eieusercontext",
        "x-eieapplication",
        "x-eieversion",
        "x-apitransactionid",
    ]

    header_count = 0
    captured_headers = []

    # Handle different header types
    if hasattr(headers, "items"):
        # Dictionary-like headers
        for key, value in headers.items():
            if value is not None and str(value).strip():
                header_key = f"request.header.{key.lower().replace('-', '_')}"
                if sensitive_fields and any(
                    field in key.lower() for field in sensitive_fields
                ):
                    span.set_attribute(header_key, "[MASKED]")
                    captured_headers.append(f"{key}: [MASKED]")
                else:
                    # Store full header value - no truncation
                    header_value = str(value)
                    span.set_attribute(header_key, header_value)
                    # Store header size for reference
                    span.set_attribute(f"{header_key}_size_bytes", len(header_value))
                    captured_headers.append(f"{key}: {header_value}")
                header_count += 1
    elif hasattr(headers, "get"):
        # Headers object with get method
        for header in important_headers:
            value = headers.get(header)
            if value:
                header_key = f"request.header.{header.replace('-', '_')}"
                if sensitive_fields and any(
                    field in header.lower() for field in sensitive_fields
                ):
                    span.set_attribute(header_key, "[MASKED]")
                    captured_headers.append(f"{header}: [MASKED]")
                else:
                    # Store full header value - no truncation
                    header_value = str(value)
                    span.set_attribute(header_key, header_value)
                    # Store header size for reference
                    span.set_attribute(f"{header_key}_size_bytes", len(header_value))
                    captured_headers.append(f"{header}: {header_value}")
                header_count += 1

    # Set header count and summary
    span.set_attribute("request.headers_count", header_count)
    if captured_headers:
        span.set_attribute(
            "request.headers_summary", "; ".join(captured_headers[:10])
        )  # First 10 headers

    # Set global transaction ID as dedicated attribute for easy trace lookup
    # Check for global transaction ID (primary correlation header)
    global_txn_id = None
    if hasattr(headers, "get"):
        global_txn_id = headers.get("x-global-transaction-id") or headers.get(
            "X-Global-Transaction-Id"
        )
    elif hasattr(headers, "items"):
        for key, value in headers.items():
            if key.lower() in [
                "x-global-transaction-id",
                "x-global_transaction_id",
            ]:
                global_txn_id = value
                break

    if global_txn_id:
        span.set_attribute("x.global.transaction.id", str(global_txn_id))


def _simple_object_to_dict(obj: Any) -> Optional[dict]:
    """Simplified object to dictionary conversion."""
    if hasattr(obj, "model_dump"):  # Pydantic v2
        return obj.model_dump()
    elif hasattr(obj, "dict"):  # Pydantic v1
        return obj.dict()
    elif hasattr(obj, "__dict__"):
        return obj.__dict__
    else:
        return None
