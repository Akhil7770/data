"""
Unified Metrics Interface

This module provides a clean interface to OpenTelemetry metrics
while maintaining backward compatibility.
"""

# Import base functionality
from .base import (
    MetricLabels,
)

# Import decorators
from .metrics.metrics_decorators import (
    # API timing decorators
    response_time,
    # Exception tracking decorators
    exception_handler,
)

# Import OpenTelemetry metrics (only the ones actually used)
from .metrics.opentelemetry_metrics import (
    error_counter as otel_error_counter,
    response_time_histogram,
    exception_counter,
    request_counter,
)

# Prometheus metrics removed - using only OpenTelemetry


# Convenience aliases for backward compatibility
__all__ = [
    # Base classes
    "MetricLabels",
    # OpenTelemetry metrics
    "otel_error_counter",
    "response_time_histogram",
    "exception_counter",
    "request_counter",
    # Decorators
    "response_time",
    "exception_handler",
]
