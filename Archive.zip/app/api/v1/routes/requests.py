from typing import Dict

from fastapi import APIRouter, Depends

from app.core.logger import logger
from app.core.observability.tracing.tracing_decorators import trace_request_response
from app.core.service_factory import ServiceFactory
from app.exception.exception_handler import validate_required_headers
from app.schemas.cost_estimator_request import CostEstimatorRequest

service_factory = ServiceFactory()
cost_estimation_service = service_factory.cost_estimation_service()
router = APIRouter()


@router.post(
    "/rate",
    summary="Retrieve cost estimate for member",
    tags=["Cost Estimation"],
)
@trace_request_response(
    span_name="cost_estimation_endpoint",
    capture_request=True,
    capture_response=True,
    max_request_size=65536,  # 64KB - large enough for full headers and request body
    max_response_size=65536,  # 64KB - large enough for full response
    include_headers=True,
    sensitive_fields=[],
)
async def estimate_cost(
    request: CostEstimatorRequest,
    headers: Dict[str, str] = Depends(validate_required_headers),
):
    # Headers are validated by validate_required_headers dependency BEFORE this function runs (fail-fast)
    # If any header is missing or empty, RequestValidationError is raised and caught by validation_exception_handler
    # No processing occurs if validation fails

    logger.info(f"Request New Headers: {headers}")

    # Call the service to get the cost estimation
    response = await cost_estimation_service.estimate_cost(request, headers=headers)
    return response


@router.post(
    "/rate-only",
    summary="Retrieve rate only for member",
    tags=["Cost Estimation"],
)
async def get_rate_only(
    request: CostEstimatorRequest,
):
    response = await cost_estimation_service.get_rate_only(request)
    return response
