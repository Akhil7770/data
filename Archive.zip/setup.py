from setuptools import setup, find_packages

setup(
    name="cost-estimator-calc-service",
    version="0.1.0",
    description="Cost Estimator Calculation Service",
    author="Akhil Salla",
    author_email="akhil.salla3@aetna.com",
    packages=find_packages(include=["app", "app.*"]),
    install_requires=[
        "aiohttp",
        "pydantic",
        "fastapi",
        "uvicorn",
        "gunicorn",
        "tenacity",
        "circuitbreaker",
        "python-dotenv",
        "requests",
        "google-cloud-spanner",
        "sqlalchemy-spanner",
        "xmltodict",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
)
