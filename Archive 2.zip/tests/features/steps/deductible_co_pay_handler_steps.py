from behave import given, when, then  # type: ignore
from app.services.handlers.deductible_co_pay_handler import DeductibleCoPayHandler
from app.core.base import InsuranceContext


@given("an DeductibleCoPayHandler is created")
def step_create_deductible_co_pay_handler(context):
    """Create a DeductibleCoPayHandler with insurance context and mocked dependencies"""
    context.handler = DeductibleCoPayHandler()
    context.insurance_context = InsuranceContext()

    # Set up selected_benefit_of_highest_member_pay with coverage containing costShareCopay
    from unittest.mock import Mock

    coverage_mock = Mock()
    coverage_mock.costShareCopay = 0.0  # Will be updated when member co-pay is set

    benefit_mock = Mock()
    benefit_mock.coverage = coverage_mock

    context.insurance_context.selected_benefit_of_highest_member_pay = benefit_mock

    # Create a mock for the deductible handler
    mock_co_insurance_handler = Mock()
    mock_co_insurance_handler.return_value = context.insurance_context

    # Create mocked dependencies
    context.mock_deductible_co_insurance_handler = Mock()
    context.mock_deductible_oopmax_handler = Mock()
    context.mock_oopmax_copay_handler = Mock()

    # Configure mocked handlers to return the insurance context with calculation_complete set
    def mock_co_insurance_handler_handle(context):
        context.calculation_complete = True
        return context

    def mock_deductible_oopmax_handler_handle(context):
        context.calculation_complete = True
        return context

    def mock_oopmax_copay_handler_handle(context):
        context.calculation_complete = True
        return context

    context.mock_deductible_co_insurance_handler.handle.side_effect = (
        mock_co_insurance_handler_handle
    )
    context.mock_deductible_oopmax_handler.handle.side_effect = (
        mock_deductible_oopmax_handler_handle
    )
    context.mock_oopmax_copay_handler.handle.side_effect = (
        mock_oopmax_copay_handler_handle
    )

    # Set the mocked dependencies
    context.handler.set_deductible_co_insurance_handler(
        context.mock_deductible_co_insurance_handler
    )
    context.handler.set_deductible_oopmax_handler(
        context.mock_deductible_oopmax_handler
    )
    context.handler.set_oopmax_copay_handler(context.mock_oopmax_copay_handler)

    # Reset mock call counts for this scenario
    context.mock_deductible_co_insurance_handler.reset_mock()
    context.mock_deductible_oopmax_handler.reset_mock()
    context.mock_oopmax_copay_handler.reset_mock()


@given("the co-pay applies out of pocket {value}")
def step_copay_applies_out_of_pocket(context, value):
    """Set whether co-pay applies to out of pocket"""
    context.insurance_context.copay_applies_oop = value.lower() == "true"


@given("is deductible before copay {value}")
def step_deductible_before_copay(context, value):
    """Set whether deductible is before copay"""
    context.insurance_context.is_deductible_before_copay = value.lower() == "true"


@given("copay count to deductible is {value}")
def step_copay_count_to_deductible(context, value):
    """Set whether copay counts to deductible"""
    context.insurance_context.copay_count_to_deductible = value.lower() == "true"


@then("the individual deductible is updated to {amount}")
def step_individual_deductible_updated(context, amount):
    """Verify the individual deductible is updated to the expected amount"""
    expected_amount = float(amount)
    actual_amount = context.result.deductible_individual_calculated
    assert (
        actual_amount == expected_amount
    ), f"Expected individual deductible to be {expected_amount}, but it is {actual_amount}"


@then("the family deductible is updated to {amount}")
def step_family_deductible_updated(context, amount):
    """Verify the family deductible is updated to the expected amount"""
    expected_amount = float(amount)
    actual_amount = context.result.deductible_family_calculated
    assert (
        actual_amount == expected_amount
    ), f"Expected family deductible to be {expected_amount}, but it is {actual_amount}"


@then("the deductible oopmax handler is called")
def step_deductible_oopmax_handler_called(context):
    """Verify that the deductible oopmax handler was called"""
    print(
        f"\nDEBUG - Deductible OOPMax Handler Mock Call Count: {context.mock_deductible_oopmax_handler.handle.call_count}"
    )
    print(
        f"DEBUG - Deductible OOPMax Handler Mock Calls: {context.mock_deductible_oopmax_handler.handle.call_args_list}"
    )
    context.mock_deductible_oopmax_handler.handle.assert_called_once_with(
        context.insurance_context
    )
