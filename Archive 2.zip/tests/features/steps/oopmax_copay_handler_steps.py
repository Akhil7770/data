from behave import given, when, then  # type: ignore
from app.services.handlers.oopmax_co_pay_handler import OOPMaxCopayHandler
from app.core.base import InsuranceContext


@given("an OOPMaxCopayHandler is created")
def step_create_oopmax_copay_handler(context):
    context.handler = OOPMaxCopayHandler()
    context.insurance_context = InsuranceContext()


@given("the co-pay continues with OOPMax {cont}")
def step_copay_continues_with_oopmax(context, cont):
    context.insurance_context.copay_continue_when_oop_met = cont.lower() == "true"
