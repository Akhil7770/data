from unittest.mock import Mock
from behave import given, when, then  # type: ignore
from app.services.handlers.deductible_cost_share_co_pay import (
    DeductibleCostShareCoPayHandler,
)
from app.core.base import InsuranceContext


@given("a DeductibleCostShareCoPayHandler is created")
def step_impl(context):
    context.handler = DeductibleCostShareCoPayHandler()
    context.insurance_context = InsuranceContext()

    # Create a mock for the co-insurance handler
    mock_co_insurance_handler = Mock()

    # Configure the mock to return the insurance context when handle is called
    def mock_co_insurance_handle(context):
        print(f"DEBUG - Mock co-insurance handler called with context: {context}")
        context.calculation_complete = True
        return context

    mock_co_insurance_handler.handle.side_effect = mock_co_insurance_handle
    context.handler.set_deductible_co_insurance_handler(mock_co_insurance_handler)
    context.mock_co_insurance_handler = mock_co_insurance_handler

    # Create a mock for the co pay handler
    mock_cost_share_co_pay_handler = Mock()

    # Configure the mock to return the insurance context when handle is called
    def mock_co_pay_handle(context):
        print(f"DEBUG - Mock co-pay handler called with context: {context}")
        context.calculation_complete = True
        return context

    mock_cost_share_co_pay_handler.handle.side_effect = mock_co_pay_handle
    context.handler.set_deductible_co_pay_handler(mock_cost_share_co_pay_handler)
    context.mock_cost_share_co_pay_handler = mock_cost_share_co_pay_handler


@given("copay continue when deductible is met is {value}")
def step_copay_continue_when_deductible_met(context, value):
    """Set whether copay continues when deductible is met"""
    context.insurance_context.copay_continue_when_deductible_met = (
        value.lower() == "true"
    )


@then("the deductible co-pay handler is called")
def step_deductible_co_pay_handler_called(context):
    """Verify that the deductible co-pay handler was called"""
    print(
        f"DEBUG - Mock call count: {context.mock_cost_share_co_pay_handler.handle.call_count}"
    )
    print(
        f"DEBUG - Mock call args: {context.mock_cost_share_co_pay_handler.handle.call_args_list}"
    )
    context.mock_cost_share_co_pay_handler.handle.assert_called_once()


@then("the deductible co-insurance is called")
def step_deductible_co_insurance_called(context):
    """Verify that the deductible co-insurance handler was called"""
    print(
        f"DEBUG - Mock call count: {context.mock_co_insurance_handler.handle.call_count}"
    )
    print(
        f"DEBUG - Mock call args: {context.mock_co_insurance_handler.handle.call_args_list}"
    )
    context.mock_co_insurance_handler.handle.assert_called_once()
