from behave import given, when, then  # type: ignore
from unittest.mock import Mock
from app.services.handlers.oopmax_handler import OOPMaxHandler
from app.core.base import InsuranceContext


@given("an OOPMaxHandler is created")
def step_create_oopmax_handler(context):
    context.handler = OOPMaxHandler()
    context.insurance_context = InsuranceContext()

    # Create a mock for the deductible handler
    mock_deductible_handler = Mock()
    mock_deductible_handler.handle.return_value = context.insurance_context

    context.handler.set_deductible_handler(mock_deductible_handler)
    context.mock_deductible_handler = mock_deductible_handler

    # Create a mock for the oopmax co-pay handler
    mock_oopmax_copay_handler = Mock()
    mock_oopmax_copay_handler.handle.return_value = context.insurance_context

    context.handler.set_oopmax_copay_handler(mock_oopmax_copay_handler)
    context.mock_oopmax_copay_handler = mock_oopmax_copay_handler


@given("member has OOPMax {has_max}")
def step_member_has_oopmax(context, has_max):
    if has_max.lower() == "true":
        context.insurance_context.accum_code = ["oopmax"]
        context.insurance_context.accum_level = ["oopmax_family", "oopmax_individual"]
    else:
        context.insurance_context.accum_code = []
        context.insurance_context.accum_level = []


@given("the family OOPMax is {amount:d}")
def step_family_oopmax_amount(context, amount):
    context.insurance_context.oopmax_family_calculated = float(amount)


@given("the individual OOPMax is {amount:d}")
def step_individual_oopmax_amount(context, amount):
    context.insurance_context.oopmax_individual_calculated = float(amount)


@given("the individual OOPMax is None")
def step_individual_oopmax_none(context):
    context.insurance_context.oopmax_individual_calculated = None


@given("the family OOPMax is None")
def step_family_oopmax_none(context):
    context.insurance_context.oopmax_family_calculated = None


@then("the deductible is checked")
def step_deductible_checked(context):
    context.mock_deductible_handler.handle.assert_called_once_with(
        context.insurance_context
    )


@then("the oopmax co-pay is checked")
def step_oopmax_copay_checked(context):
    context.mock_oopmax_copay_handler.handle.assert_called_once_with(
        context.insurance_context
    )


@then("the oopmax calculation is passed to the next handler")
def step_oopmax_calculation_passed_to_next_handler(context):
    assert context.result is context.insurance_context
    # Verify no specific handlers were called
    context.mock_deductible_handler.handle.assert_not_called()
    context.mock_oopmax_copay_handler.handle.assert_not_called()
