import pytest
from unittest.mock import AsyncMock, patch
from app.repository.impl.cost_estimator_repository_impl import (
    CostEstimatorRepositoryImpl,
)
from app.models.rate_criteria import CostEstimatorRateCriteria
from app.models.rate_criteria import NegotiatedRate
from app.config.queries import RATE_QUERIES
import pandas as pd
from pandas import DataFrame


@pytest.fixture
def sample_rate_criteria():
    return CostEstimatorRateCriteria(
        serviceCode="99214",
        placeOfService="11",
        serviceType="CPT4",
        zipCode="85305",
        providerIdentificationNumber="0004000317",
        networkId="58921",
        serviceLocationNumber="000761071",
        isOutofNetwork=False,
        providerSpecialtyCode="91017",
        providerType="HO",
    )


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_claim_based_success(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.return_value = DataFrame(
        [{"rate": "250.00", "payment_method_cd": "FIXED"}]
    )
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 250.00
    assert result.paymentMethod == "FIXED"
    assert result.isRateFound == True
    assert result.rateType == "AMOUNT"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_all_na_fallback_to_na(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.side_effect = [
        DataFrame([]),  # Claim-based
        DataFrame([]),  # Provider Info
        DataFrame([]),  # Standard
    ]
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    repo.db = mock_client

    result = await repo.get_rate(sample_rate_criteria)
    assert isinstance(result, NegotiatedRate)
    assert result.paymentMethod == ""
    assert result.rate == 0.0
    assert not result.isRateFound
    assert result.rateType == ""

    # # Expect RateNotFoundException when no rate is found
    # from app.exception.exceptions import RateNotFoundException

    # with pytest.raises(RateNotFoundException) as exc_info:
    #     await repo.get_rate(sample_rate_criteria)

    # assert "Rate not found for the given parameters." in str(exc_info.value)


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_out_of_network_success(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    sample_rate_criteria.isOutofNetwork = True

    mock_client = AsyncMock()
    mock_client.execute_query.return_value = DataFrame(
        [{"rate": "300.00", "payment_method_cd": "PERBIL"}]
    )
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 300.00
    assert result.paymentMethod == "PERBIL"
    assert result.isRateFound == True
    assert result.rateType == "PERCENTAGE"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_rate_provider_info_to_standard_rate(
    mock_config, mock_client_class, sample_rate_criteria
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client.execute_query.side_effect = [
        DataFrame([]),  # Claim-based
        DataFrame(
            [
                {
                    "provider_business_group_nbr": "None",
                    "product_cd": "PROD1",
                    "rating_system_cd": "RS1",
                    "epdb_geographic_area_cd": "GA1",
                }
            ]
        ),  # Provider info -> contract_type = S
        DataFrame([{"rate": "200.00", "payment_method_cd": "FIXED"}]),  # Standard rate
    ]
    mock_client_class.return_value = mock_client
    repo = CostEstimatorRepositoryImpl()
    result = await repo.get_rate(sample_rate_criteria)

    assert isinstance(result, NegotiatedRate)
    assert result.rate == 200.00
    assert result.paymentMethod == "FIXED"
    assert result.isRateFound == True
    assert result.rateType == "AMOUNT"


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_provider_info(mock_config, mock_client_class):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()

    # Scenario 1: Different PROVIDER_BUSINESS_GROUP_SCORE_NBR values
    df = DataFrame(
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD1",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 200,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
        ]
    )
    df.columns = [col.lower() for col in df.columns]
    mock_client.execute_query.return_value = df
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, DataFrame)
    assert len(result) == 1
    assert result["provider_business_group_nbr"][0] == "PBG002"
    assert result["provider_business_group_score_nbr"][0] == 200

    # Scenario 2: Multiple records share the highest PROVIDER_BUSINESS_GROUP_SCORE_NBR
    df = DataFrame(
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD1",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 200,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 200,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD3",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS3",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
            },
        ]
    )
    df.columns = [col.lower() for col in df.columns]
    mock_client.execute_query.return_value = df
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, DataFrame)
    assert len(result) == 2
    assert (
        result["provider_business_group_nbr"][0] == "PBG003"
        and result["provider_business_group_nbr"][1] == "PBG004"
    )
    assert len(result[result["provider_business_group_score_nbr"] == 200]) == 2

    # Scenario 3: All have the same PROVIDER_BUSINESS_GROUP_SCORE_NBR
    df = DataFrame(
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD1",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 100,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD3",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS3",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
            },
        ]
    )
    df.columns = [col.lower() for col in df.columns]
    mock_client.execute_query.return_value = df
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, DataFrame)
    assert len(result) == 4
    assert (
        result["provider_business_group_nbr"][0] == "PBG001"
        and result["provider_business_group_nbr"][1] == "PBG002"
        and result["provider_business_group_nbr"][2] == "PBG003"
        and result["provider_business_group_nbr"][3] == "PBG004"
    )
    assert len(result[result["provider_business_group_score_nbr"] == 100]) == 4

    # Scenario 4: Some records have PROVIDER_BUSINESS_GROUP_SCORE_NBR as None
    df = DataFrame(
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD1",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 10,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": 7,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD3",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS3",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
            },
        ]
    )
    df.columns = [col.lower() for col in df.columns]
    mock_client.execute_query.return_value = df
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, DataFrame)
    assert len(result) == 1
    assert result["provider_business_group_nbr"][0] == "PBG003"
    assert result["provider_business_group_score_nbr"][0] == 10

    # Scenario 5:  All records have PROVIDER_BUSINESS_GROUP_SCORE_NBR as None
    df = DataFrame(
        [
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG001",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD1",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS1",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA1",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG002",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG003",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD2",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS2",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA2",
            },
            {
                "PROVIDER_BUSINESS_GROUP_NBR": "PBG004",
                "PROVIDER_BUSINESS_GROUP_SCORE_NBR": None,
                "PROVIDER_IDENTIFICATION_NBR": "0004000317",
                "PRODUCT_CD": "PROD3",
                "SERVICE_LOCATION_NBR": "000761071",
                "NETWORK_ID": "58921",
                "RATING_SYSTEM_CD": "RS3",
                "EPDB_GEOGRAPHIC_AREA_CD": "GA3",
            },
        ]
    )
    df.columns = [col.lower() for col in df.columns]
    mock_client.execute_query.return_value = df
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()
    params = {}

    result = await repo._get_provider_info(params)
    assert isinstance(result, DataFrame)
    assert len(result) == 4
    assert (
        result["provider_business_group_nbr"][0] == "PBG001"
        and result["provider_business_group_nbr"][1] == "PBG002"
        and result["provider_business_group_nbr"][2] == "PBG003"
        and result["provider_business_group_nbr"][3] == "PBG004"
    )
    assert all(
        result["provider_business_group_score_nbr"].apply(
            lambda x: x is None or pd.isna(x)  # TODO: check
        )
    )


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_select_payment_method(mock_config, mock_client_class):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()

    mock_client.execute_query.return_value = DataFrame(
        [
            {"payment_method_cd": "FIXED", "score": 10},
            {"payment_method_cd": "PERBIL", "score": 8},
            {"payment_method_cd": "PERCNT", "score": 6},
            {"payment_method_cd": "OTHER", "score": 4},
        ]
    )
    mock_client_class.return_value = mock_client
    repo = CostEstimatorRepositoryImpl()
    repo.db = mock_client

    await repo.load_payment_method_hierarchy()

    # Scenario 1: Only one record with service_group_changed_ind = N
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 5,
            "rate": 80.00,
        }
    ]
    result = await repo._select_payment_method(DataFrame(rows_obtained_from_cet_rates))
    assert result is not None
    assert len(result) == 1
    assert result["payment_method_cd"][0] == "FIXED"
    assert result["rate"][0] == 80.00
    assert result["service_group_changed_ind"][0] == "N"
    assert result["service_grouping_priority_nbr"][0] == 5

    # Scenario 2: Only one record with service_group_changed_ind = Y
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 3,
            "rate": 90.00,
        }
    ]
    result = await repo._select_payment_method(DataFrame(rows_obtained_from_cet_rates))
    assert result is not None
    assert len(result) == 1
    assert result["payment_method_cd"][0] == "FIXED"
    assert result["rate"][0] == 90.00
    assert result["service_group_changed_ind"][0] == "Y"

    # Scenario 3: All Rows have service_group_changed_ind as 'N' and different service_grouping_priority_nbr
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 1,
            "rate": 150.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 2,
            "rate": 120.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 1,
            "rate": 130.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 3,
            "rate": 110.00,
        },
    ]
    result = await repo._select_payment_method(DataFrame(rows_obtained_from_cet_rates))
    assert result is not None
    assert len(result) == 1
    assert result["payment_method_cd"][0] == "FIXED"
    assert result["rate"][0] == 150.00
    assert result["service_group_changed_ind"][0] == "N"
    assert result["service_grouping_priority_nbr"][0] == 1

    # Scenario 4: N-N with same service_grouping_priority_nbr but different rate
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 1,
            "rate": 150.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 2,
            "rate": 120.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 3,
            "rate": 130.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 4,
            "rate": 110.00,
        },
    ]
    result = await repo._select_payment_method(DataFrame(rows_obtained_from_cet_rates))
    assert result is not None
    assert len(result) == 1
    assert result["payment_method_cd"][0] == "FIXED"
    assert result["rate"][0] == 150.00
    assert result["service_group_changed_ind"][0] == "N"
    assert result["service_grouping_priority_nbr"][0] == 1

    # Scenario 5: Y-Y with different rate
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 4,
            "rate": 100.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 5,
            "rate": 110.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 1,
            "rate": 120.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 2,
            "rate": 130.00,
        },
    ]
    result = await repo._select_payment_method(DataFrame(rows_obtained_from_cet_rates))
    assert result is not None
    assert len(result) == 1
    assert result["payment_method_cd"][0] == "FIXED"
    assert result["rate"][0] == 130.00
    assert result["service_group_changed_ind"][0] == "Y"
    assert result["service_grouping_priority_nbr"][0] == 2

    # Scenario 6: Y-N Records
    rows_obtained_from_cet_rates = [
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 3,
            "rate": 140.00,
        },
        {
            "payment_method_cd": "PERBIL",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 2,
            "rate": 150.00,
        },
        {
            "payment_method_cd": "PERCNT",
            "service_group_changed_ind": "Y",
            "service_grouping_priority_nbr": 1,
            "rate": 160.00,
        },
        {
            "payment_method_cd": "FIXED",
            "service_group_changed_ind": "N",
            "service_grouping_priority_nbr": 4,
            "rate": 170.00,
        },
    ]
    result = await repo._select_payment_method(DataFrame(rows_obtained_from_cet_rates))
    assert result is not None
    assert len(result) == 1
    assert result["payment_method_cd"][0] == "FIXED"
    assert result["rate"][0] == 140.00
    assert result["service_group_changed_ind"][0] == "Y"
    assert result["service_grouping_priority_nbr"][0] == 3


# Predefined queries for comparison in tests
non_standard_query = RATE_QUERIES["get_non_standard_rate"]
non_standard_query_with_specialty_cd = RATE_QUERIES[
    "get_non_standard_rate_with_specialty_cd"
]
non_standard_query_with_provider_type_cd = RATE_QUERIES[
    "get_non_standard_rate_with_provider_type_cd"
]
default_rate = RATE_QUERIES["get_default_rate"]
default_rate_with_specialty_cd = RATE_QUERIES["get_default_rate_with_specialty_cd"]
default_rate_with_provider_type_cd = RATE_QUERIES[
    "get_default_rate_with_provider_type_cd"
]
standard_rate = RATE_QUERIES["get_standard_rate"]
standard_rate_with_specialty_cd = RATE_QUERIES["get_standard_rate_with_specialty_cd"]
standard_rate_with_provider_type_cd = RATE_QUERIES[
    "get_standard_rate_with_provider_type_cd"
]


def test_select_rate_query():

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is N or C
    params = {
        "providerspecialtycode": "91017",
        "providertype": "HO",
    }
    repo = CostEstimatorRepositoryImpl()
    modified_query = repo._select_rate_query("N", params)
    assert modified_query == non_standard_query_with_specialty_cd

    # Scenario-2: params has only providerspecialtycode and contract_type is N or C
    params = {
        "providerspecialtycode": "91017",
    }
    modified_query = repo._select_rate_query("N", params)
    assert modified_query == non_standard_query_with_specialty_cd

    # Scenario-3: params has only providertype
    params = {
        "providertype": "HO",
    }
    modified_query = repo._select_rate_query("N", params)
    assert modified_query == non_standard_query_with_provider_type_cd

    # Scenario-4: neither providerspecialtycode nor providertype in params and contract_type is N or C
    params = {}
    modified_query = repo._select_rate_query("N", params)
    assert modified_query == non_standard_query

    # Scenario-5: params has both providerspecialtycode and providertype but contract_type is D
    params = {
        "providerspecialtycode": "91017",
        "providertype": "HO",
    }
    modified_query = repo._select_rate_query("D", params)
    assert modified_query == default_rate_with_specialty_cd

    # Scenario-6: params has only providerspecialtycode and contract_type is D
    params = {
        "providerspecialtycode": "91017",
    }
    modified_query = repo._select_rate_query("D", params)
    assert modified_query == default_rate_with_specialty_cd

    # Scenario-7: params has only providertype and contract_type is D
    params = {
        "providertype": "HO",
    }
    modified_query = repo._select_rate_query("D", params)
    assert modified_query == default_rate_with_provider_type_cd

    # Scenario-8: neither providerspecialtycode nor providertype in params and contract_type is D
    params = {}
    modified_query = repo._select_rate_query("D", params)
    assert modified_query == default_rate

    # Scenario-9: params has both providerspecialtycode and providertype and contract_type is S
    params = {
        "providerspecialtycode": "91017",
        "providertype": "HO",
    }
    modified_query = repo._select_rate_query("S", params)
    assert modified_query == standard_rate_with_specialty_cd

    # Scenario-10: params has only providerspecialtycode and contract_type is S
    params = {
        "providerspecialtycode": "91017",
    }
    modified_query = repo._select_rate_query("S", params)
    assert modified_query == standard_rate_with_specialty_cd

    # Scenario-11: params has only providertype and contract_type is S
    params = {
        "providertype": "HO",
    }
    modified_query = repo._select_rate_query("S", params)
    assert modified_query == standard_rate_with_provider_type_cd

    # Scenario-12: neither providerspecialtycode nor providertype in params and contract_type is S
    params = {}
    modified_query = repo._select_rate_query("S", params)
    assert modified_query == standard_rate


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_non_standard_rate_query_execution_based_on_optional_parameters(
    mock_config, mock_client_class
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is N or C
    params = {"providerspecialtycode": "91017", "providertype": "HO"}
    result = await repo._get_rate("non_standard", params)

    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query_with_specialty_cd

    # Scenario-2: params has only providertype and contract_type is N or C
    params = {
        "providertype": "HO",
    }
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("non_standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query_with_provider_type_cd

    # Scenario-3: params has only providerspecialtycode and contract_type is N or C
    params = {
        "providerspecialtycode": "91017",
    }
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("non_standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query_with_specialty_cd

    # Scenario-4: params has neither providerspecialtycode nor providertype and contract_type is N or C
    params = {}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("non_standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == non_standard_query


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_default_rate_query_execution_based_on_optional_parameters(
    mock_config, mock_client_class
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is D
    params = {"providerspecialtycode": "91017", "providertype": "HO"}
    result = await repo._get_rate("default", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate_with_specialty_cd

    # Scenario-2: params has only providertype and contract_type is D
    params = {"providertype": "HO"}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("default", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate_with_provider_type_cd

    # Scenario-3: params has only providerspecialtycode and contract_type is D
    params = {"providerspecialtycode": "91017"}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("default", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate_with_specialty_cd

    # Scenario-4: params has neither providerspecialtycode nor providertype and contract_type is D
    params = {}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("default", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == default_rate


@pytest.mark.asyncio
@patch("app.repository.impl.cost_estimator_repository_impl.SpannerClient")
@patch("app.repository.impl.cost_estimator_repository_impl.spanner_config")
async def test_get_standard_rate_query_execution_based_on_optional_parameters(
    mock_config, mock_client_class
):
    mock_config.is_valid.return_value = True
    mock_client = AsyncMock()
    mock_client_class.return_value = mock_client

    repo = CostEstimatorRepositoryImpl()

    # Scenario-1: params has both providerspecialtycode and providertype and contract_type is S
    params = {"providerspecialtycode": "91017", "providertype": "HO"}
    result = await repo._get_rate("standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == standard_rate_with_specialty_cd

    # Scenario-2: params has only providertype and contract_type is S
    params = {"providertype": "HO"}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == standard_rate_with_provider_type_cd

    # Scenario-3: params has only providerspecialtycode and contract_type is S
    params = {"providerspecialtycode": "91017"}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == standard_rate_with_specialty_cd

    # Scenario-4: params has neither providerspecialtycode nor providertype and contract_type is S
    params = {}
    mock_client.execute_query.reset_mock()
    result = await repo._get_rate("standard", params)
    mock_client.execute_query.assert_awaited_once()
    executed_query = mock_client.execute_query.call_args[0][0]
    assert executed_query == standard_rate
