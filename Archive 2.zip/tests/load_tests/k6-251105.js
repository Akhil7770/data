import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

// Custom metrics
export const errorRate = new Rate('errors');
export const responseTime = new Trend('response_time');

// number of users to test
const numVUs = 250;

// Test configuration
export const options = {
  vus: numVUs,
  // number of iterations to run for each VU
  iterations: numVUs * 1, // Each VU will run x iterations
  // stages: [
    // { duration: '1m', target: 5, iterations: 2 },   // Ramp up to 100 users over 1 minute
    // { duration: '5m', target: 10 },    // Stay at 100 users for 5 minutes
    // { duration: '2m', target: 500 },   // Ramp up to 500 users over 2 minutes
    // { duration: '3m', target: 500 },    // Stay at 500 users for 3 minutes
    // { duration: '1m', target: 0 },   // Ramp down to 0 users over 2 minutes
  // ],
  thresholds: {
    http_req_duration: ['p(90)<15000'], // 90% of requests must complete below 15s (more lenient)
    http_req_failed: ['rate<0.5'],     // Error rate must be below 50% (more lenient)
    errors: ['rate<0.5'],              // Custom error rate must be below 50%
  },
};

// Test data
const BASE_URL = __ENV.BASE_URL || 'https://cost-estimator-calc-service.hcb-dev.aig.aetna.com/costestimator/v1';
// Sample test data for cost estimation requests


const LDAP_ID_PAIRS = [
  ["DMT-S-W266612075",	"5~266612075+10+1+20250801+793964+A+1"],
  ["DMT-S-W266612076",	"5~266612076+10+1+20250801+793964+A+1"],
  ["DMT-S-W266612077",	"5~266612077+10+1+20250801+793964+A+1"],
  ["DMT-S-W266612080",	"5~266612080+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612083",	"5~266612083+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612084",	"5~266612084+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612085",	"5~266612085+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612086",	"5~266612086+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612087",	"5~266612087+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612088",	"5~266612088+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612089",	"5~266612089+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612090",	"5~266612090+10+1+20250801+793964+A+1"],
  ["DMT-D-W266612091",	"5~266612091+10+1+20250801+793964+A+1"],
  ["DMT-S-W266613035",	"5~266613035+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613036",	"5~266613036+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613037",	"5~266613037+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613038",	"5~266613038+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613039",	"5~266613039+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613040",	"5~266613040+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613041",	"5~266613041+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613042",	"5~266613042+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613043",	"5~266613043+10+4+20250801+793709+D+1"],
  ["DMT-S-W266613080",	"5~266613080+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613081",	"5~266613081+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613082",	"5~266613082+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613083",	"5~266613083+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613084",	"5~266613084+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613085",	"5~266613085+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613086",	"5~266613086+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613087",	"5~266613087+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613088",	"5~266613088+10+4+20250801+793710+D+1"],
  ["DMT-S-W266613125",	"5~266613125+10+4+20250801+793711+D+1"],
  ["DMT-S-W266613126",	"5~266613126+10+4+20250801+793711+D+1"],
  ["DMT-S-W266613127",	"5~266613127+10+4+20250801+793711+D+1"],
  ["DMT-S-W266613128",	"5~266613128+10+4+20250801+793711+D+1"],
  ["DMT-S-W266613129",	"5~266613129+10+4+20250801+793711+D+1"],
  ["DMT-S-W266613130",	"5~266613130+10+4+20250801+793711+D+1"],
  ["DMT-S-W266614157",	"5~266614157+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614158",	"5~266614158+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614159",	"5~266614159+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614160",	"5~266614160+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614161",	"5~266614161+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614162",	"5~266614162+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614163",	"5~266614163+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614164",	"5~266614164+11+1+20250801+794312+A+1"],
  ["DMT-S-W266614165",	"5~266614165+11+1+20250801+794312+A+1"],
  ["DMT-D-W266612061",	"5~266612061+10+1+20250801+793960+A+1"],
  ["DMT-D-W266612062",	"5~266612062+10+1+20250801+793960+A+1"],
  ["DMT-S-W266612056",	"5~266612056+10+1+20250801+793960+A+1"],
  ["DMT-S-W266612057",	"5~266612057+10+1+20250801+793960+A+1"],
];

const requestData = {
  "membershipId": "",
  "zipCode": "11763",
  "benefitProductType": "Medical",
  "languageCode": "EN",
  "service": {
      "code": "99204",
      "type": "CPT4",
      "description": "",
      "supportingService": {
          "code": "",
          "type": ""
      },
      "modifier": {
          "modifierCode": ""
      },
      "diagnosisCode": "",
      "placeOfService": {
          "code": "11"
      }
  },
  "providerInfo": [
      {
          "serviceLocation": "3405523",
          "providerType": "PH",
          "speciality": {
              "code": "10303"
          },
          "taxIdentificationNumber": "",
          "taxIdQualifier": "",
          "providerNetworks": {
              "networkID": "00391"
          },
          "providerIdentificationNumber": "0009039731",
          "nationalProviderId": "1144495029",
          "providerNetworkParticipation": {
              "providerTier": ""
          }
      },
      {
          "serviceLocation": "3405523",
          "providerType": "PH",
          "speciality": {
              "code": "10301"
          },
          "taxIdentificationNumber": "",
          "taxIdQualifier": "",
          "providerNetworks": {
              "networkID": "00391"
          },
          "providerIdentificationNumber": "0009388303",
          "nationalProviderId": "1124267513",
          "providerNetworkParticipation": {
              "providerTier": ""
          }
      },
      {
          "serviceLocation": "3405523",
          "providerType": "MPG",
          "speciality": {
              "code": "10303"
          },
          "taxIdentificationNumber": "",
          "taxIdQualifier": "",
          "providerNetworks": {
              "networkID": "00391"
          },
          "providerIdentificationNumber": "0005484506",
          "nationalProviderId": "1821035601",
          "providerNetworkParticipation": {
              "providerTier": ""
          }
      },
      {
          "serviceLocation": "3405523",
          "providerType": "",
          "speciality": {
              "code": ""
          },
          "taxIdentificationNumber": "",
          "taxIdQualifier": "",
          "providerNetworks": {
              "networkID": "00391"
          },
          "providerIdentificationNumber": "0009516737",
          "nationalProviderId": "",
          "providerNetworkParticipation": {
              "providerTier": ""
          }
      },
      {
          "serviceLocation": "0151285",
          "providerType": "PAS",
          "speciality": {
              "code": "PAS"
          },
          "taxIdentificationNumber": "",
          "taxIdQualifier": "",
          "providerNetworks": {
              "networkID": "00391"
          },
          "providerIdentificationNumber": "0009209093",
          "nationalProviderId": "1982778916",
          "providerNetworkParticipation": {
              "providerTier": ""
          }
      }
  ]
};

// Helper function to generate request ID
function generateRequestId() {
  return `k6_test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function customLog(message) {
  var timestamp = new Date().toLocaleString(); // Or format as desired
  console.log(`[${timestamp}] ${message}`);
}
function customWarn(message) {
  var timestamp = new Date().toLocaleString();
  console.warn(`[${timestamp}] ${message}`);
}
function customError(message) {
  var timestamp = new Date().toLocaleString();
  console.error(`[${timestamp}] ${message}`);
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    // Generate a random index from 0 to i
    const j = Math.floor(Math.random() * (i + 1));

    // Swap elements at indices i and j
    const temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
  return array; // Return the shuffled array
}

// Setup function - runs once before all VUs
export function setup() {
  customLog('Starting k6 tests for Cost Estimator Calc Service API');
  customLog(`Base URL: ${BASE_URL}`);
  return { baseUrl: BASE_URL };
}

// Test 1: Health Check
function testHealthCheck(baseUrl) {
  const response = http.get(`${baseUrl}/health`);
  
  const statusOk = response.status === 200;
  const responseTimeOk = response.timings.duration < 2000; // More lenient timing
  let contentOk = false;
  
  try {
    const body = JSON.parse(response.body);
    contentOk = body.health === 'ok';
  } catch (e) {
    contentOk = false;
  }
  
  const success = statusOk && responseTimeOk && contentOk;
  
  const checksResult = check(response, {
    'health check status is 200': (r) => r.status === 200,
    'health check response time < 2000ms': (r) => r.timings.duration < 2000,
    'health check has correct content': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.health === 'ok';
      } catch (e) {
        return false;
      }
    }
  });
  
  if (!success) {
    customError(`Health check FAILED - Status: ${response.status}, Time: ${response.timings.duration}ms, Content: ${contentOk ? 'OK' : 'FAILED'} - ${response.body}`);
  } else {
    customLog(`Health check PASSED: ${response.timings.duration}ms`);
  }
  
  errorRate.add(!success);
  responseTime.add(response.timings.duration);
}

function testCostEstimationValid(baseUrl) {
  const requestId = generateRequestId();
  // const indices = shuffleArray(Array.from(Array(LDAP_ID_PAIRS.length).keys()));
  // just start at different points, and keep iterating
  const j = (__ITER + __VU - 1) % LDAP_ID_PAIRS.length;

  const ldap = LDAP_ID_PAIRS[j][0];
  // for (let i = 0; i < LDAP_ID_PAIRS.length; i++) {
    // let j = indices[i];
    requestData.membershipId = LDAP_ID_PAIRS[j][1];
    const usercontext = {"eieusercontext":{"LevelOfAssurance":{"assuranceType":"identity","assuranceValue":"http://consumer.aetna.com/assurance/loa-2"},"BusinessIdentifier":[{"businessIdentifierSource":"15","businessIdentifierValue":"MLPV6FFFFPXZ"}],"AuthorizedRole":[{"Role":"subscriber"},{"Role":"memberSubscriber1"}],"AccountIdentifier":{"accountIdentifierSource":"5","accountIdentifierValue":ldap,"accountIdentifierType":"accounts"},"dnAccountName":"CN="+ldap+",OU=Members,OU=External,DC=aetheq,DC=aetnaeq,DC=com"}} 
    const headers = {
      'Content-Type':'application/json',
      'x-apitransactionid':'int-0tqv2iczhpgub1fnubsd',
      'x-eieaction':'READ',
      'x-eieapplication':'{"eieapplication":{"idSource":108,"idValue":"6b1f1072-421b-485d-874b-fa439fd0c595","applicationShortName":"applications"}}',
      'x-eieusercontext': JSON.stringify(usercontext),
      'x-eieversion':'{"eieversion":{"major":3,"minor":0,"maintenance":0}}',
      'x-global-transaction-id': requestId,
    };

    const log_str = `\nVU ${__VU}; Member index: ${j};\nLDAP: ${ldap}; Member ID: ${requestData.membershipId};\nglobal transaction id: ${requestId}`;
    customLog(log_str);
    
    const response = http.post(`${baseUrl}/rate`, JSON.stringify(requestData), {
      headers: headers,
    });
    
    const success = check(response, {
      'cost estimation status is 200': (r) => r.status === 200,
      'cost estimation response time < 3000ms': (r) => r.timings.duration < 3000,
      'cost estimation has response structure': (r) => {
        try {
          const body = JSON.parse(r.body);
          return body.hasOwnProperty('costEstimateResponse');
        } catch (e) {
          return false;
        }
      },
      'cost estimation has service info': (r) => {
        try {
          const body = JSON.parse(r.body);
          return body.costEstimateResponse && body.costEstimateResponse.hasOwnProperty('service');
        } catch (e) {
          return false;
        }
      },
      'cost estimation has response info array': (r) => {
        try {
          const body = JSON.parse(r.body);
          return body.costEstimateResponse && 
                body.costEstimateResponse.hasOwnProperty('costEstimateResponseInfo') &&
                Array.isArray(body.costEstimateResponse.costEstimateResponseInfo);
        } catch (e) {
          return false;
        }
      }
    });
    
    if (!success) {
      const responseTime = response.timings.duration;
      const status = response.status;
      
      if (status === 200) {
        customError(`API working but SLOW for ${log_str}\n${responseTime}ms (should be <3000ms)`);
      } else {
        customError(`API ERROR for ${log_str}\n${status} - ${response.body}`);
      }
    } else {
      customLog(`Test PASSED for ${log_str}\n{response.timings.duration}ms`);
      
      // Log the actual response to see rates
      try {
        const responseBody = JSON.parse(response.body);
        if (responseBody.costEstimateResponse && responseBody.costEstimateResponse.costEstimateResponseInfo) {
          responseBody.costEstimateResponse.costEstimateResponseInfo.forEach((info, index) => {
            if (info.cost) {
              customLog(`Provider ${index + 1} - In-Network Cost: $${info.cost.inNetworkCosts} (${info.cost.inNetworkCostsType})`);
              if (info.healthClaimLine) {
                customLog(`  - Member Responsibility: $${info.healthClaimLine.amountResponsibility}`);
                customLog(`  - Copay: $${info.healthClaimLine.amountCopay}`);
                customLog(`  - Coinsurance: $${info.healthClaimLine.amountCoinsurance}`);
                customLog(`  - Amount Payable: $${info.healthClaimLine.amountpayable}`);
              }
            }
          });
        }
      } catch (e) {
        customLog(`Response parsing error for ${log_str}\n ${e.message}`);
      }
    }
    errorRate.add(!success);
    responseTime.add(response.timings.duration);
  // }

  
}


// Main test function
export default function(data) {
  const { baseUrl } = data;
  // testHealthCheck(baseUrl);
  testCostEstimationValid(baseUrl);
  sleep(1); // Wait 1 second between iterations
}


// Teardown function
export function teardown(data) {
  customLog('k6 tests completed for Cost Estimator Calc Service API');
}