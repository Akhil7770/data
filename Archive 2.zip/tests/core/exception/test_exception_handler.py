import pytest
import json
from unittest.mock import Mock, patch
from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.exception.exception_handler import (
    produce_response_content,
    validation_exception_handler,
    rate_not_found_exception_handler,
    rate_not_found_exception_handler_logic,
    benefits_not_found_exception_handler,
    benefits_not_found_exception_handler_logic,
    benefits_member_not_found_exception_handler,
    benefits_member_not_found_exception_handler_logic,
    benefits_not_matching_exception_handler,
    benefits_not_matching_exception_handler_logic,
    accumulator_not_found_exception_handler,
    accumulator_member_not_found_exception_handler,
    insurance_context_error_exception_handler,
    insurance_context_error_exception_handler_logic,
    validate_required_headers,
    generic_exception_handler,
    include_exceptions,
)
from app.exception.exceptions import (
    RateNotFoundException,
    BenefitsNotFoundException,
    BenefitsMemberNotFoundException,
    BenefitsNotMatchingException,
    AccumulatorNotFoundException,
    AccumulatorMemberNotFoundException,
    InsuranceContextException,
)


def get_response_content(response: JSONResponse) -> dict:
    """Helper function to get JSON response content as dict."""
    return json.loads(bytes(response.body).decode("utf-8"))


class TestProduceResponseContent:
    """Test the produce_response_content function."""

    @patch("app.exception.exception_handler.logger")
    def test_produce_response_content_basic(self, mock_logger):
        """Test basic response content production."""
        exc = Exception("Test error")

        result = produce_response_content(exc)

        assert result["correlationId"] == ""
        assert result["type"] == "https://www.rfc-editor.org/rfc/rfc7231#section-6.5.4"
        assert result["title"] == "Error"
        assert result["status"] == 500
        assert result["detail"] == "Test error"
        assert result["message"] == "Test error"
        mock_logger.error.assert_called_once_with("Exception: Test error")


class TestValidationExceptionHandler:
    """Test the validation_exception_handler function."""

    @pytest.mark.asyncio
    async def test_validation_exception_handler_missing_field(self):
        """Test validation exception handler with missing field error."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}

        # Create a mock validation error
        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body", "membershipId"),
                "type": "missing",
                "msg": "Field required",
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        # Get response content as dict
        content = get_response_content(response)
        assert "Missing required field: membershipId" in content["detail"]
        assert content["title"] == "Validation Error"
        assert content["message"] == "One or more validation errors occurred"

    @pytest.mark.asyncio
    async def test_validation_exception_handler_string_too_short(self):
        """Test validation exception handler with string too short error."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body", "zipCode"),
                "type": "string_too_short",
                "msg": "String too short",
                "ctx": {"min_length": 5},
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Field 'zipCode' must have at least 5 character(s)" in content["detail"]

    @pytest.mark.asyncio
    async def test_validation_exception_handler_json_invalid(self):
        """Test validation exception handler with JSON invalid error."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body",),
                "type": "json_invalid",
                "msg": "Invalid JSON",
                "ctx": {"error": "Expecting ',' delimiter"},
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Invalid JSON format: Expecting ',' delimiter" in content["detail"]

    @pytest.mark.asyncio
    async def test_validation_exception_handler_multiple_errors(self):
        """Test validation exception handler with multiple errors."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("body", "membershipId"),
                "type": "missing",
                "msg": "Field required",
            },
            {
                "loc": ("body", "service", "code"),
                "type": "string_too_short",
                "msg": "String too short",
                "ctx": {"min_length": 1},
            },
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Missing required field: membershipId" in content["detail"]
        assert (
            "Field 'service.code' must have at least 1 character(s)"
            in content["detail"]
        )

    @pytest.mark.asyncio
    async def test_validation_exception_handler_missing_header(self):
        """Test validation exception handler with missing header error."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("header", "x-eieusercontext"),
                "type": "missing",
                "msg": "Field required",
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert "Missing required header: x-eieusercontext" in content["detail"]
        assert content["title"] == "Validation Error"
        assert content["message"] == "One or more validation errors occurred"

    @pytest.mark.asyncio
    async def test_validation_exception_handler_header_string_too_short(self):
        """Test validation exception handler with header string too short error (empty header)."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}

        validation_error = Mock(spec=RequestValidationError)
        validation_error.errors.return_value = [
            {
                "loc": ("header", "x-eieusercontext"),
                "type": "string_too_short",
                "msg": "String should have at least 1 character",
                "ctx": {"min_length": 1},
            }
        ]

        response = await validation_exception_handler(request, validation_error)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 400

        content = get_response_content(response)
        assert (
            "Field 'x-eieusercontext' must have at least 1 character(s)"
            in content["detail"]
        )
        assert content["title"] == "Validation Error"


class TestRateNotFoundExceptionHandler:
    """Test the rate_not_found_exception_handler functions."""

    def test_rate_not_found_exception_handler_logic(self):
        """Test rate_not_found_exception_handler_logic function."""
        exc = RateNotFoundException("Custom rate not found message")

        result = rate_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Custom rate not found message"
        assert result["title"] == "Rate not found"
        assert result["message"] == "Rate not found for the provided criteria"
        assert result["status"] == 500

    @pytest.mark.asyncio
    async def test_rate_not_found_exception_handler_with_correct_exception(self):
        """Test rate_not_found_exception_handler with RateNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = RateNotFoundException("Rate not found for provider")

        response = await rate_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Rate not found for provider" in content["detail"]
        assert "Rate not found" in content["title"]

    @pytest.mark.asyncio
    async def test_rate_not_found_exception_handler_with_other_exception(self):
        """Test rate_not_found_exception_handler with non-RateNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = Exception("Some other error")

        response = await rate_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some other error" in content["detail"]


class TestBenefitsNotFoundExceptionHandler:
    """Test the benefits_not_found_exception_handler functions."""

    def test_benefits_not_found_exception_handler_logic_default_status(self):
        """Test benefits_not_found_exception_handler_logic with default status."""
        exc = BenefitsNotFoundException("Benefits not found")

        result = benefits_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Benefits not found"
        assert result["title"] == "Benefits not found"
        assert result["message"] == "Benefits not found for the provided request"
        assert result["status"] == 500

    def test_benefits_not_found_exception_handler_logic_with_status_400(self):
        """Test benefits_not_found_exception_handler_logic with status 400."""
        exc = BenefitsNotFoundException("Status 400: Member not found")

        result = benefits_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Member not found"
        assert result["title"] == "Benefits not found"
        assert result["message"] == "Benefits not found for the provided request"
        assert result["status"] == 400

    def test_benefits_not_found_exception_handler_logic_with_status_404(self):
        """Test benefits_not_found_exception_handler_logic with status 404."""
        exc = BenefitsNotFoundException("Status 404: No benefits available")

        result = benefits_not_found_exception_handler_logic(exc)

        assert result["detail"] == "No benefits available"
        assert result["title"] == "Benefits not found"
        assert result["message"] == "Benefits not found for the provided request"
        assert result["status"] == 404

    def test_benefits_not_found_exception_handler_logic_invalid_status_format(self):
        """Test benefits_not_found_exception_handler_logic with invalid status format."""
        exc = BenefitsNotFoundException("Status invalid: Some message")

        result = benefits_not_found_exception_handler_logic(exc)

        # Should keep original message and default status
        assert result["detail"] == "Status invalid: Some message"
        assert result["status"] == 500

    @pytest.mark.asyncio
    async def test_benefits_not_found_exception_handler_with_correct_exception(self):
        """Test benefits_not_found_exception_handler with BenefitsNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = BenefitsNotFoundException("Status 400: Member not found")

        response = await benefits_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Member not found" in content["detail"]
        assert "Benefits not found" in content["title"]


class TestBenefitsMemberNotFoundExceptionHandler:
    """Test the benefits_member_not_found_exception_handler functions."""

    def test_benefits_member_not_found_exception_handler_logic_default_status(self):
        """Test benefits_member_not_found_exception_handler_logic with default status."""
        exc = BenefitsMemberNotFoundException("Member not found")

        result = benefits_member_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Member not found"
        assert result["title"] == "Member not found by benefits api"
        assert result["message"] == "Member not found by benefits api"
        assert result["status"] == 500

    def test_benefits_member_not_found_exception_handler_logic_with_status_400(self):
        """Test benefits_member_not_found_exception_handler_logic with status 400."""
        exc = BenefitsMemberNotFoundException("Status 400: Invalid member ID")

        result = benefits_member_not_found_exception_handler_logic(exc)

        assert result["detail"] == "Invalid member ID"
        assert result["title"] == "Member not found by benefits api"
        assert result["message"] == "Member not found by benefits api"
        assert result["status"] == 400

    @pytest.mark.asyncio
    async def test_benefits_member_not_found_exception_handler_with_correct_exception(
        self,
    ):
        """Test benefits_member_not_found_exception_handler with BenefitsMemberNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = BenefitsMemberNotFoundException("Status 404: Member ID not found")

        response = await benefits_member_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Member ID not found" in content["detail"]
        assert "Member not found by benefits api" in content["title"]


class TestBenefitsNotMatchingExceptionHandler:
    """Test the benefits_not_matching_exception_handler functions."""

    def test_benefits_not_matching_exception_handler_logic(self):
        """Test benefits_not_matching_exception_handler_logic function."""
        exc = BenefitsNotMatchingException("No matching benefits found")

        result = benefits_not_matching_exception_handler_logic(exc)

        assert result["detail"] == "No matching benefits found"
        assert result["title"] == "Benefits not matching"
        assert result["message"] == "No matching selected benefits"
        assert result["status"] == 500

    @pytest.mark.asyncio
    async def test_benefits_not_matching_exception_handler_with_correct_exception(self):
        """Test benefits_not_matching_exception_handler with BenefitsNotMatchingException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = BenefitsNotMatchingException("No benefits match the criteria")

        response = await benefits_not_matching_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "No benefits match the criteria" in content["detail"]
        assert "Benefits not matching" in content["title"]


class TestAccumulatorNotFoundExceptionHandler:
    """Test the accumulator_not_found_exception_handler function."""

    @pytest.mark.asyncio
    async def test_accumulator_not_found_exception_handler_with_correct_exception(self):
        """Test accumulator_not_found_exception_handler with AccumulatorNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = AccumulatorNotFoundException("Status 400: Accumulator not found")

        response = await accumulator_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Accumulator not found" in content["detail"]
        assert "Accumulator not found" in content["title"]

    @pytest.mark.asyncio
    async def test_accumulator_not_found_exception_handler_with_other_exception(self):
        """Test accumulator_not_found_exception_handler with non-AccumulatorNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = Exception("Some other error")

        response = await accumulator_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some other error" in content["detail"]


class TestAccumulatorMemberNotFoundExceptionHandler:
    """Test the accumulator_member_not_found_exception_handler function."""

    @pytest.mark.asyncio
    async def test_accumulator_member_not_found_exception_handler_with_correct_exception(
        self,
    ):
        """Test accumulator_member_not_found_exception_handler with AccumulatorMemberNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = AccumulatorMemberNotFoundException(
            "Status 404: Member not found in accumulator"
        )

        response = await accumulator_member_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Member not found in accumulator" in content["detail"]
        assert "Member not found by accumulator api" in content["title"]

    @pytest.mark.asyncio
    async def test_accumulator_member_not_found_exception_handler_with_other_exception(
        self,
    ):
        """Test accumulator_member_not_found_exception_handler with non-AccumulatorMemberNotFoundException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = Exception("Some other error")

        response = await accumulator_member_not_found_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some other error" in content["detail"]


class TestInsuranceContextExceptionHandler:
    """Test the insurance_context_error_exception_handler functions."""

    def test_insurance_context_error_exception_handler_logic_basic(self):
        """Test insurance_context_error_exception_handler_logic with basic message."""
        exc = InsuranceContextException("Insurance context error")

        result = insurance_context_error_exception_handler_logic(exc)

        assert result["detail"] == "Insurance context error"
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_error_code(self):
        """Test insurance_context_error_exception_handler_logic with error code."""
        exc = InsuranceContextException("Insurance context error", error_code="IC001")

        result = insurance_context_error_exception_handler_logic(exc)

        assert result["detail"] == "Insurance context error with error code IC001"
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_error_message(self):
        """Test insurance_context_error_exception_handler_logic with error message."""
        exc = InsuranceContextException(
            "Insurance context error", error_message="Invalid context"
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert (
            result["detail"]
            == "Insurance context error and error message Invalid context"
        )
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_both_error_code_and_message(
        self,
    ):
        """Test insurance_context_error_exception_handler_logic with both error code and message."""
        exc = InsuranceContextException(
            "Insurance context error",
            error_code="IC001",
            error_message="Invalid context",
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert (
            result["detail"]
            == "Insurance context error with error code IC001 and error message Invalid context"
        )
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    @pytest.mark.asyncio
    async def test_insurance_context_error_exception_handler_with_correct_exception(
        self,
    ):
        """Test insurance_context_error_exception_handler with InsuranceContextException."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = InsuranceContextException("Context validation failed", error_code="CV001")

        response = await insurance_context_error_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Context validation failed with error code CV001" in content["detail"]
        assert "Insurance context error" in content["title"]

    def test_insurance_context_error_exception_handler_logic_with_negative_values(
        self,
    ):
        """Test insurance_context_error_exception_handler_logic with IC_NEGATIVE_VALUES error code."""
        exc = InsuranceContextException(
            "Insurance context contains negative values which are not allowed",
            error_code="IC_NEGATIVE_VALUES",
            error_message="Negative values found in insurance context: member_pays=-5.0, cost_share_copay=-10.0",
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert "IC_NEGATIVE_VALUES" in result["detail"]
        assert "Negative values found in insurance context" in result["detail"]
        assert "member_pays=-5.0" in result["detail"]
        assert "cost_share_copay=-10.0" in result["detail"]
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_member_pays_greater_than_rate(
        self,
    ):
        """Test insurance_context_error_exception_handler_logic with IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE error code."""
        exc = InsuranceContextException(
            "Negotiated rate is less than member pays which is not allowed",
            error_code="IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE",
            error_message="Negotiated rate is less than member pays which is not allowed: negotiated_rate=100.0, member_pays=150.0",
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert "IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE" in result["detail"]
        assert "Negotiated rate is less than member pays" in result["detail"]
        assert "negotiated_rate=100.0" in result["detail"]
        assert "member_pays=150.0" in result["detail"]
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    def test_insurance_context_error_exception_handler_logic_with_coinsurance_greater_than_100(
        self,
    ):
        """Test insurance_context_error_exception_handler_logic with IC_COST_SHARE_COINSURANCE_GREATER_THAN_100 error code."""
        exc = InsuranceContextException(
            "Cost share coinsurance is greater than 100 which is not allowed",
            error_code="IC_COST_SHARE_COINSURANCE_GREATER_THAN_100",
            error_message="Cost share coinsurance is greater than 100 which is not allowed: cost_share_coinsurance=120.0",
        )

        result = insurance_context_error_exception_handler_logic(exc)

        assert "IC_COST_SHARE_COINSURANCE_GREATER_THAN_100" in result["detail"]
        assert "Cost share coinsurance is greater than 100" in result["detail"]
        assert "cost_share_coinsurance=120.0" in result["detail"]
        assert result["title"] == "Insurance context error"
        assert result["message"] == "Insurance context error for the provided request"

    @pytest.mark.asyncio
    async def test_insurance_context_error_exception_handler_with_negative_values(
        self,
    ):
        """Test insurance_context_error_exception_handler with IC_NEGATIVE_VALUES exception."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": "test-correlation-id"}
        exc = InsuranceContextException(
            "Insurance context contains negative values which are not allowed",
            error_code="IC_NEGATIVE_VALUES",
            error_message="Negative values found in insurance context: member_pays=-10.0",
        )

        response = await insurance_context_error_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "IC_NEGATIVE_VALUES" in content["detail"]
        assert "Negative values found in insurance context" in content["detail"]
        assert "Insurance context error" in content["title"]
        assert content["correlationId"] == "test-correlation-id"

    @pytest.mark.asyncio
    async def test_insurance_context_error_exception_handler_with_member_pays_greater_than_rate(
        self,
    ):
        """Test insurance_context_error_exception_handler with IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE exception."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": "test-correlation-id"}
        exc = InsuranceContextException(
            "Negotiated rate is less than member pays which is not allowed",
            error_code="IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE",
            error_message="Negotiated rate is less than member pays which is not allowed: negotiated_rate=100.0, member_pays=150.0",
        )

        response = await insurance_context_error_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "IC_MEMBER_PAYS_GREATER_THAN_NEGOTIATED_RATE" in content["detail"]
        assert "Negotiated rate is less than member pays" in content["detail"]
        assert "negotiated_rate=100.0" in content["detail"]
        assert "member_pays=150.0" in content["detail"]
        assert "Insurance context error" in content["title"]

    @pytest.mark.asyncio
    async def test_insurance_context_error_exception_handler_with_coinsurance_greater_than_100(
        self,
    ):
        """Test insurance_context_error_exception_handler with IC_COST_SHARE_COINSURANCE_GREATER_THAN_100 exception."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": "test-correlation-id"}
        exc = InsuranceContextException(
            "Cost share coinsurance is greater than 100 which is not allowed",
            error_code="IC_COST_SHARE_COINSURANCE_GREATER_THAN_100",
            error_message="Cost share coinsurance is greater than 100 which is not allowed: cost_share_coinsurance=120.0",
        )

        response = await insurance_context_error_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "IC_COST_SHARE_COINSURANCE_GREATER_THAN_100" in content["detail"]
        assert "Cost share coinsurance is greater than 100" in content["detail"]
        assert "cost_share_coinsurance=120.0" in content["detail"]
        assert "Insurance context error" in content["title"]


class TestValidateRequiredHeaders:
    """Test the validate_required_headers function."""

    def test_validate_required_headers_all_present(self):
        """Test validate_required_headers with all headers present and non-empty."""
        headers = validate_required_headers(
            x_eieusercontext="test-user-context",
            x_eieapplication="test-application",
            x_eieversion="1.0.0",
            x_apitransactionid="test-txn-id",
            x_global_transaction_id="test-global-txn-id",
        )

        assert isinstance(headers, dict)
        assert headers["x-eieusercontext"] == "test-user-context"
        assert headers["x-eieapplication"] == "test-application"
        assert headers["x-eieversion"] == "1.0.0"
        assert headers["x-apitransactionid"] == "test-txn-id"
        assert headers["x-global-transaction-id"] == "test-global-txn-id"

    def test_validate_required_headers_empty_string_single(self):
        """Test validate_required_headers raises RequestValidationError when a header is empty string."""
        with pytest.raises(RequestValidationError) as exc_info:
            validate_required_headers(
                x_eieusercontext="",
                x_eieapplication="test-application",
                x_eieversion="1.0.0",
                x_apitransactionid="test-txn-id",
                x_global_transaction_id="test-global-txn-id",
            )

        errors = exc_info.value.errors()
        assert len(errors) == 1
        assert errors[0]["loc"] == ("header", "x-eieusercontext")
        assert errors[0]["type"] == "string_too_short"

    def test_validate_required_headers_empty_string_multiple(self):
        """Test validate_required_headers raises RequestValidationError when multiple headers are empty."""
        with pytest.raises(RequestValidationError) as exc_info:
            validate_required_headers(
                x_eieusercontext="",
                x_eieapplication="",
                x_eieversion="1.0.0",
                x_apitransactionid="test-txn-id",
                x_global_transaction_id="test-global-txn-id",
            )

        errors = exc_info.value.errors()
        assert len(errors) == 2
        error_locations = [error["loc"][1] for error in errors]
        assert "x-eieusercontext" in error_locations
        assert "x-eieapplication" in error_locations

    def test_validate_required_headers_whitespace_only(self):
        """Test validate_required_headers raises RequestValidationError when header is whitespace only."""
        with pytest.raises(RequestValidationError) as exc_info:
            validate_required_headers(
                x_eieusercontext="   ",
                x_eieapplication="test-application",
                x_eieversion="1.0.0",
                x_apitransactionid="test-txn-id",
                x_global_transaction_id="test-global-txn-id",
            )

        errors = exc_info.value.errors()
        assert len(errors) == 1
        assert errors[0]["loc"] == ("header", "x-eieusercontext")
        assert errors[0]["type"] == "string_too_short"

    def test_validate_required_headers_all_empty(self):
        """Test validate_required_headers raises RequestValidationError when all headers are empty."""
        with pytest.raises(RequestValidationError) as exc_info:
            validate_required_headers(
                x_eieusercontext="",
                x_eieapplication="",
                x_eieversion="",
                x_apitransactionid="",
                x_global_transaction_id="",
            )

        errors = exc_info.value.errors()
        assert len(errors) == 5
        error_locations = [error["loc"][1] for error in errors]
        assert "x-eieusercontext" in error_locations
        assert "x-eieapplication" in error_locations
        assert "x-eieversion" in error_locations
        assert "x-apitransactionid" in error_locations
        assert "x-global-transaction-id" in error_locations


class TestGenericExceptionHandler:
    """Test the generic_exception_handler function."""

    @pytest.mark.asyncio
    async def test_generic_exception_handler(self):
        """Test generic_exception_handler with any exception."""
        request = Mock(spec=Request)
        request.headers = {"x-global-transaction-id": ""}
        exc = Exception("Some unexpected error")

        response = await generic_exception_handler(request, exc)

        assert isinstance(response, JSONResponse)
        assert response.status_code == 500

        content = get_response_content(response)
        assert "Some unexpected error" in content["detail"]


class TestIncludeExceptions:
    """Test the include_exceptions function."""

    def test_include_exceptions_adds_all_handlers(self):
        """Test that include_exceptions adds all exception handlers to the app."""
        from fastapi import FastAPI

        app = FastAPI()

        # Call include_exceptions
        result_app = include_exceptions(app)

        # Verify the app is returned
        assert result_app is app

        # Verify all exception handlers are registered
        # Note: We can't easily test the internal registration without accessing private attributes
        # But we can verify the function doesn't raise any exceptions
        assert True  # If we get here, the function executed successfully


# Integration tests using FastAPI TestClient
class TestExceptionHandlerIntegration:
    """Integration tests for exception handlers using FastAPI TestClient."""

    def test_validation_error_integration(self):
        """Test validation error handling in a real FastAPI request."""
        from fastapi.testclient import TestClient
        from fastapi import FastAPI
        from pydantic import BaseModel

        # Create a simple FastAPI app for testing
        app = FastAPI()
        include_exceptions(app)

        class TestModel(BaseModel):
            required_field: str
            optional_field: str | None = None

        @app.post("/test")
        async def test_endpoint(data: TestModel):
            return {"message": "success"}

        client = TestClient(app)

        # Test with missing required field
        response = client.post("/test", json={})

        assert response.status_code == 400
        response_data = response.json()
        assert "type" in response_data
        assert "title" in response_data
        assert "detail" in response_data
        assert "Missing required field: required_field" in response_data["detail"]

    def test_custom_exception_integration(self):
        """Test custom exception handling in a real FastAPI request."""
        from fastapi.testclient import TestClient
        from fastapi import FastAPI

        # Create a simple FastAPI app for testing
        app = FastAPI()
        include_exceptions(app)

        @app.get("/test-rate-error")
        async def test_rate_error():
            raise RateNotFoundException("Test rate not found")

        @app.get("/test-benefits-error")
        async def test_benefits_error():
            raise BenefitsNotFoundException("Status 400: Test benefits not found")

        client = TestClient(app)

        # Test rate not found exception
        response = client.get("/test-rate-error")
        assert response.status_code == 500
        response_data = response.json()
        assert "Test rate not found" in response_data["detail"]
        assert "Rate not found" in response_data["title"]

        # Test benefits not found exception
        response = client.get("/test-benefits-error")
        assert response.status_code == 500
        response_data = response.json()
        assert "Test benefits not found" in response_data["detail"]
        assert "Benefits not found" in response_data["title"]
