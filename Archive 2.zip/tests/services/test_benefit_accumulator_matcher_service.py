from typing import Dict, Any, List, Optional
import pytest
import json
import os

from app.schemas.cost_estimator_request import CostEstimatorRequest
from app.schemas.benefit_response import BenefitApiResponse
from app.schemas.accumulator_response import AccumulatorResponse, Accumulator
from app.schemas.benefit_response import Benefit
from app.services.impl.benefit_accumulator_matcher_service_impl import (
    BenefitAccumulatorMatcherServiceImpl,
)

# Load the JSON file
mock_data_path = os.path.join(
    os.path.dirname(__file__),
    "..",
    "mock-data",
    "benefit-match-mock-data",
)


@pytest.fixture
def cost_estimator_request_fixtures() -> Dict[str, CostEstimatorRequest]:
    requests = {}
    for folder_name in os.listdir(mock_data_path):
        folder_path = os.path.join(mock_data_path, folder_name)
        if os.path.isdir(folder_path):
            cost_estimator_request_file = os.path.join(
                folder_path, "CostEstimatorRequest.json"
            )
            if os.path.exists(cost_estimator_request_file):
                with open(cost_estimator_request_file, "r") as f:
                    cost_estimator_request_data = json.load(f)
                    requests[folder_name] = CostEstimatorRequest(
                        **cost_estimator_request_data
                    )
    return requests


@pytest.fixture
def benefit_response_fixtures() -> Dict[str, BenefitApiResponse]:
    responses = {}
    for folder_name in os.listdir(mock_data_path):
        folder_path = os.path.join(mock_data_path, folder_name)
        if os.path.isdir(folder_path):
            benefit_response_file = os.path.join(folder_path, "BenefitApiResponse.json")
            if os.path.exists(benefit_response_file):
                with open(benefit_response_file, "r") as f:
                    benefit_data = json.load(f)
                    responses[folder_name] = BenefitApiResponse(**benefit_data)
    return responses


@pytest.fixture
def benefit_fixtures(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
) -> Dict[str, Benefit]:
    benefits = {}
    for key, response in benefit_response_fixtures.items():
        benefits[key] = response.serviceInfo[0].benefit[0]
    return benefits


@pytest.fixture
def accumulator_data_fixtures() -> Dict[str, Any]:
    data = {}
    for folder_name in os.listdir(mock_data_path):
        folder_path = os.path.join(mock_data_path, folder_name)
        if os.path.isdir(folder_path):
            accumulator_data_file = os.path.join(
                folder_path, "AccumulatorResponse.json"
            )
            if os.path.exists(accumulator_data_file):
                with open(accumulator_data_file, "r") as f:
                    data[folder_name] = json.load(f)
    return data


@pytest.fixture
def accumulator_response_fixtures(
    accumulator_data_fixtures: Dict[str, Any],
) -> Dict[str, AccumulatorResponse]:
    responses = {}
    for key, data in accumulator_data_fixtures.items():
        responses[key] = AccumulatorResponse(**data)
    return responses


@pytest.fixture
def benefit_accumulator_matcher_service_fixture() -> (
    BenefitAccumulatorMatcherServiceImpl
):
    return BenefitAccumulatorMatcherServiceImpl()


def _get_selected_benefits(
    benefit_response: BenefitApiResponse,
    accumulator_response: AccumulatorResponse,
    cost_estimator_request: CostEstimatorRequest,
    accumulator_data: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
    isOutofNetwork: bool,
    expected_num_selected_benefits: int,
    expected_num_matched_accumulators: int = 0,
    accumulator_data_index: int = 0,
    pcp_specialty_codes: Optional[List[str]] = None,
):
    # Ensure providerInfo is available
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )

    if expected_num_selected_benefits == 0:
        # Service returns empty list when no benefits are found (doesn't raise exception)
        selected_benefits = (
            benefit_accumulator_matcher_service_fixture.get_selected_benefits(
                cost_estimator_request.membershipId,
                benefit_response,
                accumulator_response,
                cost_estimator_request.providerInfo[0],
                isOutofNetwork,
                pcp_specialty_codes or [],
            )
        )
        assert selected_benefits is not None
        assert len(selected_benefits) == 0
    else:
        selected_benefits = (
            benefit_accumulator_matcher_service_fixture.get_selected_benefits(
                cost_estimator_request.membershipId,
                benefit_response,
                accumulator_response,
                cost_estimator_request.providerInfo[0],
                isOutofNetwork,
                pcp_specialty_codes or [],
            )
        )
        assert selected_benefits is not None
        assert len(selected_benefits) == expected_num_selected_benefits
        if expected_num_selected_benefits > 0:
            assert selected_benefits[0].coverage.matchedAccumulators is not None
            assert (
                len(selected_benefits[0].coverage.matchedAccumulators)
                == expected_num_matched_accumulators
            )
            assert selected_benefits[0].coverage.matchedAccumulators[0] == Accumulator(
                **accumulator_data["readAccumulatorsResponse"]["memberships"][
                    "subscriber"
                ]["accumulators"][accumulator_data_index]
            )


def test_get_selected_benefits_in_network_without_tiering_without_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=1,
        accumulator_data_index=28,
    )


def test_get_selected_benefits_in_network_without_tiering_non_pcp_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].speciality.code = "91017"
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=1,
        accumulator_data_index=28,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


def test_get_selected_benefits_in_network_without_tiering_with_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=1,
        accumulator_data_index=28,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


def test_get_selected_benefits_in_network_with_tiering_with_non_pcp_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample1-with_tiering"]
    benefit_response = benefit_response_fixtures["sample1-with_tiering"]
    accumulator_response = accumulator_response_fixtures["sample1-with_tiering"]
    accumulator_data = accumulator_data_fixtures["sample1-with_tiering"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=2,
    )


def test_get_selected_benefits_in_network_with_tiering_with_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample1-with_tiering"]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample1-with_tiering"]
    accumulator_response = accumulator_response_fixtures["sample1-with_tiering"]
    accumulator_data = accumulator_data_fixtures["sample1-with_tiering"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=2,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[0].speciality.code = "91017"  # needed?


def test_get_selected_benefits_in_network_with_tiering_non_pcp_designation_empty(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample3-with_tiering2"]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].providerNetworkParticipation.providerTier = (
        "6"
    )
    benefit_response = benefit_response_fixtures["sample3-with_tiering2"]
    accumulator_response = accumulator_response_fixtures["sample3-with_tiering2"]
    accumulator_data = accumulator_data_fixtures["sample3-with_tiering2"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=0,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[
            0
        ].providerNetworkParticipation.providerTier = "1"  # needed?


def test_get_selected_benefits_in_network_with_tiering_pcp_designation_empty(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures["sample3-with_tiering2"]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample3-with_tiering2"]
    accumulator_response = accumulator_response_fixtures["sample3-with_tiering2"]
    accumulator_data = accumulator_data_fixtures["sample3-with_tiering2"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=False,
        expected_num_selected_benefits=1,
        expected_num_matched_accumulators=2,
        accumulator_data_index=2,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[0].speciality.code = "91017"  # needed?


def test_get_selected_benefits_out_of_network_without_tiering_without_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=True,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=0,
    )


def test_get_selected_benefits_out_of_network_without_tiering_with_designation(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample2-no_tiering_no_designation"]
    accumulator_response = accumulator_response_fixtures[
        "sample2-no_tiering_no_designation"
    ]
    accumulator_data = accumulator_data_fixtures["sample2-no_tiering_no_designation"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=True,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=0,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


def test_get_selected_benefits_out_of_network_without_tiering_with_code_is_empty(
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    accumulator_data_fixtures: Dict[str, Any],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    cost_estimator_request = cost_estimator_request_fixtures[
        "sample1-with_code_is_empty"
    ]
    assert (
        cost_estimator_request.providerInfo is not None
        and len(cost_estimator_request.providerInfo) > 0
    )
    cost_estimator_request.providerInfo[0].speciality.code = "10101"
    benefit_response = benefit_response_fixtures["sample1-with_code_is_empty"]
    accumulator_response = accumulator_response_fixtures["sample1-with_code_is_empty"]
    accumulator_data = accumulator_data_fixtures["sample1-with_code_is_empty"]
    _get_selected_benefits(
        benefit_response,
        accumulator_response,
        cost_estimator_request,
        accumulator_data,
        benefit_accumulator_matcher_service_fixture,
        isOutofNetwork=True,
        expected_num_selected_benefits=2,
        expected_num_matched_accumulators=2,
        accumulator_data_index=0,
    )
    if (
        cost_estimator_request.providerInfo
        and len(cost_estimator_request.providerInfo) > 0
    ):
        cost_estimator_request.providerInfo[0].speciality.code = ""  # needed?


# =============================================================================
# DYNAMIC SCENARIO-BASED TESTS
# =============================================================================
# Scenarios:
#   1.1 PCP + Empty tier       → PCP benefit selected, tier is empty
#   1.2 PCP + Non-Empty tier   → PCP benefit selected, tier is non-empty
#   1.3 PCP + Tier mismatch    → Error condition (no benefits)
#   1.4 Only Tiering (PCP mismatch + non-empty tier) → Appropriate tiered benefit
#   1.5 PCP mismatch           → Benefit with highest cost-share selected
#   1.6 No relatedAccums       → Benefit with highest cost-share selected
#
# To add a new scenario:
# 1. Create folder: tests/mock-data/benefit-match-mock-data/scenario{X.Y}-{description}/
# 2. Add files: CostEstimatorRequest.json, BenefitApiResponse.json, AccumulatorResponse.json
# 3. Tests will automatically pick up the new scenario!
# =============================================================================

# PCP specialty codes
PCP_SPECIALTY_CODES = ["10101"]


def _has_pcp_designation(benefit) -> bool:
    """Check if benefit has PCP provider designation."""
    if hasattr(benefit, 'serviceProvider') and benefit.serviceProvider:
        for sp in benefit.serviceProvider:
            if sp.providerDesignation and sp.providerDesignation.upper() == "PCP":
                return True
    return False


def _get_benefit_tier(benefit) -> str:
    """Get benefit tier name, returns empty string if not set."""
    if hasattr(benefit, 'benefitTier') and benefit.benefitTier:
        return benefit.benefitTier.benefitTierName or ""
    return ""


def _discover_scenarios() -> List[str]:
    """Discover all scenario folders (folders starting with 'scenario')."""
    scenarios = []
    for folder_name in sorted(os.listdir(mock_data_path)):
        if folder_name.startswith("scenario"):
            folder_path = os.path.join(mock_data_path, folder_name)
            if (os.path.isdir(folder_path) and 
                os.path.exists(os.path.join(folder_path, "CostEstimatorRequest.json")) and
                os.path.exists(os.path.join(folder_path, "BenefitApiResponse.json")) and
                os.path.exists(os.path.join(folder_path, "AccumulatorResponse.json"))):
                scenarios.append(folder_name)
    return scenarios


# Discover scenarios at module load time
SCENARIOS = _discover_scenarios()


@pytest.mark.parametrize("scenario_folder", SCENARIOS)
def test_benefit_selection_scenario(
    scenario_folder: str,
    benefit_response_fixtures: Dict[str, BenefitApiResponse],
    accumulator_response_fixtures: Dict[str, AccumulatorResponse],
    cost_estimator_request_fixtures: Dict[str, CostEstimatorRequest],
    benefit_accumulator_matcher_service_fixture: BenefitAccumulatorMatcherServiceImpl,
):
    """
    Dynamic test - assertions based on scenario type from folder name.
    """
    # Load test data
    request = cost_estimator_request_fixtures[scenario_folder]
    benefit_response = benefit_response_fixtures[scenario_folder]
    accumulator_response = accumulator_response_fixtures[scenario_folder]
    
    assert request.providerInfo and len(request.providerInfo) > 0
    
    # Call the service
    selected_benefits = benefit_accumulator_matcher_service_fixture.get_selected_benefits(
        request.membershipId,
        benefit_response,
        accumulator_response,
        request.providerInfo[0],
        isOutofNetwork=False,
        pcp_specialty_codes=PCP_SPECIALTY_CODES,
    )
    
    # Extract scenario ID (e.g., "scenario1.1-pcp-empty-tier" -> "1.1")
    scenario_id = scenario_folder.replace("scenario", "").split("-")[0]
    description = scenario_folder.replace(f"scenario{scenario_id}-", "").replace("-", " ")
    
    # =========================================================================
    # DEBUG OUTPUT (Eye Test)
    # =========================================================================
    print(f"\n{'='*70}")
    print(f"SCENARIO {scenario_id}: {description}")
    print(f"{'='*70}")
    print(f"Input:")
    print(f"  Provider Tier: '{request.providerInfo[0].providerNetworkParticipation.providerTier}'")
    print(f"  Specialty Code: '{request.providerInfo[0].speciality.code}'")
    print(f"  PCP Specialty Codes: {PCP_SPECIALTY_CODES}")
    print(f"\nResults: {len(selected_benefits)} benefit(s) selected")
    
    for i, benefit in enumerate(selected_benefits):
        tier = _get_benefit_tier(benefit)
        is_pcp = _has_pcp_designation(benefit)
        print(f"\n  Benefit {i+1}:")
        print(f"    Code: {benefit.benefitCode}")
        print(f"    Name: {benefit.benefitName}")
        print(f"    Network: {benefit.networkCategory}")
        print(f"    Tier: '{tier}' {'(empty)' if not tier else '(non-empty)'}")
        print(f"    Is PCP: {is_pcp}")
        if benefit.coverage and benefit.coverage.matchedAccumulators:
            print(f"    Matched Accumulators: {len(benefit.coverage.matchedAccumulators)}")
            for acc in benefit.coverage.matchedAccumulators:
                print(f"      - {acc.code} (Level: {acc.level})")
    
    # =========================================================================
    # ASSERTIONS BASED ON SCENARIO TYPE
    # =========================================================================
    
    if "1.1" in scenario_folder:
        # Scenario 1.1: PCP + Empty tier
        # Expectation: PCP benefit is selected, and benefit tier is empty
        assert len(selected_benefits) > 0, "Expected at least one benefit"
        pcp_benefits = [b for b in selected_benefits if _has_pcp_designation(b)]
        assert len(pcp_benefits) > 0, "Expected a PCP benefit to be selected"
        for b in pcp_benefits:
            assert _get_benefit_tier(b) == "", f"Expected empty tier, got '{_get_benefit_tier(b)}'"
        print(f"\n✓ PASS: PCP benefit selected with empty tier")
        
    elif "1.2" in scenario_folder:
        # Scenario 1.2: PCP + Non-Empty tier
        # Expectation: PCP benefit is selected, and benefit tier is non-empty
        assert len(selected_benefits) > 0, "Expected at least one benefit"
        pcp_benefits = [b for b in selected_benefits if _has_pcp_designation(b)]
        assert len(pcp_benefits) > 0, "Expected a PCP benefit to be selected"
        for b in pcp_benefits:
            tier = _get_benefit_tier(b)
            assert tier != "", "Expected non-empty tier"
        print(f"\n✓ PASS: PCP benefit selected with non-empty tier")
        
    elif "1.3" in scenario_folder:
        # Scenario 1.3: PCP + Tier mismatch
        # Expectation: Error condition (no benefits selected)
        assert len(selected_benefits) == 0, f"Expected no benefits (error), got {len(selected_benefits)}"
        print(f"\n✓ PASS: Error condition - no benefits selected")
        
    elif "1.4" in scenario_folder:
        # Scenario 1.4: Only Tiering (PCP mismatch + non-empty tier)
        # Expectation: Appropriate tiered benefit is chosen
        assert len(selected_benefits) > 0, "Expected at least one benefit"
        provider_tier = request.providerInfo[0].providerNetworkParticipation.providerTier
        for b in selected_benefits:
            assert _get_benefit_tier(b) == provider_tier, f"Expected tier '{provider_tier}'"
        print(f"\n✓ PASS: Tiered benefit selected (tier: '{provider_tier}')")
        
    elif "1.5" in scenario_folder:
        # Scenario 1.5: PCP mismatch
        # Expectation: Benefit with highest cost-share is selected
        assert len(selected_benefits) > 0, "Expected at least one benefit"
        print(f"\n✓ PASS: Benefit selected (PCP mismatch)")
        
    elif "1.6" in scenario_folder:
        # Scenario 1.6: No relatedAccums
        # Expectation: Benefit with highest cost-share is selected
        assert len(selected_benefits) > 0, "Expected at least one benefit"
        print(f"\n✓ PASS: Benefit selected (no relatedAccums)")
        
    else:
        print(f"\n✓ PASS: Service executed for {scenario_folder}")
