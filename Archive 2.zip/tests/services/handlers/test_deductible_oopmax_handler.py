#!/usr/bin/env python3
"""
Tests for the CalculationService class and interface.
"""

import pytest
from unittest.mock import Mock

from app.services.handlers.deductible_oopmax_handler import DeductibleOOPMaxHandler

from tests.services.handlers.test_data import (
    mock_matched_accumulator_individual_oopmax,
    mock_matched_accumulator_individual_deductible,
    mock_matched_accumulator_family_oopmax,
    mock_matched_accumulator_family_deductible,
    mock_handle,
    MockBenefit,
    MockCoverage,
    assert_insurance_context,
)


@pytest.fixture
def mock_co_insurance_handler() -> Mock:
    return Mock()


@pytest.fixture
def mock_cost_share_co_pay_handler() -> Mock:
    return Mock()


@pytest.fixture
def deductible_oopmax_handler_fixture(
    mock_co_insurance_handler: Mock, mock_cost_share_co_pay_handler: Mock
) -> DeductibleOOPMaxHandler:
    deductible_oopmax_handler = DeductibleOOPMaxHandler()

    deductible_oopmax_handler.set_deductible_co_insurance_handler(
        mock_co_insurance_handler
    )
    deductible_oopmax_handler.set_deductible_cost_share_co_pay_handler(
        mock_cost_share_co_pay_handler
    )
    return deductible_oopmax_handler


"""
NOTE:
- It is possible to have oopmax without deductible, but that case shouldn't reach this handler
- It is very rare / not possible to have deductible without oopmax
- If individual deductible is ever missing, so will family deductible. And such a case shouldn't reach this handler
- Deductible >= OOPMax
- Individual deductible <= Family deductible
"""


class TestDeductibleOOPMaxHandler:

    def test_ind_deductible_applies_to_oopmax_and_deductible_greater_than_service_amount(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(),
            matched_accumulators=[accum_individual_oopmax, accum_individual_deductible],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 250,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_deductible_applies_to_oopmax_and_deductible_greater_than_service_amount(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=300
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=1000
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 250,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": 250,
                "deductible_family_calculated": 950,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_ind_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_not_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="N"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 100,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_called_once()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_not_before_copay_deductibles_non_equal(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=600
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=400
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="N"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 100,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 400,
                "deductible_family_calculated": 200,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_called_once()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_not_before_copay_deductibles_equal(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=600
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="N"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 100,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 400,
                "deductible_family_calculated": 0,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_called_once()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_not_before_copay_deductibles_oopmax_equal(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=200
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=200
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="N"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 0,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 0,
                "deductible_family_calculated": 0,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_called_once()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_ind_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="Y"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 100,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_called_once()

    def test_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=600
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=400
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="Y"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 100,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 400,
                "deductible_family_calculated": 200,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_called_once()

    def test_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_before_copay_deductibles_equal(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=600
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="Y"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 100,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 400,
                "deductible_family_calculated": 0,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_called_once()

    def test_deductible_applies_to_oopmax_and_deductible_less_than_service_amount_deductible_before_copay_deductibles_oopmax_equal(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=200
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=200
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(isDeductibleBeforeCopay="Y"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 0,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 0,
                "deductible_family_calculated": 0,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_called_once()

    def test_ind_deductible_does_not_apply_to_oopmax_and_deductible_greater_than_service_amount(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(deductibleAppliesOutOfPocket="N"),
            matched_accumulators=[accum_individual_oopmax, accum_individual_deductible],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 300,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_deductible_does_not_apply_to_oopmax_and_deductible_greater_than_service_amount(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=300
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=1000
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(deductibleAppliesOutOfPocket="N"),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 300,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": 300,
                "deductible_family_calculated": 950,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_ind_deductible_does_not_apply_to_oopmax_and_deductible_less_than_service_amount_deductible_not_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(
                deductibleAppliesOutOfPocket="N", isDeductibleBeforeCopay="N"
            ),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 300,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_called_once()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_deductible_does_not_apply_to_oopmax_and_deductible_less_than_service_amount_deductible_not_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=600
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=400
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(
                deductibleAppliesOutOfPocket="N", isDeductibleBeforeCopay="N"
            ),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 300,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 600,
                "deductible_family_calculated": 200,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_called_once()
        mock_cost_share_co_pay_handler.handle.assert_not_called()

    def test_ind_deductible_does_not_apply_to_oopmax_and_deductible_less_than_service_amount_deductible_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(
                deductibleAppliesOutOfPocket="N", isDeductibleBeforeCopay="Y"
            ),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 300,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_called_once()

    def test_deductible_does_not_apply_to_oopmax_and_deductible_less_than_service_amount_deductible_before_copay(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_oopmax = mock_matched_accumulator_individual_oopmax(
            calculatedValue=300
        )
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_oopmax = mock_matched_accumulator_family_oopmax(
            calculatedValue=600
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=400
        )
        service_amount = 500
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(
                deductibleAppliesOutOfPocket="N", isDeductibleBeforeCopay="Y"
            ),
            matched_accumulators=[
                accum_individual_oopmax,
                accum_individual_deductible,
                accum_family_oopmax,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 300,
                "member_pays": 200,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": 300,
                "deductible_individual_calculated": 0,
                "oopmax_family_calculated": 600,
                "deductible_family_calculated": 200,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_called_once()

    def test_ind_deductible_applies_to_oopmax_and_no_oopmax(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(),
            matched_accumulators=[accum_individual_deductible],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": None,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": None,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()
    
    def test_deductible_applies_to_oopmax_and_no_oopmax(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=1000
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(),
            matched_accumulators=[
                accum_individual_deductible,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": None,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": 950,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()
    
    def test_deductible_does_not_apply_to_oopmax_and_no_oopmax(
        self,
        deductible_oopmax_handler_fixture: DeductibleOOPMaxHandler,
        mock_co_insurance_handler: Mock,
        mock_cost_share_co_pay_handler: Mock,
    ):
        accum_individual_deductible = mock_matched_accumulator_individual_deductible(
            calculatedValue=200
        )
        accum_family_deductible = mock_matched_accumulator_family_deductible(
            calculatedValue=1000
        )
        service_amount = 50
        insurance_context = mock_handle(
            handler=deductible_oopmax_handler_fixture,
            service_amount=service_amount,
            mock_benefit=MockBenefit(),
            mock_coverage=MockCoverage(deductibleAppliesOutOfPocket="N"),
            matched_accumulators=[
                accum_individual_deductible,
                accum_family_deductible,
            ],
        )

        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=service_amount,
            expected_values={
                "service_amount": 0,
                "member_pays": 50,
                "cost_share_copay": 0,
                "oopmax_individual_calculated": None,
                "deductible_individual_calculated": 150,
                "oopmax_family_calculated": None,
                "deductible_family_calculated": 950,
            },
            show=False,
        )
        mock_co_insurance_handler.handle.assert_not_called()
        mock_cost_share_co_pay_handler.handle.assert_not_called()


if __name__ == "__main__":
    pytest.main([__file__])
