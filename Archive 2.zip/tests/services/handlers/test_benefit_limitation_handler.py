#!/usr/bin/env python3
"""
Tests for the BenefitLimitationHandler class and interface.
"""

import sys
import os
from unittest.mock import Mock
import pytest

from app.services.impl.calculation_service_impl import CalculationServiceImpl
from app.services.calculation_service import (
    CalculationServiceInterface,
)
from app.services.handlers.benefit_limitation_handler import BenefitLimitationHandler

from tests.services.handlers.test_data import (
    mock_matched_accumulator_limit,
    MockBenefit,
    MockCoverage,
    assert_insurance_context,
    mock_handle,
)


@pytest.fixture
def mock_oopmax_handler() -> Mock:
    return Mock()


@pytest.fixture
def benefit_limitation_handler_fixture(
    mock_oopmax_handler: Mock,
) -> BenefitLimitationHandler:
    handler = BenefitLimitationHandler()
    handler.set_oopmax_handler(mock_oopmax_handler)
    return handler


# Add the project root to Python path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, project_root)


class TestCalculationService:
    """Test the CalculationService implementation"""

    def setup_method(self):
        """Set up test fixtures"""
        self.calculation_service = CalculationServiceImpl()

    def test_calculation_service_implements_interface(self):
        """Test that CalculationService implements the interface"""
        assert isinstance(self.calculation_service, CalculationServiceInterface)

    def test_calculation_service_has_chain(self):
        """Test that CalculationService has a calculation chain"""
        assert hasattr(self.calculation_service, "chain")
        assert self.calculation_service.chain is not None

    def test_find_highest_member_pay_with_limit_benefit_limit_is_zero(
        self,
        benefit_limitation_handler_fixture: BenefitLimitationHandler,
        mock_oopmax_handler: Mock,
    ):
        """Test find_highest_member_pay with benefit that has limit = 0"""

        # Create a benefit with limit accumulator with calculatedValue=0 (only override this value)
        matched_accum = mock_matched_accumulator_limit(calculatedValue=0)

        insurance_context = mock_handle(
            handler=benefit_limitation_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test Benefit with Limits", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test Benefit with Limits"),
            matched_accumulators=[matched_accum],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=200,
            expected_values={
                "service_amount": 0,  # Service amount should be 0 after being allocated to member_pays
                "member_pays": 200,  # Member pays the full amount when limit is 0
                # "is_service_covered": False,  # Service not covered when limit is 0
                "limit_calculated": 0,  # Limit should be 0
            },
            show=True,
        )

        # Simple assert to check if expected message is found in any trace description
        expected_message = "The benefit code is 'limit' and the calculated limit is 0, applying benefit service is not covered as benefit limit has reached"
        assert any(
            expected_message in trace.description
            for trace in insurance_context.trace_entries
        ), f"Expected message not found: {expected_message}"

        # Assert that the OOP max handler was NOT called (limit is 0, so no OOP max processing)
        mock_oopmax_handler.handle.assert_not_called()

        print("Test completed successfully. Benefit limitation applied correctly.")

    def test_find_highest_member_pay_with_limit_benefit_within_limit(
        self,
        benefit_limitation_handler_fixture: BenefitLimitationHandler,
        mock_oopmax_handler: Mock,
    ):
        """Test find_highest_member_pay with benefit that has limit > service amount"""

        # Create a benefit with limit accumulator where limit > service amount
        # This should trigger _apply_within_limit (service_amount=200, limit_calculated=300)
        matched_accum = mock_matched_accumulator_limit(calculatedValue=300)

        insurance_context = mock_handle(
            handler=benefit_limitation_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test Benefit with Limits", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test Benefit with Limits"),
            matched_accumulators=[matched_accum],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=200,
            expected_values={
                # "service_amount": 0,    # Service amount should be 0 after processing
                "limit_calculated": 100,  # Limit should be reduced from 300 to 100 (300 - 200)
                "is_service_covered": True,  # Service should be covered within limit
                "calculation_complete": True,  # Calculation should be complete
            },
            show=True,
        )

        # Assert that _apply_within_limit was called (look for its trace message)
        within_limit_trace_found = False
        for trace in insurance_context.trace_entries:
            if "_apply_within_limit" in trace.step:
                within_limit_trace_found = True
                print(
                    f"_apply_within_limit trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            within_limit_trace_found
        ), "Expected _apply_within_limit trace message not found"

        # Assert that the limit was reduced by service amount
        assert (
            insurance_context.limit_calculated is not None
            and insurance_context.limit_calculated < 300
        ), f"Expected limit_calculated to be reduced from 300, got {insurance_context.limit_calculated}"

        # Assert that the OOP max handler was called (dollar logic calls oopmax_handler)
        mock_oopmax_handler.handle.assert_called()

        print("Test completed successfully. Benefit within limit applied correctly.")

    def test_find_highest_member_pay_with_limit_benefit_partial_limit(
        self,
        benefit_limitation_handler_fixture: BenefitLimitationHandler,
        mock_oopmax_handler: Mock,
    ):
        """Test find_highest_member_pay with benefit that has limit < service amount"""

        # Create a benefit with limit accumulator where limit < service amount
        # This should trigger _apply_partial_limit (service_amount=200, limit_calculated=100)
        matched_accum = mock_matched_accumulator_limit(calculatedValue=100)

        insurance_context = mock_handle(
            handler=benefit_limitation_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test Benefit with Limits", benefitCode=1001
            ),
            mock_coverage=MockCoverage(benefitDescription="Test Benefit with Limits"),
            matched_accumulators=[matched_accum],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=200,
            expected_values={
                # "service_amount": 0,    # Service amount should be 0 after processing
                "member_pays": 100,  # Member pays the difference (200 - 100)
                "limit_calculated": 0,  # Limit should be reduced to 0
                "is_service_covered": True,  # Service should be covered
                "calculation_complete": True,  # Calculation should be complete
            },
            show=True,
        )

        # Assert that _apply_partial_limit was called (look for its trace message)
        partial_limit_trace_found = False
        for trace in insurance_context.trace_entries:
            if "_apply_partial_limit" in trace.step:
                partial_limit_trace_found = True
                print(
                    f"_apply_partial_limit trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            partial_limit_trace_found
        ), "Expected _apply_partial_limit trace message not found"

        # Assert that the limit was reduced to 0
        assert (
            insurance_context.limit_calculated is not None
            and insurance_context.limit_calculated == 0
        ), f"Expected limit_calculated to be reduced to 0, got {insurance_context.limit_calculated}"

        # Member pays the difference between service amount and limit
        assert (
            insurance_context.member_pays == 100
        ), f"Expected member_pays to be 100, got {insurance_context.member_pays}"

        # Assert that the OOP max handler was called (dollar logic calls oopmax_handler)
        mock_oopmax_handler.handle.assert_called()

        print("Test completed successfully. Benefit partial limit applied correctly.")

    def test_find_highest_member_pay_with_limit_benefit_counter_type(
        self,
        benefit_limitation_handler_fixture: BenefitLimitationHandler,
        mock_oopmax_handler: Mock,
    ):
        """Test find_highest_member_pay with benefit that has limitType = 'counter'"""

        # Create a benefit with limit accumulator where limitType = 'counter'
        # This should trigger the counter logic block
        matched_accum = mock_matched_accumulator_limit(
            calculatedValue=5, limitType="Counter"
        )

        insurance_context = mock_handle(
            handler=benefit_limitation_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test Benefit with Counter Limits", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test Benefit with Counter Limits"
            ),
            matched_accumulators=[matched_accum],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=200,
            expected_values={
                "service_amount": 200,  # Service amount should remain unchanged
                "limit_calculated": 4,  # Limit should be reduced from 5 to 4 (counter decrements by 1)
                "is_service_covered": True,  # Service should be covered
                "calculation_complete": True,  # Calculation should be complete
            },
            show=True,
        )

        # Assert that _apply_limitation was called (look for its trace message)
        limitation_trace_found = False
        for trace in insurance_context.trace_entries:
            if "_apply_limitation" in trace.step:
                limitation_trace_found = True
                print(
                    f"_apply_limitation trace found: [{trace.step}] {trace.description}"
                )
                break

        assert (
            limitation_trace_found
        ), "Expected _apply_limitation trace message not found"

        # Assert that the limit was reduced by 1 (counter logic)
        assert (
            insurance_context.limit_calculated is not None
            and insurance_context.limit_calculated == 4
        ), f"Expected limit_calculated to be reduced from 5 to 4, got {insurance_context.limit_calculated}"

        # Assert that the OOP max handler was called (counter logic calls oopmax_handler before _apply_limitation)
        mock_oopmax_handler.handle.assert_called_once()

        print("Test completed successfully. Benefit counter limit applied correctly.")

    def test_find_highest_member_pay_with_limit_benefit_counter_type_zero_limit(
        self,
        benefit_limitation_handler_fixture: BenefitLimitationHandler,
        mock_oopmax_handler: Mock,
    ):
        """Test find_highest_member_pay with benefit that has limitType = 'counter' and limit = 0"""

        # Create a benefit with limit accumulator where limitType = 'counter' and calculatedValue = 0
        # This should trigger the counter logic block but with zero limit
        matched_accum = mock_matched_accumulator_limit(
            calculatedValue=0, limitType="Counter"
        )

        insurance_context = mock_handle(
            handler=benefit_limitation_handler_fixture,
            service_amount=200,
            mock_benefit=MockBenefit(
                benefitName="Test Benefit with Counter Limits Zero", benefitCode=1001
            ),
            mock_coverage=MockCoverage(
                benefitDescription="Test Benefit with Counter Limits Zero"
            ),
            matched_accumulators=[matched_accum],
        )
        assert_insurance_context(
            insurance_context=insurance_context,
            service_amount=200,
            expected_values={
                "service_amount": 0,  # Service amount should be 0 after being allocated to member_pays
                "member_pays": 200,  # Member pays the full amount when counter limit is 0
                # "is_service_covered": False,  # Service not covered when counter limit is 0
                "limit_calculated": 0,  # Limit should remain 0
                "calculation_complete": True,  # Calculation should be complete
            },
            show=True,
        )

        # Simple assert to check if expected message is found in any trace description
        expected_message = "The benefit code is 'limit' and the calculated limit is 0, applying benefit service is not covered as benefit limit has reached"
        assert any(
            expected_message in trace.description
            for trace in insurance_context.trace_entries
        ), f"Expected message not found: {expected_message}"

        # Assert that the OOP max handler was NOT called (counter limit is 0, so no OOP max processing)
        mock_oopmax_handler.handle.assert_not_called()

        print(
            "Test completed successfully. Benefit counter limit zero applied correctly."
        )

    def test_find_highest_member_pay_with_limit_benefit_unknown_type_exception(
        self,
        benefit_limitation_handler_fixture: BenefitLimitationHandler,
        mock_oopmax_handler: Mock,
    ):
        """Test find_highest_member_pay with benefit that has unknown limitType to verify exception is thrown"""

        # Create a benefit with limit accumulator where limitType is unknown
        # This should trigger an exception for unknown limit type
        matched_accum = mock_matched_accumulator_limit(
            calculatedValue=100, limitType="Unknown"
        )

        # Test that an exception is raised for unknown limit type
        with pytest.raises(Exception) as exc_info:
            insurance_context = mock_handle(
                handler=benefit_limitation_handler_fixture,
                service_amount=200,
                mock_benefit=MockBenefit(
                    benefitName="Test Benefit with Unknown Limits", benefitCode=1001
                ),
                mock_coverage=MockCoverage(
                    benefitDescription="Test Benefit with Unknown Limits"
                ),
                matched_accumulators=[matched_accum],
            )

        # Verify the exception message contains the expected text
        expected_message = (
            "Uknown benefit limit type. Unable to proceed. Limit type passed: Unknown"
        )
        assert expected_message in str(
            exc_info.value
        ), f"Expected exception message not found: {expected_message}"

        # Assert that the OOP max handler was NOT called (exception thrown before OOP max processing)
        mock_oopmax_handler.handle.assert_not_called()

        print("Test completed successfully. Exception thrown for unknown limit type.")
