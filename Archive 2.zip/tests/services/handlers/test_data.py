from app.core.base import InsuranceContext, MatchedAccumulator
from app.schemas.accumulator_response import EffectivePeriod
from app.models.selected_benefit import SelectedBenefit, SelectedCoverage
from app.schemas.benefit_response import BenefitTier, Prerequisite, ServiceProviderItem
from typing import Any, Dict, List
from app.core.base import Handler
from datetime import date


class MockBenefit:
    def __init__(self, **kwargs):
        self.benefitName: str = "Mock benefit"
        self.benefitCode: int = 1
        self.isInitialBenefit: str = "true"
        self.benefitTier: BenefitTier = BenefitTier(benefitTierName="Standard")
        self.networkCategory: str = "InNetwork"
        self.prerequisites: List[Prerequisite] = [
            Prerequisite(type="None", isRequired="false")
        ]
        self.benefitProvider: str = "Mock Provider"
        self.serviceProvider: List[ServiceProviderItem] = [ServiceProviderItem()]
        for key, value in kwargs.items():
            setattr(self, key, value)


class MockCoverage:
    def __init__(self, **kwargs):
        # Set default values as instance attributes
        self.sequenceNumber: int = 1
        self.benefitDescription: str = "Mock coverage"
        self.costShareCopay: float = 0.0
        self.costShareCoinsurance: float = 0.0
        self.copayAppliesOutOfPocket: str = "Y"
        self.coinsAppliesOutOfPocket: str = "Y"
        self.deductibleAppliesOutOfPocket: str = "Y"
        self.deductibleAppliesOutOfPocketOtherIndicator: str = ""
        self.copayCountToDeductibleIndicator: str = "Y"
        self.copayContinueWhenDeductibleMetIndicator: str = "Y"
        self.copayContinueWhenOutOfPocketMaxMetIndicator: str = "Y"
        self.coinsuranceToOutOfPocketOtherIndicator: str = "Y"
        self.copayToOutofPocketOtherIndicator: str = "Y"
        self.isDeductibleBeforeCopay: str = "Y"
        self.benefitLimitation: str = "Y"
        self.isServiceCovered: str = "Y"
        for key, value in kwargs.items():
            setattr(self, key, value)


def mock_matched_accumulator_individual_oopmax(
    level="Individual",
    deductibleCode="001",
    frequency="Calendar Year",
    relationshipToSubscriber="Self",
    suffix="",
    benefitProductType="Medical",
    description="Individual oopmax",
    currentValue=900.00,
    limitValue=1000,
    code="oop max",
    effectivePeriod=EffectivePeriod(
        datetimeBegin=date(2024, 1, 1), datetimeEnd=date(2024, 12, 31)
    ),
    calculatedValue=100,
    savingsLevel="Standard",
    networkIndicator="In Network",
    networkIndicatorCode="IN",
    limitType="Annual",
    numOfIndividualsMet=0,
    numOfIndividualsNeededToMeet=0,
) -> MatchedAccumulator:
    return MatchedAccumulator(
        level=level,
        deductibleCode=deductibleCode,
        frequency=frequency,
        relationshipToSubscriber=relationshipToSubscriber,
        suffix=suffix,
        benefitProductType=benefitProductType,
        description=description,
        currentValue=currentValue,
        limitValue=limitValue,
        code=code,
        effectivePeriod=effectivePeriod,
        calculatedValue=calculatedValue,
        savingsLevel=savingsLevel,
        networkIndicator=networkIndicator,
        networkIndicatorCode=networkIndicatorCode,
        limitType=limitType,
        numOfIndividualsMet=numOfIndividualsMet,
        numOfIndividualsNeededToMeet=numOfIndividualsNeededToMeet,
    )


def mock_matched_accumulator_family_oopmax(
    level="Family",
    deductibleCode="001",
    frequency="Calendar Year",
    relationshipToSubscriber="Self",
    suffix="",
    benefitProductType="Medical",
    description="Family OOP Max",
    currentValue=0.00,
    limitValue=2000,
    code="OOP Max",
    effectivePeriod=EffectivePeriod(
        datetimeBegin=date(2024, 1, 1), datetimeEnd=date(2024, 12, 31)
    ),
    calculatedValue=int(0),
    savingsLevel="Standard",
    networkIndicator="In Network",
    networkIndicatorCode="IN",
    limitType="Annual",
    numOfIndividualsMet=0,
    numOfIndividualsNeededToMeet=0,
) -> MatchedAccumulator:
    """Create a mock family OOP max accumulator."""
    return MatchedAccumulator(
        level=level,
        deductibleCode=deductibleCode,
        frequency=frequency,
        relationshipToSubscriber=relationshipToSubscriber,
        suffix=suffix,
        benefitProductType=benefitProductType,
        description=description,
        currentValue=currentValue,
        limitValue=limitValue,
        code=code,
        effectivePeriod=effectivePeriod,
        calculatedValue=calculatedValue,
        savingsLevel=savingsLevel,
        networkIndicator=networkIndicator,
        networkIndicatorCode=networkIndicatorCode,
        limitType=limitType,
        numOfIndividualsMet=numOfIndividualsMet,
        numOfIndividualsNeededToMeet=numOfIndividualsNeededToMeet,
    )


def mock_matched_accumulator_individual_deductible(
    level="Individual",
    deductibleCode="001",
    frequency="Calendar Year",
    relationshipToSubscriber="Self",
    suffix="",
    benefitProductType="Medical",
    description="Individual deductible",
    currentValue=300.00,
    limitValue=500,
    code="Deductible",
    effectivePeriod=EffectivePeriod(
        datetimeBegin=date(2024, 1, 1), datetimeEnd=date(2024, 12, 31)
    ),
    calculatedValue=200,
    savingsLevel="Standard",
    networkIndicator="In Network",
    networkIndicatorCode="IN",
    limitType="Annual",
    numOfIndividualsMet=0,
    numOfIndividualsNeededToMeet=0,
) -> MatchedAccumulator:
    """Create a mock individual deductible accumulator."""
    return MatchedAccumulator(
        level=level,
        deductibleCode=deductibleCode,
        frequency=frequency,
        relationshipToSubscriber=relationshipToSubscriber,
        suffix=suffix,
        benefitProductType=benefitProductType,
        description=description,
        currentValue=currentValue,
        limitValue=limitValue,
        code=code,
        effectivePeriod=effectivePeriod,
        calculatedValue=calculatedValue,
        savingsLevel=savingsLevel,
        networkIndicator=networkIndicator,
        networkIndicatorCode=networkIndicatorCode,
        limitType=limitType,
        numOfIndividualsMet=numOfIndividualsMet,
        numOfIndividualsNeededToMeet=numOfIndividualsNeededToMeet,
    )


def mock_matched_accumulator_family_deductible(
    level="Family",
    deductibleCode="001",
    frequency="Calendar Year",
    relationshipToSubscriber="Self",
    suffix="",
    benefitProductType="Medical",
    description="Family deductible",
    currentValue=1000.00,
    limitValue=2000,
    code="Deductible",
    effectivePeriod=EffectivePeriod(
        datetimeBegin=date(2024, 1, 1), datetimeEnd=date(2024, 12, 31)
    ),
    calculatedValue=1000,
    savingsLevel="Standard",
    networkIndicator="In Network",
    networkIndicatorCode="IN",
    limitType="Annual",
    numOfIndividualsMet=0,
    numOfIndividualsNeededToMeet=0,
) -> MatchedAccumulator:
    """Create a mock individual deductible accumulator."""
    return MatchedAccumulator(
        level=level,
        deductibleCode=deductibleCode,
        frequency=frequency,
        relationshipToSubscriber=relationshipToSubscriber,
        suffix=suffix,
        benefitProductType=benefitProductType,
        description=description,
        currentValue=currentValue,
        limitValue=limitValue,
        code=code,
        effectivePeriod=effectivePeriod,
        calculatedValue=calculatedValue,
        savingsLevel=savingsLevel,
        networkIndicator=networkIndicator,
        networkIndicatorCode=networkIndicatorCode,
        limitType=limitType,
        numOfIndividualsMet=numOfIndividualsMet,
        numOfIndividualsNeededToMeet=numOfIndividualsNeededToMeet,
    )


def mock_matched_accumulator_limit(
    level="Individual",
    deductibleCode="001",
    frequency="Calendar Year",
    relationshipToSubscriber="Self",
    suffix="",
    benefitProductType="Medical",
    description="Service Limit",
    currentValue=0.00,
    limitValue=7,
    code="Limit",
    effectivePeriod=EffectivePeriod(
        datetimeBegin=date(2024, 1, 1), datetimeEnd=date(2024, 12, 31)
    ),
    calculatedValue=int(100),
    savingsLevel="In Network",
    networkIndicator="In Network",
    networkIndicatorCode="IN",
    limitType="dollar",
    numOfIndividualsMet=0,
    numOfIndividualsNeededToMeet=0,
) -> MatchedAccumulator:
    """Create a mock limit accumulator."""
    return MatchedAccumulator(
        level=level,
        deductibleCode=deductibleCode,
        frequency=frequency,
        relationshipToSubscriber=relationshipToSubscriber,
        suffix=suffix,
        benefitProductType=benefitProductType,
        description=description,
        currentValue=currentValue,
        limitValue=limitValue,
        code=code,
        effectivePeriod=effectivePeriod,
        calculatedValue=calculatedValue,
        savingsLevel=savingsLevel,
        networkIndicator=networkIndicator,
        networkIndicatorCode=networkIndicatorCode,
        limitType=limitType,
        numOfIndividualsMet=numOfIndividualsMet,
        numOfIndividualsNeededToMeet=numOfIndividualsNeededToMeet,
    )


def mock_selected_coverage(
    matchedAccumulators: List[MatchedAccumulator],
    sequenceNumber: int,
    benefitDescription: str,
    costShareCopay: float,
    costShareCoinsurance: float,
    copayAppliesOutOfPocket: str,
    coinsAppliesOutOfPocket: str,
    deductibleAppliesOutOfPocket: str,
    deductibleAppliesOutOfPocketOtherIndicator: str,
    copayCountToDeductibleIndicator: str,
    copayContinueWhenDeductibleMetIndicator: str,
    copayContinueWhenOutOfPocketMaxMetIndicator: str,
    coinsuranceToOutOfPocketOtherIndicator: str,
    copayToOutofPocketOtherIndicator: str,
    isDeductibleBeforeCopay: str,
    benefitLimitation: str,
    isServiceCovered: str,
) -> SelectedCoverage:
    """Create a mock selected coverage."""
    return SelectedCoverage(
        sequenceNumber=sequenceNumber,
        benefitDescription=benefitDescription,
        costShareCopay=costShareCopay,
        costShareCoinsurance=costShareCoinsurance,
        copayAppliesOutOfPocket=copayAppliesOutOfPocket,
        coinsAppliesOutOfPocket=coinsAppliesOutOfPocket,
        deductibleAppliesOutOfPocket=deductibleAppliesOutOfPocket,
        deductibleAppliesOutOfPocketOtherIndicator=deductibleAppliesOutOfPocketOtherIndicator,
        copayCountToDeductibleIndicator=copayCountToDeductibleIndicator,
        copayContinueWhenDeductibleMetIndicator=copayContinueWhenDeductibleMetIndicator,
        copayContinueWhenOutOfPocketMaxMetIndicator=copayContinueWhenOutOfPocketMaxMetIndicator,
        coinsuranceToOutOfPocketOtherIndicator=coinsuranceToOutOfPocketOtherIndicator,
        copayToOutofPocketOtherIndicator=copayToOutofPocketOtherIndicator,
        isDeductibleBeforeCopay=isDeductibleBeforeCopay,
        benefitLimitation=benefitLimitation,
        isServiceCovered=isServiceCovered,
        matchedAccumulators=matchedAccumulators,
    )


def mock_selected_benefit(
    coverage,
    benefitName: str,
    benefitCode: int,
    isInitialBenefit: str,
    benefitTier: BenefitTier,
    networkCategory: str,
    prerequisites: List[Prerequisite],
    benefitProvider: str,
    serviceProvider: List[ServiceProviderItem],
) -> SelectedBenefit:
    """Create a mock selected benefit."""
    return SelectedBenefit(
        benefitName=benefitName,
        benefitCode=benefitCode,
        isInitialBenefit=isInitialBenefit,
        benefitTier=benefitTier,
        networkCategory=networkCategory,
        prerequisites=prerequisites,
        benefitProvider=benefitProvider,
        serviceProvider=serviceProvider,
        coverage=coverage,
    )


def mock_main(
    mock_benefit: MockBenefit = MockBenefit(),
    mock_coverage: MockCoverage = MockCoverage(),
    matched_accumulators: List[MatchedAccumulator] = [],
) -> SelectedBenefit:
    coverage = mock_selected_coverage(
        matchedAccumulators=matched_accumulators, **mock_coverage.__dict__
    )
    benefit = mock_selected_benefit(coverage=coverage, **mock_benefit.__dict__)
    return benefit


def mock_handle(
    handler: Handler,
    service_amount: float = 0.0,
    mock_benefit: MockBenefit = MockBenefit(),
    mock_coverage: MockCoverage = MockCoverage(),
    matched_accumulators: List[MatchedAccumulator] = [],
) -> InsuranceContext:
    coverage = mock_selected_coverage(
        matchedAccumulators=matched_accumulators, **mock_coverage.__dict__
    )
    benefit = mock_selected_benefit(coverage=coverage, **mock_benefit.__dict__)
    insurance_context = InsuranceContext().populate_from_benefit(
        benefit, service_amount
    )
    handler.handle(insurance_context)
    return insurance_context


def assert_insurance_context(
    insurance_context: InsuranceContext,
    service_amount: float,
    expected_values: Dict[str, Any] = {},
    show: bool = False,
):
    if show:
        print("\n")
        print(f"Service Amount: ${insurance_context.service_amount}")
        print(f"Member Pays: ${insurance_context.member_pays}")
        print(f"Insurance Pays: ${service_amount - insurance_context.member_pays}")
        print(f"Service Covered: {insurance_context.is_service_covered}")
        print(f"Cost Share Copay: ${insurance_context.cost_share_copay}")
        print(
            f"OOP Max Individual Calculated: ${insurance_context.oopmax_individual_calculated}"
        )
        print(
            f"Deductible Individual Calculated: ${insurance_context.deductible_individual_calculated}"
        )
        print(
            f"OOP Max Family Calculated: ${insurance_context.oopmax_family_calculated}"
        )
        print(
            f"Deductible Family Calculated: ${insurance_context.deductible_family_calculated}"
        )
        print(f"Amount Coinsurance: ${insurance_context.amount_coinsurance}")
        print(f"Amount Copay: ${insurance_context.amount_copay}")
        print(f"Limit Type: {insurance_context.limit_type}")

        print("\n")
        # Print trace entries to see the flow
        for i, trace in enumerate(insurance_context.trace_entries, 1):
            print(f"{i}. [{trace.step}] {trace.description}")

    # Assert custom expected values
    for key, value in expected_values.items():
        assert (
            getattr(insurance_context, key) == value
        ), f"Expected {key} to be {value}, got {getattr(insurance_context, key)}"
    assert insurance_context.member_pays <= service_amount
