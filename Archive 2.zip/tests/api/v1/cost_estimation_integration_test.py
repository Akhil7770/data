# import pytest
# import asyncio
# import os

# from app.schemas.cost_estimator_response import CostEstimatorResponse
# from app.services.impl.token_service_impl import TokenServiceImpl
# from app.exception.exceptions import (
#     RateNotFoundException,
#     BenefitsNotFoundException,
#     InsuranceContextException,
#     BenefitsNotMatchingException,
#     AccumulatorNotFoundException,
#     BenefitsMemberNotFoundException,
#     AccumulatorMemberNotFoundException,
# )
# from app.api.v1.routes.requests import estimate_cost
# from app.schemas.cost_estimator_request import CostEstimatorRequest
# from app.schemas.cost_estimator_response import CostEstimateResponseInfoError
# from app.schemas.cost_estimator_response import CostEstimateResponseInfo
# from typing import Dict, Optional, Any
# import json
# from app.services.impl.benefit_service_impl import BenefitServiceImpl
# from app.services.impl.accumulator_service_impl import AccumulatorServiceImpl
# from app.services.impl.cost_estimation_service_impl import CostEstimatorMapper

# # # SET ENV VARS IN MAIN FIRST

# token_service = TokenServiceImpl()
# asyncio.run(token_service.get_token())

# # headers = {
# #     "eie_header_action": "READ",
# #     "eie_header_application_identifier": """{"applicationIdentifier":{"idSource":108,"idValue":"451ca1b1-c90b-4e9e-96b5-f4a0d5bbd2b6","idType":"applications"}}""",
# #     "eie_header_orchestrating_application_identifier": """{"applicationIdentifier":{"idSource":108,"idValue":"451ca1b1-c90b-4e9e-96b5-f4a0d5bbd2b6","idType":"applications"}}""",
# #     "eie_header_user_context": """{"eieHeaderUserContext":{"dnAccountName":"CN=DMT-S-W266110695,OU=Members,OU=External,DC=aetheq,DC=aetnaeq,DC=com","assuranceLevel":"2","eieHeaderAuthorizedRole":[{"authorizedRole":"subscriber"},{"authorizedRole":"subscriber"}],"accountIdentifier":{"idSource":"5","idValue":"","idType":"accounts"}}}""",
# #     "eie_header_version": """{"eieHeaderVersion":{"major":2,"minor":0,"maintenance":0}}""",
# # }

# """
# Tests:
# - 1 provider
#     - no error
#     - no rate
#     - no rate AND no benefit/accum -- REMOVED (fifo)
#     - no benefits member found (get_benefit)
#     - no benefits found - TODO
#     - no accums member found (get_accumulator)
#     - no accums found - TODO
#     - no benefits member found OR no accums member found
#     - no benefits matching
#     - ic error
# - multi provider
#     - no error
#     - some missing rate
#     - all missing rate
#     - some missing rate AND no benefit/accum
#     - any no benefits found (get_benefit)
#     - any no accums found (get_accum)
#     - any no benefits found OR any no accums found
#     - some no benefits matching
#     - all no benefits matching
#     - all ic error

# Order of errors;
# - One provider:
#     - rate error
#     - benefit or accum api error
#     - no matching benefits error
#     - ic error
# - Multiple providers:
#     - all rate errors -> raise 1 rate error
#     - >=1 benefit or accum api error -> raise 1 benefit or accum api error
#     - all no matching benefits errors -> raise 1 no matching benefits error
#     - some rate errors -> return individual rate errors
#     - some no matching benefits errors -> return individual no matching benefits errors
#     - >=1 ic errors -> return individual ic errors
# """

# # mock_single_request_data = json.load(
# #     open(
# #         os.path.join(
# #             os.path.dirname(__file__),
# #             "..",
# #             "..",
# #             "mock-data",
# #             "cost-estimation-service-data",
# #             "request.json",
# #         )
# #     )
# # )

# # mock_request_no_matching_benefits_data = json.load(
# #     open(
# #         os.path.join(
# #             os.path.dirname(__file__),
# #             "..",
# #             "..",
# #             "mock-data",
# #             "cost-estimation-service-data",
# #             "request-no-matching-benefits.json",
# #         )
# #     )
# # )

# # mock_multi_request_data = json.load(
# #     open(
# #         os.path.join(
# #             os.path.dirname(__file__),
# #             "..",
# #             "..",
# #             "mock-data",
# #             "cost-estimation-service-data",
# #             "multi-request.json",
# #         )
# #     )
# # )

# # mock_multi_request_some_no_matching_benefits_data = json.load(
# #     open(
# #         os.path.join(
# #             os.path.dirname(__file__),
# #             "..",
# #             "..",
# #             "mock-data",
# #             "cost-estimation-service-data",
# #             "multi-request-some-no-matching-benefits.json",
# #         )
# #     )
# # )

# # exception_titles = {
# #     "Rate not found": RateNotFoundException,
# #     "Benefits not found": BenefitsNotFoundException,
# #     "Insurance context error": InsuranceContextException,
# #     "Benefits not matching": BenefitsNotMatchingException,
# #     "Accumulator not found": AccumulatorNotFoundException,
# #     "Member not found by benefits api": BenefitsMemberNotFoundException,
# #     "Member not found by accumulator api": AccumulatorMemberNotFoundException,
# # }


# # def assert_response(
# #     response: CostEstimatorResponse,
# #     expected_num_successful_responses: int,
# #     expected_handled_error_counts: Dict[type[Exception], int],
# #     show: bool = False,
# # ):
# #     cost_estimate_response_info_list = (
# #         response.costEstimateResponse.costEstimateResponseInfo
# #     )
# #     if show:
# #         print("\n")
# #         print(f"CE response info list: {cost_estimate_response_info_list}")
# #         print("\n")

# #     for cost_estimate_response_info in cost_estimate_response_info_list:
# #         if isinstance(cost_estimate_response_info, CostEstimateResponseInfoError):
# #             exc_title = cost_estimate_response_info.exception["title"]
# #             exc_type = exception_titles[exc_title]
# #             assert exc_type in expected_handled_error_counts
# #             expected_handled_error_counts[exc_type] -= 1
# #             if expected_handled_error_counts[exc_type] == 0:
# #                 del expected_handled_error_counts[exc_type]
# #         else:
# #             expected_num_successful_responses -= 1
# #     assert expected_num_successful_responses == 0
# #     assert len(expected_handled_error_counts) == 0


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider():
# #     request = CostEstimatorRequest(**mock_single_request_data)
# #     response = await estimate_cost(request, **headers)
# #     assert isinstance(response, CostEstimatorResponse)
# #     assert_response(
# #         response=response,
# #         expected_num_successful_responses=1,
# #         expected_handled_error_counts={},
# #         show=True,
# #     )


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider_no_rate():
# #     request = CostEstimatorRequest(**mock_single_request_data)
# #     request.providerInfo[0].serviceLocation = "12345"
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, RateNotFoundException)


# # @pytest.mark.asyncio
# # async def test_get_benefit_one_provider_benefits_member_not_found():
# #     request = CostEstimatorRequest(**mock_single_request_data)
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     benefit_service = BenefitServiceImpl()
# #     benefit_request = CostEstimatorMapper.to_benefit_request(request)[0]
# #     try:
# #         await benefit_service.get_benefit(benefit_request)
# #     except Exception as e:
# #         assert isinstance(e, BenefitsMemberNotFoundException)


# # # TODO: find example for BenefitsNotFoundException
# # # @pytest.mark.asyncio
# # # async def test_get_benefit_one_provider_no_benefits_found():
# # #     request = CostEstimatorRequest(**mock_single_request_data)
# # #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# # #     benefit_service = BenefitServiceImpl()
# # #     benefit_request = CostEstimatorMapper.to_benefit_request(request)[0]
# # #     try:
# # #         await benefit_service.get_benefit(benefit_request)
# # #     except Exception as e:
# # #         assert isinstance(e, BenefitsNotFoundException)


# # @pytest.mark.asyncio  # failing
# # async def test_get_accumulator_one_provider_accums_member_not_found():
# #     request = CostEstimatorRequest(**mock_single_request_data)
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     accumulator_service = AccumulatorServiceImpl()
# #     try:
# #         await accumulator_service.get_accumulator(request, headers)
# #     except Exception as e:
# #         assert isinstance(e, AccumulatorMemberNotFoundException)


# # # TODO: find example for AccumulatorNotFoundException
# # # @pytest.mark.asyncio
# # # async def test_get_accumulator_one_provider_no_accums_found():
# # #     request = CostEstimatorRequest(**mock_single_request_data)
# # #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# # #     accumulator_service = AccumulatorServiceImpl()
# # #     try:
# # #         await accumulator_service.get_accumulator(request, headers)
# # #     except Exception as e:
# # #         assert isinstance(e, AccumulatorNotFoundException)


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider_benefits_member_not_found_or_accums_member_not_found():
# #     request = CostEstimatorRequest(**mock_single_request_data)
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, BenefitsMemberNotFoundException) or isinstance(
# #             e, AccumulatorMemberNotFoundException
# #         )


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider_no_benefits_matching():
# #     request = CostEstimatorRequest(**mock_request_no_matching_benefits_data)
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, BenefitsNotMatchingException)


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider_insurance_context_error():
# #     request = CostEstimatorRequest(**mock_single_request_data)
# #     request.membershipId = "5~265642475+10+1+20250101+798847+A+1"
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, InsuranceContextException)


# # @pytest.mark.asyncio
# # async def test_estimate_cost_multi_provider():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     response = await estimate_cost(request, **headers)
# #     assert isinstance(response, CostEstimatorResponse)
# #     assert_response(
# #         response=response,
# #         expected_num_successful_responses=2,
# #         expected_handled_error_counts={},
# #         show=True,
# #     )


# # @pytest.mark.asyncio  # failed
# # async def test_estimate_cost_multi_provider_some_no_rate():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.providerInfo[0].serviceLocation = "12345"
# #     response = await estimate_cost(request, **headers)
# #     assert isinstance(response, CostEstimatorResponse)
# #     assert_response(
# #         response=response,
# #         expected_num_successful_responses=1,
# #         expected_handled_error_counts={RateNotFoundException: 1},
# #         show=True,
# #     )


# # @pytest.mark.asyncio
# # async def test_estimate_cost_multi_provider_all_no_rate():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.providerInfo[0].serviceLocation = "12345"
# #     request.providerInfo[1].serviceLocation = "12345"
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, RateNotFoundException)


# # @pytest.mark.asyncio
# # async def test_estimate_cost_multi_provider_some_no_rate_some_no_benefits_found_or_no_accums_found():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.providerInfo[0].serviceLocation = "12345"
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, BenefitsNotFoundException) or isinstance(
# #             e, AccumulatorNotFoundException
# #         )


# # @pytest.mark.asyncio
# # async def test_get_benefit_multi_provider_any_no_benefits_found():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     benefit_service = BenefitServiceImpl()
# #     benefit_requests = CostEstimatorMapper.to_benefit_request(request)
# #     try:
# #         await asyncio.gather(
# #             *[
# #                 benefit_service.get_benefit(benefit_request)
# #                 for benefit_request in benefit_requests
# #             ]
# #         )
# #     except Exception as e:
# #         assert isinstance(e, BenefitsNotFoundException)


# # @pytest.mark.asyncio
# # async def test_get_accumulator_multi_provider_no_accums_found():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     accumulator_service = AccumulatorServiceImpl()
# #     try:
# #         await accumulator_service.get_accumulator(request, headers)
# #     except Exception as e:
# #         assert isinstance(e, AccumulatorNotFoundException)


# # @pytest.mark.asyncio
# # async def test_estimate_cost_multi_provider_any_no_benefits_found_or_no_accums_found():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.membershipId = "5~55555+10+110+20250101+827528+CJ+324"
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, BenefitsNotFoundException) or isinstance(
# #             e, AccumulatorNotFoundException
# #         )


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider_some_no_benefits_matching():
# #     request = CostEstimatorRequest(**mock_multi_request_some_no_matching_benefits_data)
# #     response = await estimate_cost(request, **headers)
# #     assert isinstance(response, CostEstimatorResponse)
# #     assert_response(
# #         response=response,
# #         expected_num_successful_responses=1,
# #         expected_handled_error_counts={BenefitsNotMatchingException: 1},
# #         show=True,
# #     )


# # @pytest.mark.asyncio
# # async def test_estimate_cost_one_provider_all_no_benefits_matching():
# #     request = CostEstimatorRequest(**mock_multi_request_some_no_matching_benefits_data)
# #     request.providerInfo[1] = request.providerInfo[0]
# #     try:
# #         await estimate_cost(request, **headers)
# #     except Exception as e:
# #         assert isinstance(e, BenefitsNotMatchingException)


# # @pytest.mark.asyncio
# # async def test_estimate_cost_multi_provider_insurance_context_error():
# #     request = CostEstimatorRequest(**mock_multi_request_data)
# #     request.membershipId = "5~265642475+10+1+20250101+798847+A+1"
# #     response = await estimate_cost(request, **headers)
# #     assert isinstance(response, CostEstimatorResponse)
# #     assert_response(
# #         response=response,
# #         expected_num_successful_responses=0,
# #         expected_handled_error_counts={InsuranceContextException: 2},
# #         show=True,
# #     )
